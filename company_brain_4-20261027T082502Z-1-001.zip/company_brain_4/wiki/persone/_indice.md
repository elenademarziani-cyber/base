---
tipo: azienda
argomento: Indice persone
fonti:
  - wiki/persone/
ultimo_aggiornamento: 2026-10-20
---
# Indice persone

Vista derivata dalle note persona.

| Nota | Ruolo | Azienda | Ingresso |
|---|---|---|---|
| [[marco-rossi]] | Founder e CEO | Musa AI | non documentato (fondatore) |
| [[elena-giorgi]] | Creative Director | Musa AI | non documentato |
| [[davide-ferretti]] | Operations Manager | Musa AI | 2023-06-05 |
| [[laura-conti]] | Account Manager | Musa AI | 2025-03-03 |
| [[giulio-marino]] | Data Analyst | Musa AI | 2022-12-01 |
| [[tommaso-ferraro]] | Titolare | [[cliente-artigiani-del-gusto]] | non applicabile |
| [[alessia-neri]] | CEO | [[cliente-bloome-cosmetics]] | non applicabile |
| [[marta-colombo]] | Communications Director | [[cliente-helios-energia]] | non applicabile |
| [[roberto-fabbri]] | Direttore Marketing | [[cliente-helios-energia]] | non applicabile |
| [[silvia-moretti]] | Investor Relations | [[cliente-helios-energia]] | non applicabile |
| [[andrea-lombardi]] | Responsabile Digital | [[cliente-helios-energia]] | non applicabile |
| [[luca-amendola]] | Head of Marketing | [[cliente-nordvik-italia]] | non applicabile |
| [[chiara-messina]] | Managing Partner | [[cliente-studiolex]] | non applicabile |
| [[sofia-bianchi]] | Marketing Manager | [[cliente-verdalia]] | non applicabile |
| [[giorgio-testa]] | Direttore Commerciale | [[cliente-ferro-forma]] | non applicabile |
