---
tipo: persona
ruolo: "CEO"
azienda: "[[cliente-bloome-cosmetics]]"
ingresso: null
progetti:
  - "[[tiktok-launch-bloome]]"
  - "[[analisi-dati-q1-bloome]]"
  - "[[youtube-shorts-bloome]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/bloome-cosmetics.md
  - raw/connettori/granola/2025-11-05_kickoff-tiktok-launch-bloome.md
  - raw/connettori/granola/2026-06-20_check-in-performance-bloome.md
ultimo_aggiornamento: 2026-10-20
---
# Alessia Neri

## Sintesi
- Ruolo: CEO presso [[cliente-bloome-cosmetics]] (referente).
- Contatti: a.neri@bloomecosmetics.it, +39 02 3421 9087.
- Segue direttamente i progetti; ai check-in e al kickoff TikTok.

## Collegamenti
- Azienda: [[cliente-bloome-cosmetics]]
- Offerte: [[offerta-2025-1]], [[offerta-2025-3]], [[offerta-2026-8]]
- Progetti: [[tiktok-launch-bloome]], [[analisi-dati-q1-bloome]], [[youtube-shorts-bloome]]
