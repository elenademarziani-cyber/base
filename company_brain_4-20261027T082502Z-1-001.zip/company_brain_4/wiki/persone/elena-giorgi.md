---
tipo: persona
ruolo: "Creative Director"
azienda: "[[profilo-musa-ai]]"
ingresso: null
progetti:
  - "[[tiktok-launch-bloome]]"
  - "[[case-study-produzione-nordvik]]"
  - "[[rebranding-digitale-helios]]"
  - "[[content-compliance-studiolex]]"
  - "[[automazione-email-flow-verdalia]]"
  - "[[linkedin-lead-gen-nordvik]]"
  - "[[content-q3-social-verdalia]]"
  - "[[social-growth-artigiani]]"
fonti:
  - raw/connettori/google-drive/Azienda/Musa AI - Company Profile 2026.md
  - raw/connettori/calendario/2025-11-20_dlv-026-strategia-tiktok.md
  - raw/connettori/calendario/2026-02-27_dlv-012-landing-page-case-study.md
  - raw/connettori/calendario/2026-03-15_dlv-016-nuova-content-strategy.md
  - raw/connettori/calendario/2026-03-20_dlv-021-content-calendar-legale-compliant.md
  - raw/connettori/calendario/2026-05-10_dlv-017-tone-of-voice-guide.md
  - raw/connettori/calendario/2026-05-25_dlv-008-strategia-contenuti-linkedin.md
  - raw/connettori/calendario/2026-06-15_dlv-005-content-calendar-trimestrale.md
  - raw/connettori/calendario/2026-06-15_dlv-018-contenuti-pilota-mese-1-di-3.md
  - raw/connettori/calendario/2026-07-10_dlv-004-batch-finale-8-template-email-personalizzati.md
  - raw/connettori/calendario/2026-07-15_dlv-020-contenuti-pilota-mese-2-di-3.md
  - raw/connettori/calendario/2026-07-20_dlv-007-reel-1-e-2.md
  - raw/connettori/calendario/2026-07-20_dlv-029-video-short-form-21-30.md
  - raw/connettori/calendario/2026-07-25_dlv-025-batch-20-post-linkedin.md
  - raw/connettori/calendario/2026-07-31_dlv-015-batch-12-post-luglio.md
  - raw/connettori/google-drive/Azienda/Workshop AI generativa - Novembre 2023 (slide).md
  - raw/connettori/granola/2026-07-02_weekly-status-deliverable.md
ultimo_aggiornamento: 2026-10-20
---
# Elena Giorgi

## Sintesi
- Ruolo: Creative Director in Musa AI ([[profilo-musa-ai]]).
- Ingresso: non documentato.
- Riporta a: [[marco-rossi]].
- Responsabilita' (Company Profile 2026): creazione contenuti, strategia creativa, oversight su tutti i deliverable creativi.
- Progetti ricavati dai DLV a lei assegnati (responsabile = invitato nel calendario) e dai kickoff Granola. Dalla weekly del 2026-07-02 risulta il carico piu' concentrato su di lei per i deliverable di luglio. Ha curato il [[strumenti-ai-workshop-2023]]. Nota: nella nota Granola del 2026-04-25 (Nordvik) e' invitata come facoltativa e ha rifiutato, ma il calendario DLV la indica per la strategia LinkedIn.

## Collegamenti
- Progetti seguiti: [[tiktok-launch-bloome]], [[case-study-produzione-nordvik]], [[rebranding-digitale-helios]], [[content-compliance-studiolex]], [[automazione-email-flow-verdalia]], [[linkedin-lead-gen-nordvik]], [[content-q3-social-verdalia]], [[social-growth-artigiani]]
