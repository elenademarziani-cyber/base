---
tipo: persona
ruolo: "Direttore Commerciale"
azienda: "[[cliente-ferro-forma]]"
ingresso: null
progetti:
  - "[[content-linkedin-newsletter-ferro-forma]]"
fonti:
  - raw/connettori/google-drive/Clienti/Ferro & Forma/Offerte/Offerta 2026-10 - Content LinkedIn e Newsletter B2B.md
  - raw/connettori/granola/2026-06-15_primo-contatto-ferro-e-forma.md
  - raw/connettori/email/2025-04-14_1020_presentazione-giorgio-testa-ferro-forma.md
  - raw/connettori/email/2026-10-20_1015_re-proposta-commerciale-strategia-linkedin-e-newsletter.md
ultimo_aggiornamento: 2026-10-20
---
# Giorgio Testa

## Sintesi
- Ruolo: Direttore Commerciale presso [[cliente-ferro-forma]] (referente).
- Contatti: g.testa@ferroforma.it, +39 030 8876 543 (da offerta Drive; azienda assente in anagrafica FiC).
- Primo contatto commerciale con [[marco-rossi]] il 2026-06-15, secondo incontro pianificato il 2026-07-28; ha poi accettato l'offerta (vedi [[offerta-2026-10]]) e chiesto contratto e kickoff.

## Collegamenti
- Azienda: [[cliente-ferro-forma]]
- Offerte: [[offerta-2026-10]]
- Progetti: [[content-linkedin-newsletter-ferro-forma]]
