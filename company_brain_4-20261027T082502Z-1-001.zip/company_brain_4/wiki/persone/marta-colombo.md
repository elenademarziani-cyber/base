---
tipo: persona
ruolo: "Communications Director"
azienda: "[[cliente-helios-energia]]"
ingresso: null
progetti:
  - "[[rebranding-digitale-helios]]"
  - "[[newsletter-trimestrale-helios]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/helios-energia.md
  - raw/connettori/granola/2026-05-05_review-tone-of-voice-guide-helios.md
  - raw/connettori/granola/2026-07-01_check-in-sal-3-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Marta Colombo

## Sintesi
- Ruolo: Communications Director presso [[cliente-helios-energia]] (referente).
- Contatti: m.colombo@heliosenergia.it, +39 011 7823 456.
- Referente principale per Helios; raccoglie i commenti degli altri stakeholder prima delle review.

## Collegamenti
- Azienda: [[cliente-helios-energia]]
- Offerte: [[offerta-2026-1]], [[offerta-2026-4]]
- Progetti: [[rebranding-digitale-helios]], [[newsletter-trimestrale-helios]]
