---
tipo: persona
ruolo: "Marketing Manager"
azienda: "[[cliente-verdalia]]"
ingresso: null
progetti:
  - "[[automazione-email-flow-verdalia]]"
  - "[[content-q3-social-verdalia]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/verdalia.md
  - raw/connettori/email/2025-04-14_1020_presentazione-giorgio-testa-ferro-forma.md
  - raw/connettori/granola/2026-06-28_check-in-mensile-verdalia.md
ultimo_aggiornamento: 2026-10-20
---
# Sofia Bianchi

## Sintesi
- Ruolo: Marketing Manager presso [[cliente-verdalia]] (referente).
- Contatti: s.bianchi@verdalia.it, +39 02 4521 7890.
- Ha presentato Giorgio Testa a Musa AI ([[cliente-ferro-forma]], referral del 2025-04-14).

## Collegamenti
- Azienda: [[cliente-verdalia]]
- Offerte: [[offerta-2026-3]], [[offerta-2026-7]]
- Progetti: [[automazione-email-flow-verdalia]], [[content-q3-social-verdalia]]
