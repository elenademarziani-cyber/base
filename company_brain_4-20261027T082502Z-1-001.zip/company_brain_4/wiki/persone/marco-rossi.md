---
tipo: persona
ruolo: "Founder e CEO"
azienda: "[[profilo-musa-ai]]"
ingresso: null
progetti:
  - "[[rebranding-digitale-helios]]"
  - "[[content-linkedin-newsletter-ferro-forma]]"
fonti:
  - raw/connettori/google-drive/Azienda/Musa AI - Company Profile 2026.md
  - raw/connettori/granola/2026-02-05_kickoff-rebranding-digitale-helios.md
  - raw/connettori/granola/2026-06-15_primo-contatto-ferro-e-forma.md
  - raw/connettori/granola/2026-06-10_stakeholder-review-dashboard-kpi-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Marco Rossi

## Sintesi
- Ruolo: Founder e CEO in Musa AI ([[profilo-musa-ai]]).
- Ingresso: non documentato (fondatore).
- Riporta a: non applicabile (vertice).
- Responsabilita' (Company Profile 2026): strategia aziendale, relazioni con i clienti key, business development.
- Organizza e conduce le call commerciali (primo contatto con [[giorgio-testa]]) e partecipa al kickoff e alla terza review dashboard di Helios. Conduce con Davide le review interne su marginalita' e pianificazione H2. Con Elena ha curato il [[strumenti-ai-workshop-2023]].

## Collegamenti
- Progetti seguiti: [[rebranding-digitale-helios]], [[content-linkedin-newsletter-ferro-forma]]
- Offerte preparate (campo `Preparata da`/proprietario): [[offerta-2022-1]], [[offerta-2025-1]], [[offerta-2025-2]], [[offerta-2026-1]], [[offerta-2026-2]], [[offerta-2026-4]], [[offerta-2026-5]], [[offerta-2026-8]], [[offerta-2026-9]], [[offerta-2026-10]]
