---
tipo: persona
ruolo: "Direttore Marketing"
azienda: "[[cliente-helios-energia]]"
ingresso: null
progetti:
  - "[[rebranding-digitale-helios]]"
fonti:
  - raw/connettori/email/2026-01-25_1940_re-offerta-2026-1-rebranding-digitale.md
  - raw/connettori/granola/2026-06-10_stakeholder-review-dashboard-kpi-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Roberto Fabbri

## Sintesi
- Ruolo: Direttore Marketing presso [[cliente-helios-energia]].
- Contatti: non documentato.
- Stakeholder coinvolto in kickoff e review del rebranding; chiede confronto con lo stesso periodo dell'anno precedente sulla dashboard KPI.

## Collegamenti
- Azienda: [[cliente-helios-energia]]
- Offerte: [[offerta-2026-1]]
- Progetti: [[rebranding-digitale-helios]]
