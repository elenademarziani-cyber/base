---
tipo: persona
ruolo: "Managing Partner"
azienda: "[[cliente-studiolex]]"
ingresso: null
progetti:
  - "[[content-compliance-studiolex]]"
  - "[[video-testimonianze-studiolex]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/studiolex.md
  - raw/connettori/granola/2026-05-28_modifiche-articoli-10-12-studiolex.md
ultimo_aggiornamento: 2026-10-20
---
# Avv. Chiara Messina

## Sintesi
- Ruolo: Managing Partner presso [[cliente-studiolex]] (referente).
- Contatti: c.messina@studiolex.it, +39 06 4521 8900.
- Referente per i contenuti; tramite lei passa l'esito della revisione legale interna degli articoli.

## Collegamenti
- Azienda: [[cliente-studiolex]]
- Offerte: [[offerta-2026-2]], [[offerta-2026-9]]
- Progetti: [[content-compliance-studiolex]], [[video-testimonianze-studiolex]]
