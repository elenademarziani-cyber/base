---
tipo: persona
ruolo: "Data Analyst"
azienda: "[[profilo-musa-ai]]"
ingresso: 2022-12-01
progetti:
  - "[[tiktok-launch-bloome]]"
  - "[[analisi-dati-q1-bloome]]"
  - "[[rebranding-digitale-helios]]"
  - "[[linkedin-lead-gen-nordvik]]"
  - "[[youtube-shorts-bloome]]"
fonti:
  - raw/connettori/google-drive/Azienda/Musa AI - Company Profile 2026.md
  - raw/connettori/email/2022-12-01_0905_benvenuto-giulio.md
  - raw/connettori/email/2023-06-05_0900_benvenuto-davide-ferretti-nuovo-operations-manager.md
  - raw/connettori/calendario/2026-02-12_dlv-030-report-analitico-q1.md
  - raw/connettori/calendario/2026-02-14_dlv-031-dashboard-performance.md
  - raw/connettori/calendario/2026-02-15_dlv-032-raccomandazioni-strategiche.md
  - raw/connettori/calendario/2026-05-31_dlv-027-video-short-form-1-20.md
  - raw/connettori/calendario/2026-07-03_dlv-028-report-performance-mensile-giugno.md
  - raw/connettori/calendario/2026-07-05_dlv-009-report-lead-mensile-giugno.md
  - raw/connettori/calendario/2026-07-08_dlv-019-dashboard-kpi-bozza-per-stakeholder-review.md
  - raw/connettori/calendario/2026-07-12_dlv-010-dashboard-analytics-v2-aggiunta-metrica-ctr.md
ultimo_aggiornamento: 2026-10-20
---
# Giulio Marino

## Sintesi
- Ruolo: Data Analyst in Musa AI ([[profilo-musa-ai]]).
- Ingresso: 2022-12-01.
- Riporta a: [[davide-ferretti]] (dal 2023-06-05; in precedenza direttamente [[marco-rossi]]).
- Responsabilita' (Company Profile 2026): analytics, reporting, data visualization, generazione di insight.
- Responsabile dei report e delle dashboard (Bloome, Helios, Nordvik); ha fornito i dati a supporto dell'offerta [[offerta-2026-8]] (YouTube Shorts). Partecipa al [[strumenti-ai-workshop-2023]].

## Collegamenti
- Progetti seguiti: [[tiktok-launch-bloome]], [[analisi-dati-q1-bloome]], [[rebranding-digitale-helios]], [[linkedin-lead-gen-nordvik]], [[youtube-shorts-bloome]]
- Offerte preparate (campo `Preparata da`/proprietario): [[offerta-2025-3]]
