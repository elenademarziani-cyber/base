---
tipo: persona
ruolo: "Titolare"
azienda: "[[cliente-artigiani-del-gusto]]"
ingresso: null
progetti:
  - "[[social-growth-artigiani]]"
  - "[[fotografia-prodotto-artigiani]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/artigiani-del-gusto.md
  - raw/connettori/granola/2026-03-22_kickoff-social-growth-artigiani-del-gusto.md
ultimo_aggiornamento: 2026-10-20
---
# Tommaso Ferraro

## Sintesi
- Ruolo: Titolare presso [[cliente-artigiani-del-gusto]] (referente).
- Contatti: t.ferraro@artigianidelgusto.it, +39 031 5643 210.
- Referente e decisore (titolare). Presente al kickoff del ciclo Social Growth; invitato allo shooting fotografico provvisorio.

## Collegamenti
- Azienda: [[cliente-artigiani-del-gusto]]
- Offerte: [[offerta-2022-1]], [[offerta-2026-6]]
- Progetti: [[social-growth-artigiani]], [[fotografia-prodotto-artigiani]]
