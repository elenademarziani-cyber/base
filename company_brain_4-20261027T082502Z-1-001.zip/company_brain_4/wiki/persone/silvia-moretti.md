---
tipo: persona
ruolo: "Investor Relations"
azienda: "[[cliente-helios-energia]]"
ingresso: null
progetti:
  - "[[rebranding-digitale-helios]]"
fonti:
  - raw/connettori/email/2026-01-25_1940_re-offerta-2026-1-rebranding-digitale.md
  - raw/connettori/granola/2026-06-10_stakeholder-review-dashboard-kpi-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Silvia Moretti

## Sintesi
- Ruolo: Investor Relations presso [[cliente-helios-energia]].
- Contatti: non documentato.
- Stakeholder del rebranding, attenta alla comunicazione verso gli investitori (indicatori di reputazione/sentiment dedicati).

## Collegamenti
- Azienda: [[cliente-helios-energia]]
- Offerte: [[offerta-2026-1]]
- Progetti: [[rebranding-digitale-helios]]
