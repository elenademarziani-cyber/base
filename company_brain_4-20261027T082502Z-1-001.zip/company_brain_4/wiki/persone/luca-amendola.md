---
tipo: persona
ruolo: "Head of Marketing"
azienda: "[[cliente-nordvik-italia]]"
ingresso: null
progetti:
  - "[[case-study-produzione-nordvik]]"
  - "[[linkedin-lead-gen-nordvik]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/nordvik-italia.md
  - raw/connettori/granola/2026-06-30_walkthrough-dashboard-analytics-nordvik.md
ultimo_aggiornamento: 2026-10-20
---
# Luca Amendola

## Sintesi
- Ruolo: Head of Marketing presso [[cliente-nordvik-italia]] (referente).
- Contatti: l.amendola@nordvik.it, +39 02 8876 3421.
- Referente operativo anche nel SOW del 2022; presenta la dashboard analytics in direzione.

## Collegamenti
- Azienda: [[cliente-nordvik-italia]]
- Offerte: [[offerta-2025-2]], [[offerta-2026-5]]
- Progetti: [[case-study-produzione-nordvik]], [[linkedin-lead-gen-nordvik]]
