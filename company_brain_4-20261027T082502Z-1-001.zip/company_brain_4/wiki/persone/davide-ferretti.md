---
tipo: persona
ruolo: "Operations Manager"
azienda: "[[profilo-musa-ai]]"
ingresso: 2023-06-05
progetti:
  - "[[automazione-email-flow-verdalia]]"
  - "[[rebranding-digitale-helios]]"
fonti:
  - raw/connettori/google-drive/Azienda/Musa AI - Company Profile 2026.md
  - raw/connettori/email/2023-06-05_0900_benvenuto-davide-ferretti-nuovo-operations-manager.md
  - raw/connettori/granola/2026-07-01_check-in-sal-3-helios.md
  - raw/connettori/granola/2026-04-10_kickoff-automazione-email-flow-verdalia.md
ultimo_aggiornamento: 2026-10-20
---
# Davide Ferretti

## Sintesi
- Ruolo: Operations Manager in Musa AI ([[profilo-musa-ai]]).
- Ingresso: 2023-06-05.
- Riporta a: [[marco-rossi]].
- Responsabilita' (Company Profile 2026): gestione progetti, timeline, risorse, coordinamento interno.
- Responsabile dei DLV di setup flow su Verdalia; per Helios cura timeline e coordinamento (check-in SAL 3 con la referente). Organizza i promemoria di fine progetto nel calendario e la weekly sui deliverable. Dal workshop del 2023 gestisce anche le licenze di team dei tool AI ([[strumenti-ai-workshop-2023]]). Da lui riportano [[giulio-marino]] e [[laura-conti]].

## Collegamenti
- Progetti seguiti: [[automazione-email-flow-verdalia]], [[rebranding-digitale-helios]]
