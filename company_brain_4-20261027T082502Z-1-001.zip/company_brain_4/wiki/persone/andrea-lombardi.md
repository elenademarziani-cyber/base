---
tipo: persona
ruolo: "Responsabile Digital"
azienda: "[[cliente-helios-energia]]"
ingresso: null
progetti:
  - "[[rebranding-digitale-helios]]"
fonti:
  - raw/connettori/email/2026-01-25_1940_re-offerta-2026-1-rebranding-digitale.md
  - raw/connettori/granola/2026-06-10_stakeholder-review-dashboard-kpi-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Andrea Lombardi

## Sintesi
- Ruolo: Responsabile Digital presso [[cliente-helios-energia]].
- Contatti: non documentato.
- Stakeholder del rebranding; nella terza review ha chiesto il dettaglio per canale con filtro data.

## Collegamenti
- Azienda: [[cliente-helios-energia]]
- Offerte: [[offerta-2026-1]]
- Progetti: [[rebranding-digitale-helios]]
