---
tipo: persona
ruolo: "Account Manager"
azienda: "[[profilo-musa-ai]]"
ingresso: 2025-03-03
progetti:
  - "[[case-study-produzione-nordvik]]"
  - "[[content-compliance-studiolex]]"
  - "[[social-growth-artigiani]]"
  - "[[content-q3-social-verdalia]]"
  - "[[linkedin-lead-gen-nordvik]]"
  - "[[fotografia-prodotto-artigiani]]"
  - "[[video-testimonianze-studiolex]]"
  - "[[content-linkedin-newsletter-ferro-forma]]"
fonti:
  - raw/connettori/google-drive/Azienda/Musa AI - Company Profile 2026.md
  - raw/connettori/email/2025-03-03_0900_benvenuta-laura-conti-nuova-account-manager.md
  - raw/connettori/calendario/2026-02-20_dlv-011-3-case-study-clienti-pdf.md
  - raw/connettori/calendario/2026-05-25_dlv-022-articoli-blog-1-9.md
  - raw/connettori/calendario/2026-05-28_dlv-023-articoli-blog-10-12.md
  - raw/connettori/calendario/2026-06-30_dlv-013-batch-12-post-giugno.md
  - raw/connettori/calendario/2026-07-05_dlv-006-batch-12-post-instagram-facebook-luglio.md
  - raw/connettori/calendario/2026-07-08_dlv-014-report-mensile-engagement-giugno.md
  - raw/connettori/calendario/2026-07-11_dlv-024-articolo-blog-13.md
  - raw/connettori/granola/2026-04-25_allineamento-target-mql-nordvik.md
ultimo_aggiornamento: 2026-10-20
---
# Laura Conti

## Sintesi
- Ruolo: Account Manager in Musa AI ([[profilo-musa-ai]]).
- Ingresso: 2025-03-03.
- Riporta a: [[davide-ferretti]].
- Responsabilita' (Company Profile 2026): relazioni con i clienti, raccolta dei brief, comunicazione, feedback loop.
- Progetti dai DLV a lei assegnati e dai kickoff/check-in Granola; segue come account Nordvik (allineamento MQL), StudioLex, Artigiani e Verdalia. Invitata ai promemoria di scadenza di offerte e disdette.

## Collegamenti
- Progetti seguiti: [[case-study-produzione-nordvik]], [[content-compliance-studiolex]], [[social-growth-artigiani]], [[content-q3-social-verdalia]], [[linkedin-lead-gen-nordvik]], [[fotografia-prodotto-artigiani]], [[video-testimonianze-studiolex]], [[content-linkedin-newsletter-ferro-forma]]
- Offerte preparate (campo `Preparata da`/proprietario): [[offerta-2026-3]], [[offerta-2026-6]], [[offerta-2026-7]]
