---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2026-5]]", "[[fattura-n-2026-5a]]", "[[fattura-n-2026-5b]]", "[[linkedin-lead-gen-nordvik]]"]
valore_a: "Offerta: 6.800 totali in tre tranche (50% + 25% + 25%)"
fonte_a: raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2026-5 - LinkedIn Lead Gen.md
valore_b: "Fatture emesse: acconto e SAL per 5.100; manca il 25% finale"
fonte_b: raw/connettori/fatture-in-cloud/fatture/fattura-2026-5B.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2026-5 - LinkedIn Lead Gen.md
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-5A.md
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-5B.md
ultimo_aggiornamento: 2026-10-20
---
# Saldo 2026-5 Nordvik non fatturato

## Sintesi
- Su 6.800 di offerta risultano fatturati 5.100; la tranche finale è ancora da emettere secondo l'export.
- Il progetto aveva fine prevista il 2026-08-15. Il saldo successivo all'export non è documentato.

## Collegamenti
- [[offerta-2026-5]] · [[fattura-n-2026-5a]] · [[fattura-n-2026-5b]] · [[linkedin-lead-gen-nordvik]] · [[cliente-nordvik-italia]]
