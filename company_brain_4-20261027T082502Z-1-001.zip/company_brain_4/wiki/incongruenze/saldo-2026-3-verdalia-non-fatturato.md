---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2026-3]]", "[[fattura-n-2026-3a]]", "[[automazione-email-flow-verdalia]]"]
valore_a: "Offerta: 4.500 totali, pagamento 50% + 50%"
fonte_a: raw/connettori/google-drive/Clienti/Verdalia/Offerte/Offerta 2026-3 - Automazione Email Flow.md
valore_b: "Fatture emesse: solo l'acconto da 2.250; saldo non emesso"
fonte_b: raw/connettori/fatture-in-cloud/fatture/fattura-2026-3A.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/Verdalia/Offerte/Offerta 2026-3 - Automazione Email Flow.md
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-3A.md
ultimo_aggiornamento: 2026-10-20
---
# Saldo 2026-3 Verdalia non fatturato

## Sintesi
- L'offerta prevede due tranche da 2.250, ma l'export Fatture in Cloud contiene solo l'acconto.
- Il progetto aveva fine prevista il 2026-07-30, quindi il saldo dovrebbe essere maturato.
- Non è documentato se il saldo sia stato emesso dopo l'export del 2026-07-02. Non scelgo: serve conferma dall'utente.

## Collegamenti
- [[offerta-2026-3]] · [[fattura-n-2026-3a]] · [[automazione-email-flow-verdalia]] · [[cliente-verdalia]]
