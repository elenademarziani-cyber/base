---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2022-1]]", "[[social-growth-artigiani]]", "[[fattura-n-2022-1c]]", "[[contratto-artigiani-del-gusto]]"]
valore_a: "Budget 2026 di 2.400 (12 mesi × 200); fatture in Fatture in Cloud numerate 2022-1A…D, solo aprile-luglio 2026"
fonte_a: raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
valore_b: "Ciclo 2026 dal 2026-03-20 al 2026-12-20 (circa 9 mesi, 1.800 dedotto); l'email di sollecito cita la fattura FT-2026-028"
fonte_b: raw/connettori/email/2026-06-25_0940_sollecito-pagamento-fattura-ft-2026-028.md
stato: aperta
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2026-03-22_kickoff-social-growth-artigiani-del-gusto.md
  - raw/connettori/email/2026-06-25_0940_sollecito-pagamento-fattura-ft-2026-028.md
  - raw/connettori/fatture-in-cloud/fatture/fattura-2022-1C.md
ultimo_aggiornamento: 2026-10-20
---
# Artigiani: budget, durata e numerazione delle fatture

## Sintesi
Tre discrepanze sullo stesso retainer, non risolte:
- Budget 2.400 (12 mensilità) contro un ciclo dichiarato di circa 9 mesi.
- Nell'export mancano le fatture precedenti ad aprile 2026, nonostante il retainer attivo dal 2023.
- L'email di sollecito del 2026-06-25 cita "FT-2026-028", mentre il retainer di giugno è la [[fattura-n-2022-1c]] in Fatture in Cloud.

## Collegamenti
- [[offerta-2022-1]] · [[social-growth-artigiani]] · [[fattura-n-2022-1c]] · [[contratto-artigiani-del-gusto]] · [[cliente-artigiani-del-gusto]]
