---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2025-1]]", "[[tiktok-launch-bloome]]", "[[dlv-027]]", "[[dlv-029]]"]
valore_a: "40 video short-form previsti (offerta e kickoff)"
fonte_a: raw/connettori/granola/2025-11-05_kickoff-tiktok-launch-bloome.md
valore_b: "I deliverable a calendario coprono solo i video 1-30 (1-20 e 21-30)"
fonte_b: raw/connettori/calendario/2026-07-20_dlv-029-video-short-form-21-30.md
stato: aperta
fonti:
  - raw/connettori/granola/2025-11-05_kickoff-tiktok-launch-bloome.md
  - raw/connettori/calendario/2026-05-31_dlv-027-video-short-form-1-20.md
  - raw/connettori/calendario/2026-07-20_dlv-029-video-short-form-21-30.md
ultimo_aggiornamento: 2026-10-20
---
# Bloome: 40 video previsti, deliverable solo fino al 30

## Sintesi
- Il perimetro prevede 40 video; il calendario ha deliverable solo per i video 1-30.
- Mancano i video 31-40 oppure il perimetro è stato ridotto senza traccia nelle fonti.

## Collegamenti
- [[offerta-2025-1]] · [[tiktok-launch-bloome]] · [[dlv-027]] · [[dlv-029]]
