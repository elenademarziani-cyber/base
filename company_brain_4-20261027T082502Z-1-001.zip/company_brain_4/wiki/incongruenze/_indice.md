---
tipo: indice
argomento: incongruenze tra fonti (vista derivata)
ultimo_aggiornamento: 2026-10-20
---
# Indice incongruenze

Discrepanze sostanziali tra fonti. Non sono risolte: ogni nota riporta i due valori con le fonti. Escluse ortografia, nomi abbreviati dei clienti e giorni della settimana.

| Nota | Tema | Entità principali | Stato |
|---|---|---|---|
| [[saldo-2026-3-verdalia-non-fatturato]] | Saldo non fatturato | [[automazione-email-flow-verdalia]] | aperta |
| [[saldo-2026-5-nordvik-non-fatturato]] | Saldo non fatturato | [[linkedin-lead-gen-nordvik]] | aperta |
| [[contratto-bloome-2024-vs-offerta-2025]] | Date contratto e offerta | [[tiktok-launch-bloome]] | aperta |
| [[bloome-video-previsti-vs-dlv]] | Perimetro vs deliverable | [[tiktok-launch-bloome]] | aperta |
| [[dlv-029-oltre-fine-tiktok-launch]] | Date | [[tiktok-launch-bloome]] | aperta |
| [[studiolex-articoli-previsti-vs-dlv]] | Perimetro vs deliverable | [[content-compliance-studiolex]] | aperta |
| [[nordvik-post-linkedin-senza-dlv]] | Perimetro vs deliverable | [[linkedin-lead-gen-nordvik]] | aperta |
| [[artigiani-budget-durata-e-numerazione-fatture]] | Budget, durata, numerazione | [[social-growth-artigiani]] | aperta |
| [[artigiani-offerta-2026-6-vs-retainer]] | Offerta vs retainer | [[fotografia-prodotto-artigiani]] | aperta |
| [[studiolex-penale-e-durata-non-documentate]] | Dato mancante | [[contratto-studiolex]] | aperta |
| [[helios-newsletter-stato-offerta-vs-calendario]] | Stato offerta vs calendario | [[newsletter-trimestrale-helios]] | aperta |
| [[ferro-forma-assente-in-fatture-in-cloud]] | Anagrafica mancante | [[cliente-ferro-forma]] | aperta |
| [[helios-contenuti-pilota-mese-3-senza-dlv]] | Perimetro vs deliverable | [[rebranding-digitale-helios]] | aperta |
| [[artigiani-cliente-piu-importante-vs-fatturato]] | Nota utente vs dati | [[cliente-artigiani-del-gusto]] | aperta |
