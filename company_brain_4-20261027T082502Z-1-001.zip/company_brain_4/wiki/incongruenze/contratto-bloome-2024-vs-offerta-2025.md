---
tipo: incongruenza
entita_coinvolte: ["[[contratto-bloome-cosmetics]]", "[[offerta-2025-1]]", "[[tiktok-launch-bloome]]"]
valore_a: "Contratto TikTok Launch firmato a ottobre 2024"
fonte_a: raw/connettori/google-drive/Clienti/Bloome Cosmetics/Contratti/Contratto a progetto Bloome Cosmetics - TikTok Launch.md
valore_b: "Offerta 2025-1 per lo stesso progetto del 2025-10-20, accettata il 2025-10-29; kickoff il 2025-11-05"
fonte_b: raw/connettori/email/2025-10-20_1045_offerta-2025-1-tiktok-launch.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/Bloome Cosmetics/Contratti/Contratto a progetto Bloome Cosmetics - TikTok Launch.md
  - raw/connettori/email/2024-10-10_1800_re-contratto-richiesta-clausola-di-uscita-anticipata.md
  - raw/connettori/email/2025-10-20_1045_offerta-2025-1-tiktok-launch.md
ultimo_aggiornamento: 2026-10-20
---
# Contratto Bloome (2024) vs offerta (2025)

## Sintesi
- Il contratto cita il progetto TikTok Launch e un'offerta già accettata, ma la prima offerta documentata per quel progetto è di un anno dopo.
- Possibili spiegazioni (non verificate): errore di data nel contratto, oppure un progetto precedente non documentato.
- Non scelgo una lettura; serve conferma dall'utente.

## Collegamenti
- [[contratto-bloome-cosmetics]] · [[offerta-2025-1]] · [[tiktok-launch-bloome]] · [[cliente-bloome-cosmetics]]
