---
tipo: incongruenza
entita_coinvolte: ["[[dlv-029]]", "[[tiktok-launch-bloome]]"]
valore_a: "DLV-029 in scadenza il 2026-07-20"
fonte_a: raw/connettori/calendario/2026-07-20_dlv-029-video-short-form-21-30.md
valore_b: "Fine prevista del progetto il 2026-07-15"
fonte_b: raw/connettori/calendario/2026-07-15_fine-prevista-progetto-tiktok-launch.md
stato: aperta
fonti:
  - raw/connettori/calendario/2026-07-20_dlv-029-video-short-form-21-30.md
  - raw/connettori/calendario/2026-07-15_fine-prevista-progetto-tiktok-launch.md
ultimo_aggiornamento: 2026-10-20
---
# DLV-029 oltre la fine prevista di TikTok Launch

## Sintesi
- L'ultimo deliverable cade cinque giorni dopo la fine prevista del progetto.
- La call settimanale del 2 luglio lo cita con la data concordata, quindi lo slittamento è noto ma la fine progetto non è stata aggiornata.

## Collegamenti
- [[dlv-029]] · [[tiktok-launch-bloome]] · [[2026-07-02-weekly-status-deliverable]]
