---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2026-1]]", "[[rebranding-digitale-helios]]", "[[dlv-018]]", "[[dlv-020]]"]
valore_a: "Tre mesi di contenuti pilota previsti (offerta e kickoff)"
fonte_a: raw/connettori/google-drive/Clienti/Helios Energia/Offerte/Offerta 2026-1 - Rebranding Digitale.md
valore_b: "A calendario ci sono solo i deliverable del mese 1 (DLV-018) e del mese 2 (DLV-020); manca il mese 3"
fonte_b: raw/connettori/calendario/2026-07-15_dlv-020-contenuti-pilota-mese-2-di-3.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/Helios Energia/Offerte/Offerta 2026-1 - Rebranding Digitale.md
  - raw/connettori/calendario/2026-06-15_dlv-018-contenuti-pilota-mese-1-di-3.md
  - raw/connettori/calendario/2026-07-15_dlv-020-contenuti-pilota-mese-2-di-3.md
ultimo_aggiornamento: 2026-10-20
---
# Helios: contenuti pilota, mese 3 senza deliverable

## Sintesi
- Il perimetro prevede tre mesi di contenuti pilota; i deliverable a calendario si fermano al secondo.
- La fine progetto è il 2026-11-30, quindi il mese 3 può essere ancora da pianificare: non è documentato.

## Collegamenti
- [[offerta-2026-1]] · [[rebranding-digitale-helios]] · [[dlv-018]] · [[dlv-020]]
