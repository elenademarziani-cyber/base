---
tipo: incongruenza
entita_coinvolte: ["[[cliente-artigiani-del-gusto]]", "[[social-growth-artigiani]]"]
valore_a: "Nota personale dell'utente: è il cliente più importante"
fonte_a: raw/note-personali/Info aggiuntive su artigiani del gusto.md
valore_b: "Retainer da 200 al mese, 8 dipendenti, margine del 30%, fattura di giugno scaduta nell'export"
fonte_b: raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
stato: aperta
fonti:
  - raw/note-personali/Info aggiuntive su artigiani del gusto.md
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/fatture-in-cloud/fatture/fattura-2022-1C.md
ultimo_aggiornamento: 2026-10-20
---
# Artigiani: «cliente più importante» vs fatturato

## Sintesi
- La nota personale è attendibile ma forse non aggiornata; i dati economici dicono che per fatturato è il cliente più piccolo.
- L'importanza può essere strategica o relazionale: non è un dato verificabile dalle fonti, quindi la nota dell'utente resta una annotazione.

## Collegamenti
- [[cliente-artigiani-del-gusto]] · [[social-growth-artigiani]]
