---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2026-4]]", "[[newsletter-trimestrale-helios]]"]
valore_a: "Evento di calendario: avvio della newsletter il 2026-09-07, stato provvisorio 'da confermare'"
fonte_a: raw/connettori/calendario/2026-09-07_avvio-newsletter-trimestrale-helios-da-confermare.md
valore_b: "Offerta con validità scaduta il 2026-05-27 e mai firmata; il cliente attende il budget dal CFO"
fonte_b: raw/connettori/email/2026-06-29_0852_re-sollecito-conferma-budget-newsletter-trimestrale.md
stato: aperta
fonti:
  - raw/connettori/calendario/2026-09-07_avvio-newsletter-trimestrale-helios-da-confermare.md
  - raw/connettori/google-drive/Clienti/Helios Energia/Offerte/Offerta 2026-4 - Newsletter Trimestrale.md
  - raw/connettori/email/2026-06-29_0852_re-sollecito-conferma-budget-newsletter-trimestrale.md
ultimo_aggiornamento: 2026-10-27
---
# Helios: newsletter pianificata ma offerta non firmata

## Sintesi
- Il calendario pianifica un avvio a settembre, ma l'offerta non risulta accettata e la sua validità è scaduta.
- La data del 2026-09-07 è tra 66 giorni (al 2026-07-03): va confermata o tolta dal calendario.

## Collegamenti
- [[offerta-2026-4]] · [[newsletter-trimestrale-helios]] · [[cliente-helios-energia]]
