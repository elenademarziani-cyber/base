---
tipo: incongruenza
entita_coinvolte: ["[[cliente-ferro-forma]]", "[[offerta-2026-10]]"]
valore_a: "Cliente presente in Drive con l'offerta 2026-10 e partita IVA"
fonte_a: raw/connettori/google-drive/Clienti/Ferro & Forma/Offerte/Offerta 2026-10 - Content LinkedIn e Newsletter B2B.md
valore_b: "Assente dall'anagrafica clienti di Fatture in Cloud; l'offerta è stata accettata il 2026-10-20 e il contratto non c'è ancora"
fonte_b: raw/connettori/fatture-in-cloud/README.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/Ferro & Forma/Offerte/Offerta 2026-10 - Content LinkedIn e Newsletter B2B.md
  - raw/connettori/fatture-in-cloud/README.md
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/email/2026-10-20_1015_re-proposta-commerciale-strategia-linkedin-e-newsletter.md
ultimo_aggiornamento: 2026-10-20
---
# Ferro & Forma assente in Fatture in Cloud

## Sintesi
- Il cliente ha accettato l'offerta il 2026-10-20: nel vault vale ora `stato_cliente: attivo`.
- Non è ancora in anagrafica Fatture in Cloud e non ha contratto né fatture: va creato in anagrafica prima della prima fattura (acconto del 50% all'avvio).

## Collegamenti
- [[cliente-ferro-forma]] · [[offerta-2026-10]] · [[content-linkedin-newsletter-ferro-forma]]
