---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2026-2]]", "[[content-compliance-studiolex]]", "[[dlv-022]]", "[[dlv-023]]", "[[dlv-024]]"]
valore_a: "16 articoli di blog previsti"
fonte_a: raw/connettori/google-drive/Clienti/StudioLex/Offerte/Offerta 2026-2 - Content Compliance.md
valore_b: "I deliverable arrivano fino all'articolo 13 (DLV-024)"
fonte_b: raw/connettori/calendario/2026-07-11_dlv-024-articolo-blog-13.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/StudioLex/Offerte/Offerta 2026-2 - Content Compliance.md
  - raw/connettori/calendario/2026-07-11_dlv-024-articolo-blog-13.md
ultimo_aggiornamento: 2026-10-20
---
# StudioLex: 16 articoli previsti, deliverable fino al 13

## Sintesi
- Mancano a calendario i deliverable per gli articoli 14-16, con fine progetto il 2026-08-31.
- Non è documentato se siano stati pianificati altrove o stralciati dal perimetro.

## Collegamenti
- [[offerta-2026-2]] · [[content-compliance-studiolex]] · [[dlv-024]]
