---
tipo: incongruenza
entita_coinvolte: ["[[contratto-studiolex]]", "[[content-compliance-studiolex]]"]
valore_a: "Il contratto prevede una penale se si pubblica senza validazione legale, con importo rinviato all'Allegato economico"
fonte_a: raw/connettori/google-drive/Clienti/StudioLex/Contratti/Contratto a progetto StudioLex - Febbraio 2024.md
valore_b: "L'Allegato economico non è presente in Drive; durata, rinnovo e recesso non sono indicati"
fonte_b: raw/connettori/google-drive/README.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/StudioLex/Contratti/Contratto a progetto StudioLex - Febbraio 2024.md
  - raw/connettori/google-drive/README.md
ultimo_aggiornamento: 2026-10-20
---
# StudioLex: penale e durata non documentate

## Sintesi
- L'importo della penale e le condizioni di durata del contratto non si possono ricavare dalle fonti disponibili.
- Il rischio è operativo: la validazione legale è un vincolo contrattuale su ogni articolo pubblicato.

## Collegamenti
- [[contratto-studiolex]] · [[content-compliance-studiolex]] · [[cliente-studiolex]]
