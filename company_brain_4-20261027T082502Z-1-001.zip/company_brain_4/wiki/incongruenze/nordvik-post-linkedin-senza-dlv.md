---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2026-5]]", "[[linkedin-lead-gen-nordvik]]", "[[dlv-008]]"]
valore_a: "24 post LinkedIn previsti"
fonte_a: raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2026-5 - LinkedIn Lead Gen.md
valore_b: "I deliverable del progetto riguardano strategia, report lead e dashboard; nessuno è dedicato ai post"
fonte_b: raw/connettori/calendario/2026-05-25_dlv-008-strategia-contenuti-linkedin.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2026-5 - LinkedIn Lead Gen.md
  - raw/connettori/calendario/2026-05-25_dlv-008-strategia-contenuti-linkedin.md
  - raw/connettori/granola/2026-04-25_allineamento-target-mql-nordvik.md
ultimo_aggiornamento: 2026-10-20
---
# Nordvik: 24 post previsti, nessun deliverable per i post

## Sintesi
- Il perimetro include 24 post, ma il calendario non ha DLV per la loro consegna.
- Non è documentato dove sia tracciata la consegna dei post.

## Collegamenti
- [[offerta-2026-5]] · [[linkedin-lead-gen-nordvik]] · [[dlv-008]]
