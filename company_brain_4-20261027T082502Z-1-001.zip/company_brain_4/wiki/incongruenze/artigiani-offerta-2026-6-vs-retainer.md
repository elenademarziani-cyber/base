---
tipo: incongruenza
entita_coinvolte: ["[[offerta-2026-6]]", "[[fotografia-prodotto-artigiani]]", "[[contratto-artigiani-del-gusto]]"]
valore_a: "Offerta 2026-6 da 600 una tantum, accettata il 2026-05-15; il contratto prevede lo shooting con offerte separate"
fonte_a: raw/connettori/google-drive/Clienti/Artigiani del Gusto/Offerte/Offerta 2026-6 - Fotografia Prodotto.md
valore_b: "Email del 2026-05-18: dal giugno la fotografia è inclusa nel retainer mensile; nessuna fattura da 600 nell'export"
fonte_b: raw/connettori/email/2026-05-18_0930_re-offerta-2026-6-fotografia-prodotto.md
stato: aperta
fonti:
  - raw/connettori/google-drive/Clienti/Artigiani del Gusto/Offerte/Offerta 2026-6 - Fotografia Prodotto.md
  - raw/connettori/google-drive/Clienti/Artigiani del Gusto/Contratti/Contratto retainer social - Artigiani del Gusto.md
  - raw/connettori/email/2026-05-18_0930_re-offerta-2026-6-fotografia-prodotto.md
ultimo_aggiornamento: 2026-10-20
---
# Artigiani: offerta fotografia vs retainer

## Sintesi
- Non è chiaro se i 600 siano dovuti: l'offerta accettata dice di sì, l'email successiva sposta la fotografia dentro il retainer.
- Lo shooting a calendario è provvisorio e "da definire".

## Collegamenti
- [[offerta-2026-6]] · [[fotografia-prodotto-artigiani]] · [[contratto-artigiani-del-gusto]] · [[cliente-artigiani-del-gusto]]
