# Convenzioni del wiki

Regole di comportamento e di manutenzione: vedi `../CLAUDE.md`. Questo file fissa **formato, nomi e proprietà dei fatti**.

## 1. Principi
- `raw/` è fonte di verità, in sola lettura. Il wiki sintetizza e rimanda, **non copia**.
- Ogni fatto vive in **una sola nota proprietaria** (§4). Le altre note la linkano con `[[slug]]`.
- Indici (`_indice.md`) e `timeline/` sono **viste derivate**: ripetono dati delle note proprietarie in forma di tabella e si rigenerano da esse. Mai modificare un dato lì senza modificarlo nella nota proprietaria.
- Data di riferimento dell'export: **2026-07-02**. Data odierna di calcolo: **2026-10-20** (aggiornarla quando si ricalcola).
- Dato non presente nelle fonti → scrivere `non documentato`, mai inventare. Dato dedotto → marcarlo `(dedotto)`.

## 2. Nomi e link
- Il nome file è lo slug: minuscolo, trattini, senza accenti, `.md`. Lo slug è unico in tutto il vault.
- Wikilink: `[[slug]]` (senza cartella). Poiché `raw/` fa parte del vault Obsidian, gli slug del wiki **non devono coincidere** (nemmeno ignorando maiuscole/minuscole) con nomi di file in `raw/`: per questo i clienti hanno il prefisso `cliente-` e le fatture `fattura-n-`. Esempi:
  - clienti: `cliente-artigiani-del-gusto`, `cliente-bloome-cosmetics`, `cliente-helios-energia`, `cliente-nordvik-italia`, `cliente-studiolex`, `cliente-verdalia`, `cliente-ferro-forma`
  - offerte: `offerta-2026-5`, `offerta-2022-1` · contratti: `contratto-<slug-cliente>` (es. `contratto-verdalia`)
  - fatture: `fattura-n-2026-5a` (lettera minuscola) · DLV: `dlv-008`
  - persone: `nome-cognome` (es. `marco-rossi`)
  - call: nome file raw senza estensione, primo `_` → `-` (es. `2026-06-26-review-marginalita-progetti`)
  - progetti: `<titolo>-<cliente>` (§5)
- Le fonti raw vanno nel campo `fonti` del frontmatter come **percorsi dalla radice del vault** (es. `raw/connettori/fatture-in-cloud/fatture/fattura-2026-5A.md`), mai come wikilink. Nel corpo si cita la fonte con il nome file tra backtick.

## 3. Frontmatter (obbligatorio, YAML)
Campi comuni a ogni nota: `tipo`, `fonti` (lista di percorsi), `ultimo_aggiornamento` (ISO). Date sempre ISO `AAAA-MM-GG`; importi come numeri in euro, IVA esclusa, senza simbolo (`importo: 2600`); percentuali come numero (`margine_pct: 40`). Campi non noti: `null`.

| tipo | Campi specifici |
|---|---|
| `cliente` | `slug, ragione_sociale, piva, sede, settore, dipendenti, referente (wikilink), stato_cliente (attivo\|prospect), contratto (wikilink\|null)` |
| `progetto` | `cliente, offerta, periodo_inizio, periodo_fine_prevista, stato_documentato, stato_calcolato_oggi, valore_offerta, fatturato_emesso, residuo_da_fatturare, margine_eur, margine_pct, team (dedotto da responsabili DLV e partecipanti alle call)` |
| `offerta` | `numero, cliente, data, importo, stato_documentato, validita, preparata_da, progetto, fatture` |
| `contratto` | `cliente, formula (quadro\|progetto\|retainer\|sow), firma, durata, rinnovo, preavviso_disdetta, clausole_chiave` |
| `fattura` | `numero, cliente, offerta, progetto, contatto_sollecito (wikilink al referente del cliente), tipo_fattura (acconto\|sal\|saldo\|retainer\|unica), importo (senza IVA), aliquota_iva, iva, importo_ivato, emissione, scadenza, stato_documentato, incasso, stato_calcolato_oggi` |
| `call` | `data, durata_min, natura (cliente\|interna), cliente, progetto, partecipanti` |
| `deliverable` | `id, progetto, cliente, data, responsabile, stato_documentato` |
| `persona` | `ruolo, azienda, ingresso, progetti` |
| `incongruenza` | `entita_coinvolte, valore_a, fonte_a, valore_b, fonte_b, stato (aperta\|chiusa)` |
| `azienda` / `timeline` / `indice` | `argomento` (gli indici non hanno `fonti`) |

Vocabolari:
- `stato_documentato` fattura: `pagata | scaduta | in-attesa` (stato al 2026-07-02).
- `stato_documentato` offerta: `accettata | rifiutata | in-sospeso | non-accettata | in-valutazione`.
- `stato_documentato` progetto: `in-corso | concluso | lead | prospect | rifiutato | non-avviato`.
- `stato_calcolato_oggi`: testo breve calcolato rispetto a oggi (es. `scaduta da 17 giorni`, `in termini, scade tra 12 giorni`). In ogni nota che lo usa aggiungere la riga: *"Calcolato rispetto al 2026-07-03, non confermato dalle fonti."* (data di riferimento in `CLAUDE.md`)

## 4. Chi possiede quale fatto
| Fatto | Nota proprietaria | Le altre note |
|---|---|---|
| Anagrafica fiscale, sede, settore, dimensione | cliente | linkano il cliente |
| Contatti e ruolo di una persona | persona | il cliente linka il referente |
| Importo offerta, perimetro (contenuti, quantità), pagamento, validità, stato | offerta | il progetto rimanda all'offerta per il perimetro |
| Durata, rinnovo, disdetta, esclusiva, penali | contratto | cliente e timeline linkano |
| Importo, scadenza, stato, incasso di una fattura | fattura | il progetto somma e linka |
| Date di avvio e fine, valore, fatturato, residuo, margine, stato | progetto | indice progetti tabula; l'offerta rimanda al progetto per le date |
| Data, responsabile, stato di un deliverable | deliverable | il progetto linka |
| Decisioni e azioni di una call | call | progetto e persone linkano |
| Date calcolate (termine disdetta, scadenza offerta) | timeline | |
| Ruolo e data di ingresso nel team | persona | |
| Note personali dell'utente | cliente (sezione "Note dell'utente") | |

Esempio: l'importo di una fattura compare solo nella nota fattura; il progetto riporta `fatturato_emesso` (somma) e l'elenco delle fatture con wikilink, senza ripetere i singoli importi.

## 5. Progetti (14, uno per offerta)
`social-growth-artigiani` (2022-1) · `tiktok-launch-bloome` (2025-1) · `case-study-produzione-nordvik` (2025-2) · `analisi-dati-q1-bloome` (2025-3) · `rebranding-digitale-helios` (2026-1) · `content-compliance-studiolex` (2026-2) · `automazione-email-flow-verdalia` (2026-3) · `newsletter-trimestrale-helios` (2026-4) · `linkedin-lead-gen-nordvik` (2026-5) · `fotografia-prodotto-artigiani` (2026-6) · `content-q3-social-verdalia` (2026-7) · `youtube-shorts-bloome` (2026-8) · `video-testimonianze-studiolex` (2026-9) · `content-linkedin-newsletter-ferro-forma` (2026-10).
Per i progetti non avviati/rifiutati/prospect: `fatturato_emesso: 0`.

## 6. Struttura di una nota
```
---
frontmatter
---
# Titolo
## Sintesi            (5-15 righe, solo ciò che la nota possiede)
## Collegamenti       (wikilink alle note correlate, con etichetta del ruolo)
## Incongruenze       (solo se ce ne sono: link alla nota in incongruenze/)
```
- Cliente: aggiungere `## Note dell'utente` (da `raw/note-personali/`, attendibili ma forse non aggiornate).
- Nessun testo copiato dalle fonti oltre brevi termini tecnici; niente trascrizioni; niente ripetizione di dati di altre note.

## 7. Incongruenze
Una nota in `incongruenze/` per ogni discrepanza sostanziale tra fonti, con entrambi i valori e le fonti, **senza scegliere**. Le note coinvolte la linkano nella sezione `## Incongruenze`. Escluse: ortografia, nomi abbreviati dei clienti, giorni della settimana.

## 8. Cartelle
`clienti/ progetti/ offerte-contratti/ persone/ fatture/ call/ deliverable/ azienda/ timeline/ incongruenze/`, ciascuna con `_indice.md` (tabella: nota, stato, valore, date). Punto d'ingresso: `00-indice.md`. Registro modifiche: `log.md`.
