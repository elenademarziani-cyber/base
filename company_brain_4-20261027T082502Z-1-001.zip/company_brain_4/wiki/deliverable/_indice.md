---
tipo: azienda
argomento: indice dei deliverable DLV-001...DLV-032
fonti:
  - raw/connettori/granola/2026-07-02_weekly-status-deliverable.md
ultimo_aggiornamento: 2026-10-20
---
# Indice deliverable

Vista derivata dalle note `dlv-NNN`: in caso di dubbio vale la nota proprietaria. Stato al 2026-07-02 (export).

## [[social-growth-artigiani]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-013]] | Batch 12 post (giugno) | Social Growth | 2026-06-30 | [[laura-conti]] | consegnato |
| [[dlv-014]] | Report mensile engagement (giugno) | Social Growth | 2026-07-08 | [[laura-conti]] | da-consegnare |
| [[dlv-015]] | Batch 12 post (luglio) | Social Growth | 2026-07-31 | [[elena-giorgi]] | da-consegnare |

## [[tiktok-launch-bloome]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-026]] | Strategia TikTok | TikTok Launch | 2025-11-20 | [[elena-giorgi]] | consegnato |
| [[dlv-027]] | Video short-form 1-20 | TikTok Launch | 2026-05-31 | [[giulio-marino]] | consegnato |
| [[dlv-028]] | Report performance mensile (giugno) | TikTok Launch | 2026-07-03 | [[giulio-marino]] | da-consegnare |
| [[dlv-029]] | Video short-form 21-30 | TikTok Launch | 2026-07-20 | [[elena-giorgi]] | da-consegnare |

## [[case-study-produzione-nordvik]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-011]] | 3 case study clienti (PDF) | Case Study Produzione | 2026-02-20 | [[laura-conti]] | consegnato |
| [[dlv-012]] | Landing page case study | Case Study Produzione | 2026-02-27 | [[elena-giorgi]] | consegnato |

## [[analisi-dati-q1-bloome]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-030]] | Report analitico Q1 | Analisi Dati Q1 | 2026-02-12 | [[giulio-marino]] | consegnato |
| [[dlv-031]] | Dashboard performance | Analisi Dati Q1 | 2026-02-14 | [[giulio-marino]] | consegnato |
| [[dlv-032]] | Raccomandazioni strategiche | Analisi Dati Q1 | 2026-02-15 | [[giulio-marino]] | consegnato |

## [[rebranding-digitale-helios]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-016]] | Nuova content strategy | Rebranding Digitale | 2026-03-15 | [[elena-giorgi]] | consegnato |
| [[dlv-017]] | Tone of voice guide | Rebranding Digitale | 2026-05-10 | [[elena-giorgi]] | consegnato |
| [[dlv-018]] | Contenuti pilota - mese 1 di 3 | Rebranding Digitale | 2026-06-15 | [[elena-giorgi]] | consegnato |
| [[dlv-019]] | Dashboard KPI (bozza per stakeholder review) | Rebranding Digitale | 2026-07-08 | [[giulio-marino]] | in-revisione |
| [[dlv-020]] | Contenuti pilota - mese 2 di 3 | Rebranding Digitale | 2026-07-15 | [[elena-giorgi]] | da-consegnare |

## [[content-compliance-studiolex]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-021]] | Content calendar legale-compliant | Content Compliance | 2026-03-20 | [[elena-giorgi]] | consegnato |
| [[dlv-022]] | Articoli blog 1-9 | Content Compliance | 2026-05-25 | [[laura-conti]] | consegnato |
| [[dlv-023]] | Articoli blog 10-12 | Content Compliance | 2026-05-28 | [[laura-conti]] | consegnato |
| [[dlv-024]] | Articolo blog 13 | Content Compliance | 2026-07-11 | [[laura-conti]] | in-revisione |
| [[dlv-025]] | Batch 20 post LinkedIn | Content Compliance | 2026-07-25 | [[elena-giorgi]] | da-consegnare |

## [[automazione-email-flow-verdalia]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-001]] | Setup flow welcome | Automazione Email Flow | 2026-04-30 | [[davide-ferretti]] | consegnato |
| [[dlv-002]] | Setup flow abandoned cart | Automazione Email Flow | 2026-05-20 | [[davide-ferretti]] | consegnato |
| [[dlv-003]] | Setup flow post-purchase | Automazione Email Flow | 2026-06-15 | [[davide-ferretti]] | consegnato |
| [[dlv-004]] | Batch finale 8 template email personalizzati | Automazione Email Flow | 2026-07-10 | [[elena-giorgi]] | in-revisione |

## [[linkedin-lead-gen-nordvik]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-008]] | Strategia contenuti LinkedIn | LinkedIn Lead Gen | 2026-05-25 | [[elena-giorgi]] | consegnato |
| [[dlv-009]] | Report lead mensile (giugno) | LinkedIn Lead Gen | 2026-07-05 | [[giulio-marino]] | da-consegnare |
| [[dlv-010]] | Dashboard analytics v2 (aggiunta metrica CTR) | LinkedIn Lead Gen | 2026-07-12 | [[giulio-marino]] | in-lavorazione |

## [[content-q3-social-verdalia]]

| id | titolo | progetto | data | responsabile | stato_documentato |
|---|---|---|---|---|---|
| [[dlv-005]] | Content calendar trimestrale | Content Q3 Social | 2026-06-15 | [[elena-giorgi]] | consegnato |
| [[dlv-006]] | Batch 12 post Instagram/Facebook (luglio) | Content Q3 Social | 2026-07-05 | [[laura-conti]] | da-consegnare |
| [[dlv-007]] | Reel #1 e #2 | Content Q3 Social | 2026-07-20 | [[elena-giorgi]] | da-consegnare |
