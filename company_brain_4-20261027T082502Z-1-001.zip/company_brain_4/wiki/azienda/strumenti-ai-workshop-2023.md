---
tipo: azienda
argomento: Strumenti AI e metodo (workshop interno, novembre 2023)
fonti:
  - raw/connettori/google-drive/Azienda/Workshop AI generativa - Novembre 2023 (slide).md
  - raw/connettori/calendario/2023-11-16_workshop-interno-ai-generativa.md
ultimo_aggiornamento: 2026-10-20
---
# Strumenti AI e workshop 2023

## Sintesi
- Primo workshop interno sull'AI generativa, 2023-11-16, a cura di [[marco-rossi]] ed [[elena-giorgi]]; partecipanti: Marco, Elena, [[davide-ferretti]], [[giulio-marino]] (Laura non ancora in azienda). Obiettivo: stessi strumenti e stesso metodo per tutto il team.
- Tool adottati: ChatGPT (GPT-4) per bozze e varianti; Midjourney e DALL-E 3 per concept visivi; Adobe Firefly per ritocchi su asset del cliente (uso commerciale); Canva (funzioni AI) per formati social; Runway per prove di video short-form. Licenze di team gestite da Davide.
- Metodo di prompting: Ruolo, Contesto, Compito, Formato, Vincoli; iterare e salvare i prompt efficaci in una libreria condivisa su Drive.
- Regole etiche e di qualita': revisione umana obbligatoria su tutto cio' che va al cliente; verifica di fatti, dati e nomi; trasparenza con i clienti sull'uso dell'AI; attenzione a diritti d'immagine e dati personali; nessun dato riservato dei clienti nei tool senza accordo; nei settori regolamentati valgono le validazioni del cliente.
- Prossimi passi: prova dei tool su attivita' reali, libreria prompt condivisa, raccolta di dubbi per il prossimo incontro, bozza di linee guida interne (Elena e Marco). Esito successivo: non documentato.

## Collegamenti
- [[profilo-musa-ai]] (valore "etica nell'uso dell'AI")
