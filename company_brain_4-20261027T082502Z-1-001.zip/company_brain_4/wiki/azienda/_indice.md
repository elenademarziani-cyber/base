---
tipo: indice
argomento: Indice azienda
ultimo_aggiornamento: 2026-10-20
---
# Indice azienda

Vista derivata dalle note della cartella.

| Nota | Argomento |
|---|---|
| [[profilo-musa-ai]] | Chi e' Musa AI, mission, servizi, valori, contatti |
| [[strumenti-ai-workshop-2023]] | Tool AI adottati, metodo, regole etiche, prossimi passi |
