---
tipo: azienda
argomento: profilo di Musa AI
fonti:
  - raw/connettori/google-drive/Azienda/Musa AI - Company Profile 2026.md
ultimo_aggiornamento: 2026-10-20
---
# Profilo di Musa AI

## Sintesi
- Agenzia di marketing creativa che applica l'intelligenza artificiale a content creation, automazione e analisi dati; fondata nel 2021 (dal Company Profile 2026, ultima modifica 2026-01-12).
- Mission: democratizzare l'uso dell'AI nel marketing, per aziende di ogni dimensione.
- Servizi: content creation con AI, automazione email, social media strategy, analisi dati di marketing.
- Posizionamento: integrare l'AI nei processi creativi senza perdere l'elemento umano e strategico (automazione intelligente, insight data-driven, storytelling autentico).
- Valori: innovazione continua, trasparenza nei risultati, collaborazione attiva con i clienti, etica nell'uso dell'AI.
- Contatti: info@musa.ai, sito musa.ai.
- Un **listino** non è documentato: i prezzi si ricavano dalle singole offerte.

## Collegamenti
- Team: [[marco-rossi]], [[elena-giorgi]], [[davide-ferretti]], [[laura-conti]], [[giulio-marino]]
- Strumenti e regole sull'AI: [[strumenti-ai-workshop-2023]]
- Offerte e contratti: [[offerte-contratti/_indice]]
