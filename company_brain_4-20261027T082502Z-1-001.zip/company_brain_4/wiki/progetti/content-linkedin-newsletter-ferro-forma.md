---
tipo: progetto
cliente: "[[cliente-ferro-forma]]"
offerta: "[[offerta-2026-10]]"
periodo_inizio: null
periodo_fine_prevista: null
stato_documentato: non-avviato
stato_calcolato_oggi: "al 2026-07-03 offerta inviata, valida fino al 2026-08-25 (tra 53 giorni); l'accettazione del 2026-10-20 viene da una fonte successiva alla data di riferimento"
valore_offerta: 2800
fatturato_emesso: 0
residuo_da_fatturare: null
margine_eur: null
margine_pct: null
team: ["[[marco-rossi]]", "[[laura-conti]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-15_primo-contatto-ferro-e-forma.md
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/calendario/2026-08-25_scadenza-offerta-2026-10-ferro-forma.md
  - raw/connettori/email/2026-10-20_1015_re-proposta-commerciale-strategia-linkedin-e-newsletter.md
ultimo_aggiornamento: 2026-10-27
---
# Content LinkedIn e Newsletter B2B — Ferro & Forma

## Sintesi
- Progetto per [[cliente-ferro-forma]] (perimetro in [[offerta-2026-10]]): offerta accettata dal cliente; contratto da inviare e kickoff da fissare.
- Costi e margine non stimabili perché il progetto non è avviato.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-10]]
- Call: [[2026-06-15-primo-contatto-ferro-e-forma]], [[2026-06-26-review-marginalita-progetti]], [[2026-06-29-review-account-e-pipeline]]

## Incongruenze
- [[ferro-forma-assente-in-fatture-in-cloud]]
