---
tipo: progetto
cliente: "[[cliente-nordvik-italia]]"
offerta: "[[offerta-2025-2]]"
periodo_inizio: 2026-01-05
periodo_fine_prevista: 2026-02-28
stato_documentato: concluso
stato_calcolato_oggi: "concluso e interamente fatturato e incassato"
valore_offerta: 2100
fatturato_emesso: 2100
residuo_da_fatturare: 0
margine_eur: 945
margine_pct: 45
team: ["[[elena-giorgi]]", "[[laura-conti]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2026-01-03_kickoff-case-study-produzione-nordvik.md
ultimo_aggiornamento: 2026-10-27
---
# Case Study Produzione — Nordvik Italia

## Sintesi
- Progetto per [[cliente-nordvik-italia]] (perimetro in [[offerta-2025-2]]); concluso.
- Progetto a margine alto (45%), chiuso con una sola fattura.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2025-2]] · Contratto: [[contratto-nordvik-italia]]
- Fattura: [[fattura-n-2025-2a]]
- Deliverable: [[dlv-011]], [[dlv-012]]
- Call: [[2026-01-03-kickoff-case-study-produzione-nordvik]], [[2026-06-26-review-marginalita-progetti]]
