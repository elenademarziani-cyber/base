---
tipo: progetto
cliente: "[[cliente-studiolex]]"
offerta: "[[offerta-2026-2]]"
periodo_inizio: 2026-03-01
periodo_fine_prevista: 2026-08-31
stato_documentato: in-corso
stato_calcolato_oggi: "in corso, fine prevista il 2026-08-31 (tra 59 giorni); saldo in termini"
valore_offerta: 3600
fatturato_emesso: 3600
residuo_da_fatturare: 0
margine_eur: 1080
margine_pct: 30
team: ["[[elena-giorgi]]", "[[laura-conti]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2026-03-01_kickoff-content-compliance-studiolex.md
  - raw/connettori/calendario/2026-08-31_fine-prevista-progetto-content-compliance.md
ultimo_aggiornamento: 2026-10-27
---
# Content Compliance — StudioLex

## Sintesi
- Progetto per lo studio legale [[cliente-studiolex]] (perimetro in [[offerta-2026-2]]); la revisione legale prima della pubblicazione è un vincolo contrattuale ([[contratto-studiolex]]).
- Interamente fatturato (acconto e saldo); il margine è al 30%.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-2]] · Contratto: [[contratto-studiolex]]
- Fatture: [[fattura-n-2026-2a]], [[fattura-n-2026-2b]]
- Deliverable: [[dlv-021]], [[dlv-022]], [[dlv-023]], [[dlv-024]], [[dlv-025]]
- Call: [[2026-03-01-kickoff-content-compliance-studiolex]], [[2026-05-28-modifiche-articoli-10-12-studiolex]], [[2026-06-26-review-marginalita-progetti]]
- Offerta correlata: [[video-testimonianze-studiolex]]

## Incongruenze
- [[studiolex-articoli-previsti-vs-dlv]]
- [[studiolex-penale-e-durata-non-documentate]]
