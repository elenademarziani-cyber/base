---
tipo: indice
argomento: riepilogo dei progetti, una riga per progetto (query Dataview)
ultimo_aggiornamento: 2026-10-20
---
# Riepilogo progetti

Una riga per progetto, calcolata da **Dataview** sulle proprietà delle note progetto (nessun dato è copiato qui). Importi in euro, IVA esclusa. Lo stato è quello documentato nell'export del 2026-07-02. Il plugin Dataview deve essere installato e abilitato (vedi [[riepilogo-fatture]]).

```dataview
TABLE WITHOUT ID
  file.link AS "Progetto",
  cliente AS "Cliente",
  offerta AS "Offerta",
  stato_documentato AS "Stato",
  fatturato_emesso AS "Fatturato emesso (€)"
FROM "wiki/progetti"
WHERE tipo = "progetto"
SORT cliente ASC, offerta ASC
```

## Totale
```dataview
TABLE WITHOUT ID
  length(rows) AS "N. progetti",
  sum(rows.fatturato_emesso) AS "Fatturato emesso (€)"
FROM "wiki/progetti"
WHERE tipo = "progetto"
GROUP BY true
```

## Valori attesi per il controllo
14 progetti e 35.950 di fatturato emesso totale (coincide con il totale delle fatture, vedi [[fatture/_indice]]). Più dettagli per progetto (valore offerta, residuo, margine): [[progetti/_indice]].
