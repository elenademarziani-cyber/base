---
tipo: progetto
cliente: "[[cliente-nordvik-italia]]"
offerta: "[[offerta-2026-5]]"
periodo_inizio: 2026-05-10
periodo_fine_prevista: 2026-08-15
stato_documentato: in-corso
stato_calcolato_oggi: "in corso, fine prevista il 2026-08-15 (tra 43 giorni); SAL in termini, saldo non ancora fatturato"
valore_offerta: 6800
fatturato_emesso: 5100
residuo_da_fatturare: 1700
margine_eur: 2380
margine_pct: 35
team: ["[[elena-giorgi]]", "[[giulio-marino]]", "[[laura-conti]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2026-04-25_allineamento-target-mql-nordvik.md
  - raw/connettori/calendario/2026-08-15_fine-prevista-progetto-linkedin-lead-gen.md
ultimo_aggiornamento: 2026-10-27
---
# LinkedIn Lead Gen — Nordvik Italia

## Sintesi
- Progetto per [[cliente-nordvik-italia]] (perimetro in [[offerta-2026-5]]); obiettivi concordati nella call di allineamento.
- Fatturati acconto e SAL; il saldo finale non risulta emesso.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-5]] · Contratto: [[contratto-nordvik-italia]]
- Fatture: [[fattura-n-2026-5a]], [[fattura-n-2026-5b]]
- Deliverable: [[dlv-008]], [[dlv-009]], [[dlv-010]]
- Call: [[2026-04-25-allineamento-target-mql-nordvik]], [[2026-06-30-walkthrough-dashboard-analytics-nordvik]], [[2026-06-26-review-marginalita-progetti]]

## Incongruenze
- [[saldo-2026-5-nordvik-non-fatturato]]
- [[nordvik-post-linkedin-senza-dlv]]
