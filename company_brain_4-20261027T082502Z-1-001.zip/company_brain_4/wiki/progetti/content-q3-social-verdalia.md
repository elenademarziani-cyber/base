---
tipo: progetto
cliente: "[[cliente-verdalia]]"
offerta: "[[offerta-2026-7]]"
periodo_inizio: 2026-06-01
periodo_fine_prevista: 2026-09-30
stato_documentato: in-corso
stato_calcolato_oggi: "in corso, fine prevista il 2026-09-30 (tra 89 giorni)"
valore_offerta: 3200
fatturato_emesso: 3200
residuo_da_fatturare: 0
margine_eur: 1300
margine_pct: 41
team: ["[[elena-giorgi]]", "[[laura-conti]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/calendario/2026-09-30_fine-prevista-progetto-content-q3-social.md
ultimo_aggiornamento: 2026-10-27
---
# Content Q3 Social — Verdalia

## Sintesi
- Progetto per i social di [[cliente-verdalia]] (perimetro in [[offerta-2026-7]]); fatturato in anticipo e incassato.
- Margine al 41%, il migliore tra i progetti in corso alla review.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-7]] · Contratto: [[contratto-verdalia]]
- Fattura: [[fattura-n-2026-7a]]
- Deliverable: [[dlv-005]], [[dlv-006]], [[dlv-007]]
- Call: [[2026-06-28-check-in-mensile-verdalia]], [[2026-06-26-review-marginalita-progetti]]
- Altro progetto del cliente: [[automazione-email-flow-verdalia]]
