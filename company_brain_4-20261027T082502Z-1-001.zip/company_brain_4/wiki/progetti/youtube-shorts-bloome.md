---
tipo: progetto
cliente: "[[cliente-bloome-cosmetics]]"
offerta: "[[offerta-2026-8]]"
periodo_inizio: null
periodo_fine_prevista: null
stato_documentato: rifiutato
stato_calcolato_oggi: "offerta rifiutata dal cliente il 2026-06-17"
valore_offerta: 1800
fatturato_emesso: 0
residuo_da_fatturare: 0
margine_eur: null
margine_pct: null
team: null   # nessun responsabile documentato
fonti:
  - raw/connettori/granola/2026-06-20_check-in-performance-bloome.md
  - raw/connettori/granola/2026-06-29_review-account-e-pipeline.md
ultimo_aggiornamento: 2026-10-27
---
# Estensione YouTube Shorts — Bloome Cosmetics

## Sintesi
- Upsell proposto a [[cliente-bloome-cosmetics]] per estendere i video TikTok su YouTube Shorts; il cliente ha declinato per concentrare il budget su TikTok.
- Nessuna attività né fattura.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-8]]
- Progetto di partenza: [[tiktok-launch-bloome]]
- Call: [[2026-06-20-check-in-performance-bloome]]
