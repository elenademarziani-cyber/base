---
tipo: progetto
cliente: "[[cliente-helios-energia]]"
offerta: "[[offerta-2026-1]]"
periodo_inizio: 2026-02-01
periodo_fine_prevista: 2026-11-30
stato_documentato: in-corso
stato_calcolato_oggi: "in corso, fine prevista il 2026-11-30 (tra 150 giorni); SAL 3 in termini"
valore_offerta: 12500
fatturato_emesso: 12502
residuo_da_fatturare: 0
margine_eur: 3125
margine_pct: 25
team:
  - "[[davide-ferretti]]"
  - "[[elena-giorgi]]"
  - "[[giulio-marino]]"
  - "[[marco-rossi]]"
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2026-02-05_kickoff-rebranding-digitale-helios.md
  - raw/connettori/calendario/2026-11-30_fine-prevista-progetto-rebranding-digitale.md
ultimo_aggiornamento: 2026-10-27
---
# Rebranding Digitale — Helios Energia

## Sintesi
- È il progetto più grande per [[cliente-helios-energia]] (perimetro in [[offerta-2026-1]]).
- Il margine è il più basso (25%) per le molte iterazioni, in particolare sulla dashboard: in review è stata decisa l'azione di monitorare le ore.
- Fatturato completo in tre tranche; l'ultima (SAL 3) era ancora da incassare nell'export.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-1]] · Contratto: [[contratto-helios-energia]]
- Fatture: [[fattura-n-2026-1a]], [[fattura-n-2026-1b]], [[fattura-n-2026-1c]]
- Deliverable: [[dlv-016]], [[dlv-017]], [[dlv-018]], [[dlv-019]], [[dlv-020]]
- Call: [[2026-02-05-kickoff-rebranding-digitale-helios]], [[2026-05-05-review-tone-of-voice-guide-helios]], [[2026-06-10-stakeholder-review-dashboard-kpi-helios]], [[2026-07-01-check-in-sal-3-helios]], [[2026-06-26-review-marginalita-progetti]]
- Offerta correlata: [[newsletter-trimestrale-helios]]

## Incongruenze
- [[helios-contenuti-pilota-mese-3-senza-dlv]]
