---
tipo: progetto
cliente: "[[cliente-bloome-cosmetics]]"
offerta: "[[offerta-2025-3]]"
periodo_inizio: 2026-01-10
periodo_fine_prevista: 2026-02-15
stato_documentato: concluso
stato_calcolato_oggi: "concluso e interamente fatturato e incassato"
valore_offerta: 1200
fatturato_emesso: 1200
residuo_da_fatturare: 0
margine_eur: 600
margine_pct: 50
team: ["[[giulio-marino]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/calendario/2026-02-12_dlv-030-report-analitico-q1.md
ultimo_aggiornamento: 2026-10-27
---
# Analisi Dati Q1 — Bloome Cosmetics

## Sintesi
- Progetto per [[cliente-bloome-cosmetics]] (perimetro in [[offerta-2025-3]]); concluso.
- È il progetto col margine più alto (50%).
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2025-3]] · Contratto: [[contratto-bloome-cosmetics]]
- Fattura: [[fattura-n-2025-3a]]
- Deliverable: [[dlv-030]], [[dlv-031]], [[dlv-032]]
- Call: [[2026-06-26-review-marginalita-progetti]]
