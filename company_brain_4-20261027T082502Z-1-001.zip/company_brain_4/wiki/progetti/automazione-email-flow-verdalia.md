---
tipo: progetto
cliente: "[[cliente-verdalia]]"
offerta: "[[offerta-2026-3]]"
periodo_inizio: 2026-04-15
periodo_fine_prevista: 2026-07-30
stato_documentato: in-corso
stato_calcolato_oggi: "in corso, fine prevista il 2026-07-30 (tra 27 giorni); saldo non ancora fatturato"
valore_offerta: 4500
fatturato_emesso: 2250
residuo_da_fatturare: 2250
margine_eur: 1800
margine_pct: 40
team: ["[[davide-ferretti]]", "[[elena-giorgi]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2026-04-10_kickoff-automazione-email-flow-verdalia.md
  - raw/connettori/calendario/2026-07-30_fine-prevista-progetto-automazione-email-flow.md
ultimo_aggiornamento: 2026-10-27
---
# Automazione Email Flow — Verdalia

## Sintesi
- Progetto per [[cliente-verdalia]] (perimetro in [[offerta-2026-3]]); include un test A/B sulle subject line.
- Fatturato solo l'acconto: nell'export non risulta emessa la fattura di saldo.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-3]] · Contratto: [[contratto-verdalia]]
- Fattura: [[fattura-n-2026-3a]]
- Deliverable: [[dlv-001]], [[dlv-002]], [[dlv-003]], [[dlv-004]]
- Call: [[2026-04-10-kickoff-automazione-email-flow-verdalia]], [[2026-06-28-check-in-mensile-verdalia]], [[2026-06-26-review-marginalita-progetti]]
- Altro progetto del cliente: [[content-q3-social-verdalia]]

## Incongruenze
- [[saldo-2026-3-verdalia-non-fatturato]]
