---
tipo: progetto
cliente: "[[cliente-studiolex]]"
offerta: "[[offerta-2026-9]]"
periodo_inizio: null
periodo_fine_prevista: null
stato_documentato: lead
stato_calcolato_oggi: "in valutazione; validità dell'offerta fino al 2026-07-10 (tra 7 giorni)"
valore_offerta: 2200
fatturato_emesso: 0
residuo_da_fatturare: null
margine_eur: null
margine_pct: null
team: null   # nessun responsabile documentato
fonti:
  - raw/connettori/granola/2026-06-29_review-account-e-pipeline.md
  - raw/connettori/calendario/2026-07-10_scadenza-offerta-2026-9-studiolex.md
ultimo_aggiornamento: 2026-10-27
---
# Video Testimonianze — StudioLex

## Sintesi
- Upsell per [[cliente-studiolex]] (perimetro in [[offerta-2026-9]]); il cliente attende la validazione legale interna prima di decidere.
- Nessuna attività né fattura; margine non stimabile.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-9]] · Contratto: [[contratto-studiolex]]
- Progetto di riferimento: [[content-compliance-studiolex]]
- Call: [[2026-06-29-review-account-e-pipeline]]
