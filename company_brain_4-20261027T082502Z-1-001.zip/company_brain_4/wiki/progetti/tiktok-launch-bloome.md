---
tipo: progetto
cliente: "[[cliente-bloome-cosmetics]]"
offerta: "[[offerta-2025-1]]"
periodo_inizio: 2025-11-05
periodo_fine_prevista: 2026-07-15
stato_documentato: in-corso
stato_calcolato_oggi: "in corso, fine prevista il 2026-07-15 (tra 12 giorni)"
valore_offerta: 5200
fatturato_emesso: 5200
residuo_da_fatturare: 0
margine_eur: 2080
margine_pct: 40
team: ["[[elena-giorgi]]", "[[giulio-marino]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2025-11-05_kickoff-tiktok-launch-bloome.md
  - raw/connettori/calendario/2026-07-15_fine-prevista-progetto-tiktok-launch.md
ultimo_aggiornamento: 2026-10-27
---
# TikTok Launch — Bloome Cosmetics

## Sintesi
- Lancio su TikTok di [[cliente-bloome-cosmetics]] (perimetro in [[offerta-2025-1]]).
- Interamente fatturato (acconto e saldo). Al momento della review il margine era a rischio se la frequenza dei video fosse aumentata a parità di budget.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2025-1]] · Contratto: [[contratto-bloome-cosmetics]]
- Fatture: [[fattura-n-2025-1a]], [[fattura-n-2025-1b]]
- Deliverable: [[dlv-026]], [[dlv-027]], [[dlv-028]], [[dlv-029]]
- Call: [[2025-11-05-kickoff-tiktok-launch-bloome]], [[2026-06-20-check-in-performance-bloome]], [[2026-06-26-review-marginalita-progetti]]
- Offerta correlata: [[youtube-shorts-bloome]]

## Incongruenze
- [[contratto-bloome-2024-vs-offerta-2025]]
- [[bloome-video-previsti-vs-dlv]]
- [[dlv-029-oltre-fine-tiktok-launch]]
