---
tipo: indice
argomento: progetti (vista derivata)
ultimo_aggiornamento: 2026-10-20
---
# Indice progetti

Vista derivata dalle note progetto (importi in euro, IVA esclusa). Stato documentato = export del 2026-07-02. La proprietà dei dati resta nelle note. Per la tabella dinamica con una riga per progetto apri [[_riepilogo-progetti]] (query Dataview).

| Progetto | Cliente | Stato documentato | Valore offerta | Fatturato | Residuo | Margine % |
|---|---|---|---|---|---|---|
| [[social-growth-artigiani]] | [[cliente-artigiani-del-gusto]] | in-corso | 2.400 (budget 2026) | 800 | n/a (retainer) | 30 |
| [[tiktok-launch-bloome]] | [[cliente-bloome-cosmetics]] | in-corso | 5.200 | 5.200 | 0 | 40 |
| [[case-study-produzione-nordvik]] | [[cliente-nordvik-italia]] | concluso | 2.100 | 2.100 | 0 | 45 |
| [[analisi-dati-q1-bloome]] | [[cliente-bloome-cosmetics]] | concluso | 1.200 | 1.200 | 0 | 50 |
| [[rebranding-digitale-helios]] | [[cliente-helios-energia]] | in-corso | 12.500 | 12.500 | 0 | 25 |
| [[content-compliance-studiolex]] | [[cliente-studiolex]] | in-corso | 3.600 | 3.600 | 0 | 30 |
| [[automazione-email-flow-verdalia]] | [[cliente-verdalia]] | in-corso | 4.500 | 2.250 | 2.250 | 40 |
| [[linkedin-lead-gen-nordvik]] | [[cliente-nordvik-italia]] | in-corso | 6.800 | 5.100 | 1.700 | 35 |
| [[content-q3-social-verdalia]] | [[cliente-verdalia]] | in-corso | 3.200 | 3.200 | 0 | 41 |
| [[newsletter-trimestrale-helios]] | [[cliente-helios-energia]] | lead | 1.800 | 0 | n/d | n/d |
| [[fotografia-prodotto-artigiani]] | [[cliente-artigiani-del-gusto]] | non-avviato | 600 | 0 | n/d | n/d |
| [[youtube-shorts-bloome]] | [[cliente-bloome-cosmetics]] | rifiutato | 1.800 | 0 | 0 | n/d |
| [[video-testimonianze-studiolex]] | [[cliente-studiolex]] | lead | 2.200 | 0 | n/d | n/d |
| [[content-linkedin-newsletter-ferro-forma]] | [[cliente-ferro-forma]] | non-avviato | 2.800 | 0 | n/d | n/d |

Fatturato totale dei progetti: 35.950 (coincide con il totale delle fatture, vedi [[fatture/_indice]]).
