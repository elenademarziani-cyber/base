---
tipo: progetto
cliente: "[[cliente-artigiani-del-gusto]]"
offerta: "[[offerta-2026-6]]"
periodo_inizio: null
periodo_fine_prevista: null
stato_documentato: non-avviato
stato_calcolato_oggi: "shooting provvisorio previsto il 2026-07-15 (tra 12 giorni)"
valore_offerta: 600
fatturato_emesso: 0
residuo_da_fatturare: null
margine_eur: null
margine_pct: null
team: null   # nessun responsabile documentato
fonti:
  - raw/connettori/calendario/2026-07-15_shooting-fotografico-artigiani-del-gusto-provvisorio.md
  - raw/connettori/granola/2026-06-29_review-account-e-pipeline.md
ultimo_aggiornamento: 2026-10-27
---
# Fotografia Prodotto — Artigiani del Gusto

## Sintesi
- Upsell proposto a [[cliente-artigiani-del-gusto]] (perimetro in [[offerta-2026-6]]): l'offerta è stata accettata, ma le email indicano poi che la fotografia entra nel retainer mensile.
- Non è documentato se i 600 siano dovuti, quindi il residuo da fatturare resta `null`.
- Lo shooting è un evento provvisorio "da definire" nel calendario.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-6]] · Contratto: [[contratto-artigiani-del-gusto]]
- Progetto di riferimento: [[social-growth-artigiani]]

## Incongruenze
- [[artigiani-offerta-2026-6-vs-retainer]]
