---
tipo: progetto
cliente: "[[cliente-artigiani-del-gusto]]"
offerta: "[[offerta-2022-1]]"
periodo_inizio: 2026-03-20
periodo_fine_prevista: 2026-12-20
stato_documentato: in-corso
stato_calcolato_oggi: "in corso, fine ciclo prevista il 2026-12-20 (tra 170 giorni); 1 fattura del retainer scaduta"
valore_offerta: 2400
fatturato_emesso: 800
residuo_da_fatturare: null
margine_eur: 720
margine_pct: 30
team: ["[[elena-giorgi]]", "[[laura-conti]]"]   # dedotto da responsabili DLV e partecipanti alle call
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/granola/2026-03-22_kickoff-social-growth-artigiani-del-gusto.md
  - raw/connettori/calendario/2026-12-20_fine-prevista-progetto-social-growth.md
ultimo_aggiornamento: 2026-10-27
---
# Social Growth — Artigiani del Gusto

## Sintesi
- Retainer social di [[cliente-artigiani-del-gusto]], attivo dal 2023 (perimetro in [[offerta-2022-1]]); ciclo 2026 dal 20 marzo al 20 dicembre.
- `valore_offerta` è il budget di riferimento 2026 indicato in review (200 al mese × 12); `fatturato_emesso` conta le sole 4 mensilità presenti nell'export (aprile-luglio 2026). Il residuo non è calcolabile perché il retainer è mensile.
- Il margine è quello stimato nella review di giugno.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2022-1]] · Contratto: [[contratto-artigiani-del-gusto]]
- Fatture: [[fattura-n-2022-1a]], [[fattura-n-2022-1b]], [[fattura-n-2022-1c]], [[fattura-n-2022-1d]]
- Deliverable: [[dlv-013]], [[dlv-014]], [[dlv-015]]
- Call: [[2026-03-22-kickoff-social-growth-artigiani-del-gusto]], [[2026-06-26-review-marginalita-progetti]]
- Offerta collegata fuori dal progetto: [[fotografia-prodotto-artigiani]]

## Incongruenze
- [[artigiani-budget-durata-e-numerazione-fatture]]
- [[artigiani-offerta-2026-6-vs-retainer]]
