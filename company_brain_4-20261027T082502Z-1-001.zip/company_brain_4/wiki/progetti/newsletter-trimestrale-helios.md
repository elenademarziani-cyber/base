---
tipo: progetto
cliente: "[[cliente-helios-energia]]"
offerta: "[[offerta-2026-4]]"
periodo_inizio: null
periodo_fine_prevista: null
stato_documentato: lead
stato_calcolato_oggi: "lead in attesa di budget; avvio provvisorio previsto il 2026-09-07 (tra 66 giorni)"
valore_offerta: 1800
fatturato_emesso: 0
residuo_da_fatturare: null
margine_eur: null
margine_pct: null
team: null   # nessun responsabile documentato
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
  - raw/connettori/calendario/2026-09-07_avvio-newsletter-trimestrale-helios-da-confermare.md
ultimo_aggiornamento: 2026-10-27
---
# Newsletter Trimestrale — Helios Energia

## Sintesi
- Newsletter trimestrale proposta a [[cliente-helios-energia]] (perimetro in [[offerta-2026-4]]); è un lead: l'offerta non risulta accettata perché il cliente attende l'ok del budget dal CFO.
- Costi e margine non sono stimabili: progetto non avviato e team non assegnato.
- Nel calendario l'avvio è un evento provvisorio "da confermare" al 2026-09-07.
- Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Offerta: [[offerta-2026-4]] · Contratto quadro: [[contratto-helios-energia]]
- Call: [[2026-06-26-review-marginalita-progetti]], [[2026-06-29-review-account-e-pipeline]]
- Progetto principale del cliente: [[rebranding-digitale-helios]]

## Incongruenze
- [[helios-newsletter-stato-offerta-vs-calendario]]
