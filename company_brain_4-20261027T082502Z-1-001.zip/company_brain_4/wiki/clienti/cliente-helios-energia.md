---
tipo: cliente
slug: cliente-helios-energia
ragione_sociale: "Helios Energia"
piva: IT09123450011
sede: "Corso Vittorio Emanuele 88, Torino"
settore: "Energia / Rinnovabili"
dipendenti: 55
referente: "[[marta-colombo]]"
stato_cliente: attivo
contratto: "[[contratto-helios-energia]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/helios-energia.md
  - raw/connettori/google-drive/Clienti/Helios Energia/Offerte/Offerta 2026-1 - Rebranding Digitale.md
  - raw/connettori/google-drive/Clienti/Helios Energia/Offerte/Offerta 2026-4 - Newsletter Trimestrale.md
  - raw/connettori/granola/2026-02-05_kickoff-rebranding-digitale-helios.md
  - raw/connettori/email/2023-06-01_1620_contratto-quadro-helios-energia-musa-ai-firmato.md
ultimo_aggiornamento: 2026-10-20
---
# Helios Energia

## Sintesi
Media impresa del settore energia rinnovabile, con forte attenzione al linguaggio tecnico e alla comunicazione verso gli investitori. Cliente attivo con contratto quadro (firmato nel 2023, vedi contratto). Il progetto di rebranding digitale coinvolge quattro stakeholder interni: [[marta-colombo]] (referente), [[roberto-fabbri]], [[silvia-moretti]], [[andrea-lombardi]]. La newsletter trimestrale e' un'offerta ancora in attesa di conferma di budget.

## Collegamenti
- Referente: [[marta-colombo]]
- Contratto: [[contratto-helios-energia]]
- Offerte: [[offerta-2026-1]], [[offerta-2026-4]]
- Progetti: [[rebranding-digitale-helios]], [[newsletter-trimestrale-helios]]

## Incongruenze
- [[helios-newsletter-stato-offerta-vs-calendario]]
