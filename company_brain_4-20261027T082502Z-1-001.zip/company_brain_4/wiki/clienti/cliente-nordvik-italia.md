---
tipo: cliente
slug: cliente-nordvik-italia
ragione_sociale: "Nordvik Italia"
piva: IT07832410158
sede: "Corso Buenos Aires 77, Milano"
settore: "Software gestionale B2B"
dipendenti: 40
referente: "[[luca-amendola]]"
stato_cliente: attivo
contratto: "[[contratto-nordvik-italia]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/nordvik-italia.md
  - raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2025-2 - Case Study Produzione.md
  - raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2026-5 - LinkedIn Lead Gen.md
  - raw/connettori/email/2022-09-12_1140_sow-firmato-avvio-collaborazione-nordvik-musa-ai.md
ultimo_aggiornamento: 2026-10-20
---
# Nordvik Italia

## Sintesi
Media impresa che sviluppa software gestionale per il mercato B2B; il marketing e' orientato alla lead generation, con LinkedIn come canale principale. Cliente dal settembre 2022 (primo SOW). Ogni progetto e' contrattualizzato a parte (nessun accordo quadro, vedi contratto). Un progetto di case study e' concluso; e' in corso il progetto LinkedIn di lead generation.

## Collegamenti
- Referente: [[luca-amendola]]
- Contratto: [[contratto-nordvik-italia]]
- Offerte: [[offerta-2025-2]], [[offerta-2026-5]]
- Progetti: [[case-study-produzione-nordvik]], [[linkedin-lead-gen-nordvik]]

## Incongruenze
- [[saldo-2026-5-nordvik-non-fatturato]]
- [[nordvik-post-linkedin-senza-dlv]]
