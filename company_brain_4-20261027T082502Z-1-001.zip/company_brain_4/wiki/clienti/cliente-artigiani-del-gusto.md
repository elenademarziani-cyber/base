---
tipo: cliente
slug: cliente-artigiani-del-gusto
ragione_sociale: "Artigiani del Gusto"
piva: IT03241780132
sede: "Via Roma 34, Como"
settore: "Food & Beverage / Retail"
dipendenti: 8
referente: "[[tommaso-ferraro]]"
stato_cliente: attivo
contratto: "[[contratto-artigiani-del-gusto]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/artigiani-del-gusto.md
  - raw/connettori/google-drive/Clienti/Artigiani del Gusto/Offerte/Offerta 2022-1 - Social Growth (retainer).md
  - raw/connettori/google-drive/Clienti/Artigiani del Gusto/Offerte/Offerta 2026-6 - Fotografia Prodotto.md
  - raw/connettori/granola/2026-03-22_kickoff-social-growth-artigiani-del-gusto.md
  - raw/note-personali/Info aggiuntive su artigiani del gusto.md
ultimo_aggiornamento: 2026-10-20
---
# Artigiani del Gusto

## Sintesi
Piccola impresa (bottega alimentare e retail) di Como. Il titolare decide in prima persona. Cliente attivo dal 2023 con gestione continuativa dei social (Instagram e Facebook); dal kickoff del 2026-03-22 e' in corso un nuovo ciclo di gestione. Budget contenuto, risultati organici apprezzati dal cliente; un'offerta di upsell (fotografia prodotto) e' collegata al retainer esistente.

## Collegamenti
- Referente: [[tommaso-ferraro]]
- Contratto: [[contratto-artigiani-del-gusto]]
- Offerte: [[offerta-2022-1]], [[offerta-2026-6]]
- Progetti: [[social-growth-artigiani]], [[fotografia-prodotto-artigiani]]

## Note dell'utente
- L'utente lo considera il suo cliente piu' importante (`Info aggiuntive su artigiani del gusto.md`); nota attendibile ma forse non aggiornata, non verificata dalle fonti. Confronto con il fatturato: [[artigiani-cliente-piu-importante-vs-fatturato]].

## Incongruenze
- [[artigiani-budget-durata-e-numerazione-fatture]]
- [[artigiani-offerta-2026-6-vs-retainer]]
- [[artigiani-cliente-piu-importante-vs-fatturato]]
