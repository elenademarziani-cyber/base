---
tipo: cliente
slug: cliente-studiolex
ragione_sociale: "StudioLex"
piva: IT11234560589
sede: "Via Nazionale 112, Roma"
settore: "Legal / Servizi Professionali"
dipendenti: 12
referente: "[[chiara-messina]]"
stato_cliente: attivo
contratto: "[[contratto-studiolex]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/studiolex.md
  - raw/connettori/google-drive/Clienti/StudioLex/Offerte/Offerta 2026-2 - Content Compliance.md
  - raw/connettori/google-drive/Clienti/StudioLex/Offerte/Offerta 2026-9 - Produzione Video Testimonianze Clienti.md
  - raw/connettori/email/2024-02-19_1200_contratto-studiolex-musa-ai-firmato.md
ultimo_aggiornamento: 2026-10-20
---
# StudioLex

## Sintesi
Studio associato di 12 professionisti in un settore regolamentato: massima attenzione a deontologia, tone of voice e compliance, con validazione legale interna di ogni contenuto. Cliente attivo (contratto a progetto del febbraio 2024). Un piano editoriale su blog e LinkedIn e' in corso; l'offerta di video testimonianze e' un upsell separato.

## Collegamenti
- Referente: [[chiara-messina]]
- Contratto: [[contratto-studiolex]]
- Offerte: [[offerta-2026-2]], [[offerta-2026-9]]
- Progetti: [[content-compliance-studiolex]], [[video-testimonianze-studiolex]]

## Incongruenze
- [[studiolex-articoli-previsti-vs-dlv]]
- [[studiolex-penale-e-durata-non-documentate]]
