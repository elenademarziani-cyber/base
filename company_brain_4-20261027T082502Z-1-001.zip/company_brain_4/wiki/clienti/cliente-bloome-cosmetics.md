---
tipo: cliente
slug: cliente-bloome-cosmetics
ragione_sociale: "Bloome Cosmetics"
piva: IT12345670155
sede: "Via Savona 50, Milano"
settore: "Beauty / Ecommerce"
dipendenti: 6
referente: "[[alessia-neri]]"
stato_cliente: attivo
contratto: "[[contratto-bloome-cosmetics]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/bloome-cosmetics.md
  - raw/connettori/google-drive/Clienti/Bloome Cosmetics/Offerte/Offerta 2025-1 - TikTok Launch.md
  - raw/connettori/google-drive/Clienti/Bloome Cosmetics/Offerte/Offerta 2025-3 - Analisi Dati Q1.md
  - raw/connettori/google-drive/Clienti/Bloome Cosmetics/Offerte/Offerta 2026-8 - Estensione TikTok su YouTube Shorts.md
  - raw/connettori/email/2024-12-20_1730_chiusura-2024-6-clienti-attivi.md
ultimo_aggiornamento: 2026-10-20
---
# Bloome Cosmetics

## Sintesi
Startup beauty/ecommerce orientata ai trend e alla crescita rapida su TikTok e Instagram; la CEO segue direttamente i progetti. Cliente dall'ottobre 2024 (ultimo arrivato nel portfolio del 2024, da email interna). Il progetto TikTok e' il filone principale; l'analisi dati Q1 e' conclusa; l'estensione su YouTube Shorts e' stata proposta come upsell.

## Collegamenti
- Referente: [[alessia-neri]]
- Contratto: [[contratto-bloome-cosmetics]]
- Offerte: [[offerta-2025-1]], [[offerta-2025-3]], [[offerta-2026-8]]
- Progetti: [[tiktok-launch-bloome]], [[analisi-dati-q1-bloome]], [[youtube-shorts-bloome]]

## Incongruenze
- [[contratto-bloome-2024-vs-offerta-2025]]
- [[bloome-video-previsti-vs-dlv]]
- [[dlv-029-oltre-fine-tiktok-launch]]
