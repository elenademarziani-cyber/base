---
tipo: azienda
argomento: Indice clienti
fonti:
  - wiki/clienti/
ultimo_aggiornamento: 2026-10-20
---
# Indice clienti

Vista derivata dalle note cliente.

| Nota | Settore | stato_cliente | Referente |
|---|---|---|---|
| [[cliente-artigiani-del-gusto]] | Food & Beverage / Retail | attivo | [[tommaso-ferraro]] |
| [[cliente-bloome-cosmetics]] | Beauty / Ecommerce | attivo | [[alessia-neri]] |
| [[cliente-helios-energia]] | Energia / Rinnovabili | attivo | [[marta-colombo]] |
| [[cliente-nordvik-italia]] | Software gestionale B2B | attivo | [[luca-amendola]] |
| [[cliente-studiolex]] | Legal / Servizi Professionali | attivo | [[chiara-messina]] |
| [[cliente-verdalia]] | Ecommerce moda sostenibile | attivo | [[sofia-bianchi]] |
| [[cliente-ferro-forma]] | Design Industriale / B2B | attivo | [[giorgio-testa]] |
