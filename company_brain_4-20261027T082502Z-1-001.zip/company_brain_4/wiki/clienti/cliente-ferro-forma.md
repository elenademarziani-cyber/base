---
tipo: cliente
slug: cliente-ferro-forma
ragione_sociale: "Ferro & Forma"
piva: IT05678900171
sede: "Via dell'Industria 22, Brescia"
settore: "Design Industriale / B2B"
dipendenti: 20
referente: "[[giorgio-testa]]"
stato_cliente: attivo
contratto: null
fonti:
  - raw/connettori/google-drive/Clienti/Ferro & Forma/Offerte/Offerta 2026-10 - Content LinkedIn e Newsletter B2B.md
  - raw/connettori/granola/2026-06-15_primo-contatto-ferro-e-forma.md
  - raw/connettori/email/2025-04-14_1020_presentazione-giorgio-testa-ferro-forma.md
  - raw/connettori/email/2026-10-20_1015_re-proposta-commerciale-strategia-linkedin-e-newsletter.md
ultimo_aggiornamento: 2026-10-20
---
# Ferro & Forma

## Sintesi
PMI di design industriale B2B di Brescia, senza una strategia di contenuti strutturata e interessata a LinkedIn e newsletter B2B. Cliente dall'accettazione dell'offerta (vedi [[offerta-2026-10]]); prima era un prospect. Contatto nato per referral di [[cliente-verdalia]] (prima presentazione ad aprile 2025, primo contatto commerciale il 2026-06-15). Non presente in anagrafica Fatture in Cloud (solo documenti Drive). Contratto ancora da firmare.

## Collegamenti
- Referente: [[giorgio-testa]]
- Contratto: nessuno (da firmare)
- Offerte: [[offerta-2026-10]]
- Progetti: [[content-linkedin-newsletter-ferro-forma]]

## Incongruenze
- [[ferro-forma-assente-in-fatture-in-cloud]]
