---
tipo: cliente
slug: cliente-verdalia
ragione_sociale: "Verdalia"
piva: IT04521890155
sede: "Via Tortona 12, Milano"
settore: "Ecommerce moda sostenibile"
dipendenti: 15
referente: "[[sofia-bianchi]]"
stato_cliente: attivo
contratto: "[[contratto-verdalia]]"
fonti:
  - raw/connettori/fatture-in-cloud/clienti/verdalia.md
  - raw/connettori/google-drive/Clienti/Verdalia/Offerte/Offerta 2026-3 - Automazione Email Flow.md
  - raw/connettori/google-drive/Clienti/Verdalia/Offerte/Offerta 2026-7 - Content Q3 Social.md
  - raw/connettori/granola/2026-06-29_review-account-e-pipeline.md
  - raw/connettori/email/2022-03-10_1500_contratto-quadro-musa-ai-verdalia-controfirmato.md
ultimo_aggiornamento: 2026-10-20
---
# Verdalia

## Sintesi
PMI di moda sostenibile in ecommerce. Cliente storico e fidelizzato (contratto quadro dal 2022, vedi contratto), con interesse crescente per l'automazione email e per i contenuti social. La referente ha anche segnalato Ferro & Forma a Musa AI ([[cliente-ferro-forma]]).

## Collegamenti
- Referente: [[sofia-bianchi]]
- Contratto: [[contratto-verdalia]]
- Offerte: [[offerta-2026-3]], [[offerta-2026-7]]
- Progetti: [[automazione-email-flow-verdalia]], [[content-q3-social-verdalia]]

## Incongruenze
- [[saldo-2026-3-verdalia-non-fatturato]]
