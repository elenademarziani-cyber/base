---
tipo: indice
ultimo_aggiornamento: 2026-10-27
---
# Company Brain — Musa AI

Secondo cervello aziendale di Musa AI (esercitazione). Le fonti sono in `raw/` (sola lettura); qui c'è la sintesi collegata.
Regole: [[CONVENZIONI]] · Registro modifiche: [[log]]

## Come interrogarlo
1. Parti da un cliente o da un progetto: ogni nota linka offerte, contratti, fatture, call e deliverable.
2. Per i numeri usa gli indici (tabelle riepilogative).
3. Stati: *documentato* = export del 2026-07-02; *calcolato* = rispetto al 2026-07-03 (data di riferimento).
4. Dove le fonti si contraddicono trovi una nota in [[incongruenze/_indice]]: i due valori sono riportati, nessuno è scelto.

## Mappa
| Sezione | Contenuto | Indice |
|---|---|---|
| clienti | 7 clienti | [[clienti/_indice]] |
| progetti | 14 progetti: valore, fatturato, margine | [[progetti/_indice]] |
| offerte-contratti | 14 offerte e 6 contratti | [[offerte-contratti/_indice]] |
| fatture | 17 fatture e riconciliazione | [[fatture/_indice]] |
| persone | 5 del team Musa AI e 10 referenti cliente | [[persone/_indice]] |
| call | 19 call Granola | [[call/_indice]] |
| deliverable | 32 deliverable DLV | [[deliverable/_indice]] |
| azienda | profilo e strumenti AI | [[azienda/_indice]] |
| timeline | scadenze, rinnovi, disdette | [[timeline/_indice]] |
| incongruenze | 14 discrepanze tra fonti | [[incongruenze/_indice]] |

## Numeri chiave (export 2026-07-02)
Fatturato 35.950, incassato 29.050, aperto 6.900: dettaglio in [[fatture/_indice]].
