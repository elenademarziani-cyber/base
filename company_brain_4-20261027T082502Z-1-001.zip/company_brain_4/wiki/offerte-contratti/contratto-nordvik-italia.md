---
tipo: contratto
cliente: "[[cliente-nordvik-italia]]"
formula: sow
firma: 2022-09 (SOW 01 firmato dal cliente, email del 2022-09-12)
durata: pari al progetto, conclusa con consegna e accettazione dei deliverable
rinnovo: nessun rinnovo automatico
preavviso_disdetta: non documentato
clausole_chiave:
  - contratto a progetto, nessun accordo quadro
  - ogni nuovo incarico richiede un nuovo SOW
  - riservatezza reciproca
  - foro di Milano
fonti:
  - "raw/connettori/google-drive/Clienti/Nordvik Italia/Contratti/SOW 01 - Nordvik Italia - Settembre 2022.md"
  - raw/connettori/email/2022-09-12_1140_sow-firmato-avvio-collaborazione-nordvik-musa-ai.md
ultimo_aggiornamento: 2026-10-20
---
# SOW 01 Nordvik Italia (settembre 2022)

## Sintesi
- Primo progetto di collaborazione: marketing B2B con contenuti LinkedIn a supporto della lead generation.
- Natura: contratto a progetto. Tra le parti non esiste un accordo quadro; ogni progetto ha il proprio SOW che richiama l'offerta accettata (nota interna: usare questo SOW come modello).
- Deliverable, tempistiche e corrispettivo rimandano all'Allegato A, che non è nel Drive: `non documentato`.
- Nessun rinnovo automatico; il SOW termina con la consegna dei deliverable.
- Per le offerte 2025-2 e 2026-5 il cliente annuncia SOW dedicati nelle email, ma non sono presenti nel Drive: `non documentato`.

## Collegamenti
- Cliente: [[cliente-nordvik-italia]] · Referente: [[luca-amendola]]
- Offerte successive: [[offerta-2025-2]], [[offerta-2026-5]]
