---
tipo: offerta
numero: 2022-1
cliente: "[[cliente-artigiani-del-gusto]]"
data: 2022-12-15
importo: 200
stato_documentato: accettata
validita: nessuna scadenza autonoma (contestuale al contratto di retainer)
preparata_da: "[[marco-rossi]]"
progetto: "[[social-growth-artigiani]]"
fatture: ["[[fattura-n-2022-1a]]", "[[fattura-n-2022-1b]]", "[[fattura-n-2022-1c]]", "[[fattura-n-2022-1d]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Artigiani del Gusto/Offerte/Offerta 2022-1 - Social Growth (retainer).md"
  - raw/connettori/email/2022-12-15_1030_proposta-retainer-social-offerta-2022-1.md
  - raw/connettori/email/2023-01-12_1115_re-proposta-retainer-social-offerta-2022-1.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2022-1 - Social Growth (retainer)

## Sintesi
- Importo: retainer mensile di 200 euro IVA esclusa (`importo` è la rata mensile, non un totale).
- Contenuto: gestione continuativa di Instagram e Facebook, 12 post al mese (copy, visual, pubblicazione), con calendario mensile da approvare.
- Tempistiche: avvio alla firma del contratto di retainer (gennaio 2023); durata e rinnovo come da contratto.
- Pagamento: fatturazione il 1° di ogni mese, pagamento a 15 giorni data fattura.
- Stato: inviata il 2022-12-15 insieme alla bozza di contratto; accettata il 2023-01-12 con il contratto firmato ("così com'è").
- Aggiornamento 2026 (nota di L. Conti, marzo 2026): nuovo ciclo dal 2026-03-20 al 2026-12-20, budget di riferimento 2.400 euro, stesso retainer di 200 euro/mese e stesso piano (12 post/mese).

## Collegamenti
- Cliente: [[cliente-artigiani-del-gusto]] · Contratto: [[contratto-artigiani-del-gusto]] · Progetto: [[social-growth-artigiani]]
- Preparata da: [[marco-rossi]] · Aggiornamento 2026: [[laura-conti]]
- Fatture: [[fattura-n-2022-1a]], [[fattura-n-2022-1b]], [[fattura-n-2022-1c]], [[fattura-n-2022-1d]]
- Upsell collegato: [[offerta-2026-6]]

## Incongruenze
- [[artigiani-budget-durata-e-numerazione-fatture]]
- [[artigiani-offerta-2026-6-vs-retainer]]
