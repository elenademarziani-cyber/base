---
tipo: indice
argomento: indice offerte e contratti (vista derivata)
fonti:
  - raw/connettori/google-drive/README.md
ultimo_aggiornamento: 2026-10-20
---
# Indice offerte e contratti

Vista derivata dalle note proprietarie; importi in euro IVA esclusa. Gli stati sono quelli documentati (export 2026-07-02 e email), non ricalcolati a oggi.

## Offerte
| Nota | Cliente | Importo | Data | Stato documentato | Validità |
|---|---|---|---|---|---|
| [[offerta-2022-1]] | [[cliente-artigiani-del-gusto]] | 200 (al mese) | 2022-12-15 | accettata | nessuna scadenza autonoma |
| [[offerta-2025-1]] | [[cliente-bloome-cosmetics]] | 5200 | 2025-10-20 | accettata | 30 giorni |
| [[offerta-2025-2]] | [[cliente-nordvik-italia]] | 2100 | 2025-12-10 | accettata | 30 giorni |
| [[offerta-2025-3]] | [[cliente-bloome-cosmetics]] | 1200 | 2025-12-20 | accettata | 30 giorni |
| [[offerta-2026-1]] | [[cliente-helios-energia]] | 12500 | 2026-01-10 | accettata | 30 giorni |
| [[offerta-2026-2]] | [[cliente-studiolex]] | 3600 | 2026-02-10 | accettata | 30 giorni |
| [[offerta-2026-3]] | [[cliente-verdalia]] | 4500 | 2026-03-20 | accettata | 30 giorni |
| [[offerta-2026-4]] | [[cliente-helios-energia]] | 1800 | 2026-04-12 | in-sospeso | 45 giorni (fino al 2026-05-27) |
| [[offerta-2026-5]] | [[cliente-nordvik-italia]] | 6800 | 2026-04-15 | accettata | 30 giorni |
| [[offerta-2026-6]] | [[cliente-artigiani-del-gusto]] | 600 | 2026-05-08 | accettata | 30 giorni |
| [[offerta-2026-7]] | [[cliente-verdalia]] | 3200 | 2026-05-10 | accettata | 30 giorni |
| [[offerta-2026-8]] | [[cliente-bloome-cosmetics]] | 1800 | 2026-06-03 | rifiutata | 30 giorni (fino al 2026-07-03) |
| [[offerta-2026-9]] | [[cliente-studiolex]] | 2200 | 2026-06-10 | in-valutazione | 30 giorni (fino al 2026-07-10) |
| [[offerta-2026-10]] | [[cliente-ferro-forma]] | 2800 | 2026-06-26 | accettata | 60 giorni (fino al 2026-08-25) |

## Contratti
| Nota | Cliente | Formula | Firma | Rinnovo | Preavviso |
|---|---|---|---|---|---|
| [[contratto-verdalia]] | [[cliente-verdalia]] | quadro | 2022-03 | automatico annuale (ultimo marzo 2026) | 60 giorni |
| [[contratto-helios-energia]] | [[cliente-helios-energia]] | quadro | 2023-06 | annuale (ultimo giugno 2026) | 90 giorni |
| [[contratto-nordvik-italia]] | [[cliente-nordvik-italia]] | sow | 2022-09 | nessun rinnovo automatico | non documentato |
| [[contratto-studiolex]] | [[cliente-studiolex]] | progetto | 2024-02 | non documentato | non documentato |
| [[contratto-bloome-cosmetics]] | [[cliente-bloome-cosmetics]] | progetto | 2024-10-10 (vedi incongruenza) | non previsto | 30 giorni (recesso cliente) |
| [[contratto-artigiani-del-gusto]] | [[cliente-artigiani-del-gusto]] | retainer | 2023-01 | tacito mensile dopo 6 mesi minimi | 30 giorni |

[[cliente-ferro-forma]] non ha contratto nell'export.
