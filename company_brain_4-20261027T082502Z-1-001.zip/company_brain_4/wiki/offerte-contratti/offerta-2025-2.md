---
tipo: offerta
numero: 2025-2
cliente: "[[cliente-nordvik-italia]]"
data: 2025-12-10
importo: 2100
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[marco-rossi]]"
progetto: "[[case-study-produzione-nordvik]]"
fatture: ["[[fattura-n-2025-2a]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2025-2 - Case Study Produzione.md"
  - raw/connettori/email/2025-12-10_1100_offerta-2025-2-case-study-produzione.md
  - raw/connettori/email/2025-12-20_1020_re-offerta-2025-2-case-study-produzione.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2025-2 - Case Study Produzione

## Sintesi
- Importo: 2.100 euro IVA esclusa.
- Contenuto: 3 case study di clienti Nordvik (interviste, stesura, impaginazione PDF) e landing page dedicata per pubblicazione e raccolta contatti.
- Tempistiche: date di avvio e fine nel progetto [[case-study-produzione-nordvik]]; kickoff a inizio gennaio per confermare i clienti da intervistare.
- Pagamento: 100% alla consegna; 30 giorni data fattura.
- Stato: inviata il 2025-12-10; accettata il 2025-12-20 da L. Amendola, che la formalizza con un SOW dedicato (il SOW non è nel Drive: `non documentato`).

## Collegamenti
- Cliente: [[cliente-nordvik-italia]] · Contratto: [[contratto-nordvik-italia]] · Progetto: [[case-study-produzione-nordvik]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[luca-amendola]]
- Fatture: [[fattura-n-2025-2a]]
