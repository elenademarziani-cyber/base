---
tipo: offerta
numero: 2026-8
cliente: "[[cliente-bloome-cosmetics]]"
data: 2026-06-03
importo: 1800
stato_documentato: rifiutata
validita: 30 giorni dalla data di emissione (fino al 2026-07-03)
preparata_da: "[[marco-rossi]] (proposta), [[giulio-marino]] (dati a supporto)"
progetto: "[[youtube-shorts-bloome]]"
fatture: []
fonti:
  - "raw/connettori/google-drive/Clienti/Bloome Cosmetics/Offerte/Offerta 2026-8 - Estensione TikTok su YouTube Shorts.md"
  - raw/connettori/email/2026-06-03_0950_offerta-2026-8-estensione-tiktok-su-youtube-shorts.md
  - raw/connettori/email/2026-06-17_1810_re-offerta-2026-8-estensione-tiktok-su-youtube-shorts.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-8 - Estensione TikTok su YouTube Shorts

## Sintesi
- Importo: 1.800 euro IVA esclusa.
- Tipo: upsell, non collegata a un progetto avviato; se accettata sarebbe partita come estensione separata.
- Contenuto: adattamento dei video short-form TikTok per YouTube Shorts e report performance comparativo TikTok vs YouTube Shorts. Dati a supporto: +180% follower TikTok in 6 mesi.
- Tempistiche: avvio da concordare dopo l'accettazione.
- Pagamento: 50% all'avvio, 50% alla consegna; 30 giorni data fattura.
- Stato: inviata il 2026-06-03; rifiutata il 2026-06-17 dalla CEO ("per ora non procediamo", budget concentrato su TikTok, possibile riparlarne più avanti).

## Collegamenti
- Cliente: [[cliente-bloome-cosmetics]] · Contratto: [[contratto-bloome-cosmetics]] · Progetto: [[youtube-shorts-bloome]]
- Preparata da: [[marco-rossi]], [[giulio-marino]] · Referente cliente: [[alessia-neri]]
- Fatture: nessuna
