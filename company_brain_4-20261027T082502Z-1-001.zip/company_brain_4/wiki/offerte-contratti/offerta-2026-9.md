---
tipo: offerta
numero: 2026-9
cliente: "[[cliente-studiolex]]"
data: 2026-06-10
importo: 2200
stato_documentato: in-valutazione
validita: 30 giorni dalla data di emissione (fino al 2026-07-10)
preparata_da: "[[marco-rossi]]"
progetto: "[[video-testimonianze-studiolex]]"
fatture: []
fonti:
  - "raw/connettori/google-drive/Clienti/StudioLex/Offerte/Offerta 2026-9 - Produzione Video Testimonianze Clienti.md"
  - raw/connettori/email/2026-06-10_1630_offerta-2026-9-produzione-video-testimonianze-clienti.md
  - raw/connettori/email/2026-06-16_1210_re-offerta-2026-9-produzione-video-testimonianze-clienti.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-9 - Produzione Video Testimonianze Clienti

## Sintesi
- Importo: 2.200 euro IVA esclusa.
- Tipo: upsell, non collegata a un progetto in corso; se accettata partirebbe come attività separata.
- Contenuto: 3 video testimonianza di clienti in formato breve per LinkedIn e sito (interviste, riprese, montaggio, sottotitoli); testi e liberatorie soggetti a validazione legale interna dello Studio prima di ogni pubblicazione.
- Tempistiche: avvio da concordare dopo l'accettazione, compatibilmente con i clienti da intervistare e la validazione legale.
- Pagamento: 50% all'avvio, 50% alla consegna; 30 giorni data fattura.
- Stato: inviata il 2026-06-10; il 2026-06-16 lo Studio la trova interessante ma chiede tempo per la validazione interna del team legale. Nessuna accettazione o rifiuto documentati.

## Collegamenti
- Cliente: [[cliente-studiolex]] · Contratto: [[contratto-studiolex]] · Progetto: [[video-testimonianze-studiolex]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[chiara-messina]]
- Fatture: nessuna
