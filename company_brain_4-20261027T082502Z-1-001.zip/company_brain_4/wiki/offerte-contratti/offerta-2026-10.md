---
tipo: offerta
numero: 2026-10
cliente: "[[cliente-ferro-forma]]"
data: 2026-06-26
importo: 2800
stato_documentato: accettata
validita: 60 giorni dalla data di emissione (fino al 2026-08-25)
preparata_da: "[[marco-rossi]]"
progetto: "[[content-linkedin-newsletter-ferro-forma]]"
fatture: []
fonti:
  - "raw/connettori/google-drive/Clienti/Ferro & Forma/Offerte/Offerta 2026-10 - Content LinkedIn e Newsletter B2B.md"
  - raw/connettori/email/2026-06-26_1130_proposta-commerciale-strategia-linkedin-e-newsletter.md
  - raw/connettori/email/2026-06-30_1012_re-proposta-commerciale-strategia-linkedin-e-newsletter.md
  - raw/connettori/email/2026-06-30_1102_re-proposta-commerciale-strategia-linkedin-e-newsletter.md
  - raw/connettori/email/2026-10-20_1015_re-proposta-commerciale-strategia-linkedin-e-newsletter.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-10 - Content LinkedIn e Newsletter B2B

## Sintesi
- Importo: 2.800 euro IVA esclusa.
- Contenuto: strategia contenuti LinkedIn, 24 post al mese (copy e visual), newsletter B2B mensile, report trimestrale su LinkedIn e newsletter.
- Tempistiche: data di avvio da definire; kickoff entro due settimane dalla firma (il cliente ha chiesto di fissarlo).
- Pagamento: 50% all'avvio, 50% alla consegna; 30 giorni data fattura.
- Stato: primo contatto nato da segnalazione, call conoscitiva a giugno 2026; offerta inviata il 2026-06-26. Il 2026-06-30 G. Testa risponde che la stanno valutando e chiede un secondo incontro a Brescia il 2026-07-28 (fissato alle 10:30). Il 2026-10-20 G. Testa accetta l'offerta (email a M. Rossi, in copia L. Conti) e chiede il contratto da firmare e di fissare il kickoff. L'accettazione arriva dopo la scadenza della validità (2026-08-25): da confermare che prezzo e condizioni restino quelli dell'offerta.

## Collegamenti
- Cliente: [[cliente-ferro-forma]] · Progetto: [[content-linkedin-newsletter-ferro-forma]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[giorgio-testa]]
- Fatture: nessuna · Contratto: nessuno (richiesto dal cliente il 2026-10-20, da inviare)

## Incongruenze
- [[ferro-forma-assente-in-fatture-in-cloud]]
