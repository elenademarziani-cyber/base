---
tipo: offerta
numero: 2025-1
cliente: "[[cliente-bloome-cosmetics]]"
data: 2025-10-20
importo: 5200
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[marco-rossi]]"
progetto: "[[tiktok-launch-bloome]]"
fatture: ["[[fattura-n-2025-1a]]", "[[fattura-n-2025-1b]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Bloome Cosmetics/Offerte/Offerta 2025-1 - TikTok Launch.md"
  - raw/connettori/email/2025-10-20_1045_offerta-2025-1-tiktok-launch.md
  - raw/connettori/email/2025-10-29_2105_re-offerta-2025-1-tiktok-launch.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2025-1 - TikTok Launch

## Sintesi
- Importo: 5.200 euro IVA esclusa.
- Contenuto: strategia TikTok (posizionamento, format, piano editoriale), 40 video short-form in batch, report performance mensile.
- Tempistiche: date di avvio e fine nel progetto [[tiktok-launch-bloome]].
- Pagamento: 50% alla firma, 50% alla milestone dei 6 mesi di progetto; 30 giorni data fattura.
- Stato: inviata il 2025-10-20; accettata dalla CEO il 2025-10-29, con richiesta di kickoff il 5 novembre.
- Il contratto a progetto con Bloome riporta firma ottobre 2024, cioè un anno prima di questa offerta (non risolto qui).

## Collegamenti
- Cliente: [[cliente-bloome-cosmetics]] · Contratto: [[contratto-bloome-cosmetics]] · Progetto: [[tiktok-launch-bloome]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[alessia-neri]]
- Fatture: [[fattura-n-2025-1a]], [[fattura-n-2025-1b]]

## Incongruenze
- [[contratto-bloome-2024-vs-offerta-2025]]
- [[bloome-video-previsti-vs-dlv]]
- [[dlv-029-oltre-fine-tiktok-launch]]
