---
tipo: contratto
cliente: "[[cliente-bloome-cosmetics]]"
formula: progetto
firma: 2024-10-10 (versione firmata inviata dal cliente; documento datato ottobre 2024)
durata: pari al progetto, fino alla consegna dei deliverable
rinnovo: non previsto (nessun accordo quadro)
preavviso_disdetta: 30 giorni (recesso anticipato del cliente)
clausole_chiave:
  - recesso anticipato (way-out) del cliente con 30 giorni di preavviso, richiesto in quanto startup
  - in caso di recesso il cliente paga attività e deliverable fino alla data di efficacia
  - nessun accordo quadro, progetti successivi con accordi separati
  - video di proprietà del cliente dopo il saldo; uso a portfolio consentito
  - foro di Milano
fonti:
  - "raw/connettori/google-drive/Clienti/Bloome Cosmetics/Contratti/Contratto a progetto Bloome Cosmetics - TikTok Launch.md"
  - raw/connettori/email/2024-10-07_1015_contratto-richiesta-clausola-di-uscita-anticipata.md
  - raw/connettori/email/2024-10-08_0940_re-contratto-richiesta-clausola-di-uscita-anticipata.md
  - raw/connettori/email/2024-10-10_1800_re-contratto-richiesta-clausola-di-uscita-anticipata.md
ultimo_aggiornamento: 2026-10-20
---
# Contratto a progetto Bloome Cosmetics - TikTok Launch

## Sintesi
- Contratto a progetto per TikTok Launch (strategia, video short-form, reportistica); corrispettivo e tranche sono quelli dell'offerta accettata.
- Il way-out a 30 giorni è stato chiesto dalla CEO il 2024-10-07 e inserito da Musa AI nella versione 2 (2024-10-08); firmato il 2024-10-10.
- Date: il contratto e le email sono dell'ottobre 2024, mentre l'offerta 2025-1 (TikTok Launch) è del 2025-10-20 e accettata il 2025-10-29. Il contratto dichiara di riferirsi a un'offerta già accettata. La discrepanza non è risolta qui.
- Nessun accordo quadro: [[offerta-2025-3]] e [[offerta-2026-8]] non hanno un contratto proprio nell'export (`non documentato`).

## Collegamenti
- Cliente: [[cliente-bloome-cosmetics]] · Referente: [[alessia-neri]]
- Offerte: [[offerta-2025-1]], [[offerta-2025-3]], [[offerta-2026-8]]

## Incongruenze
- [[contratto-bloome-2024-vs-offerta-2025]]
