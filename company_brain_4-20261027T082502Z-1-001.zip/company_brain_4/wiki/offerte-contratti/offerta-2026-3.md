---
tipo: offerta
numero: 2026-3
cliente: "[[cliente-verdalia]]"
data: 2026-03-20
importo: 4500
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[laura-conti]]"
progetto: "[[automazione-email-flow-verdalia]]"
fatture: ["[[fattura-n-2026-3a]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Verdalia/Offerte/Offerta 2026-3 - Automazione Email Flow.md"
  - raw/connettori/email/2026-03-20_1630_offerta-2026-3-automazione-email-flow.md
  - raw/connettori/email/2026-04-08_1010_re-offerta-2026-3-automazione-email-flow.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-3 - Automazione Email Flow

## Sintesi
- Importo: 4.500 euro IVA esclusa.
- Contenuto: tre flow email automatizzati (welcome, abandoned cart, post-purchase) configurati e testati sulla piattaforma del cliente, più 8 template personalizzati con test A/B sulle subject line.
- Tempistiche: date di avvio e fine nel progetto [[automazione-email-flow-verdalia]]; kickoff entro la prima settimana dall'accettazione.
- Pagamento: 50% di acconto all'avvio, 50% a saldo; 30 giorni data fattura.
- Stato: inviata il 2026-03-20; accettata il 2026-04-08 da S. Bianchi (kickoff proposto il 10 aprile); formalizzata come SOW nel contratto quadro (SOW non nel Drive: `non documentato`).

## Collegamenti
- Cliente: [[cliente-verdalia]] · Contratto: [[contratto-verdalia]] · Progetto: [[automazione-email-flow-verdalia]]
- Preparata da: [[laura-conti]] · Referente cliente: [[sofia-bianchi]]
- Fatture: [[fattura-n-2026-3a]]

## Incongruenze
- [[saldo-2026-3-verdalia-non-fatturato]]
