---
tipo: offerta
numero: 2026-5
cliente: "[[cliente-nordvik-italia]]"
data: 2026-04-15
importo: 6800
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[marco-rossi]]"
progetto: "[[linkedin-lead-gen-nordvik]]"
fatture: ["[[fattura-n-2026-5a]]", "[[fattura-n-2026-5b]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Nordvik Italia/Offerte/Offerta 2026-5 - LinkedIn Lead Gen.md"
  - raw/connettori/email/2026-04-15_1510_offerta-2026-5-linkedin-lead-gen.md
  - raw/connettori/email/2026-04-28_1230_re-offerta-2026-5-linkedin-lead-gen.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-5 - LinkedIn Lead Gen

## Sintesi
- Importo: 6.800 euro IVA esclusa.
- Contenuto: strategia contenuti LinkedIn, 24 post (copy e visual), report lead mensile, dashboard analytics. KPI principale: MQL generati.
- Tempistiche: date di avvio e fine nel progetto [[linkedin-lead-gen-nordvik]].
- Pagamento: 50% di acconto all'avvio, 25% al SAL intermedio, 25% a saldo; 30 giorni data fattura.
- Stato: inviata il 2026-04-15; accettata il 2026-04-28 da L. Amendola con target di 15 MQL/mese concordato nella call del 25 aprile; SOW dedicato come di consueto (non nel Drive: `non documentato`).

## Collegamenti
- Cliente: [[cliente-nordvik-italia]] · Contratto: [[contratto-nordvik-italia]] · Progetto: [[linkedin-lead-gen-nordvik]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[luca-amendola]]
- Fatture presenti: [[fattura-n-2026-5a]], [[fattura-n-2026-5b]] (mancano quelle del terzo pagamento previsto)

## Incongruenze
- [[saldo-2026-5-nordvik-non-fatturato]]
- [[nordvik-post-linkedin-senza-dlv]]
