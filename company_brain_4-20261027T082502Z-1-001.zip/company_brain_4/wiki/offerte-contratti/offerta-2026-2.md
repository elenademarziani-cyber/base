---
tipo: offerta
numero: 2026-2
cliente: "[[cliente-studiolex]]"
data: 2026-02-10
importo: 3600
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[marco-rossi]]"
progetto: "[[content-compliance-studiolex]]"
fatture: ["[[fattura-n-2026-2a]]", "[[fattura-n-2026-2b]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/StudioLex/Offerte/Offerta 2026-2 - Content Compliance.md"
  - raw/connettori/email/2026-02-10_1000_offerta-2026-2-content-compliance.md
  - raw/connettori/email/2026-02-20_1645_re-offerta-2026-2-content-compliance.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-2 - Content Compliance

## Sintesi
- Importo: 3.600 euro IVA esclusa.
- Contenuto: content calendar legale-compliant, 16 articoli blog (consegna in lotti), 20 post LinkedIn; ogni contenuto passa dalla validazione legale interna dello Studio prima della pubblicazione.
- Tempistiche: date di avvio e fine nel progetto [[content-compliance-studiolex]]; le consegne tengono conto dei tempi di approvazione dello Studio.
- Pagamento: 50% di acconto all'avvio, 50% a saldo; 45 giorni data fattura.
- Stato: inviata il 2026-02-10; accettata il 2026-02-20 dalla Managing Partner (kickoff a inizio marzo).

## Collegamenti
- Cliente: [[cliente-studiolex]] · Contratto: [[contratto-studiolex]] · Progetto: [[content-compliance-studiolex]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[chiara-messina]]
- Fatture: [[fattura-n-2026-2a]], [[fattura-n-2026-2b]]

## Incongruenze
- [[studiolex-articoli-previsti-vs-dlv]]
