---
tipo: offerta
numero: 2025-3
cliente: "[[cliente-bloome-cosmetics]]"
data: 2025-12-20
importo: 1200
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[giulio-marino]]"
progetto: "[[analisi-dati-q1-bloome]]"
fatture: ["[[fattura-n-2025-3a]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Bloome Cosmetics/Offerte/Offerta 2025-3 - Analisi Dati Q1.md"
  - raw/connettori/email/2025-12-20_1120_offerta-2025-3-analisi-dati-q1.md
  - raw/connettori/email/2025-12-28_1630_re-offerta-2025-3-analisi-dati-q1.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2025-3 - Analisi Dati Q1

## Sintesi
- Importo: 1.200 euro IVA esclusa.
- Contenuto: report analitico Q1 su canali e contenuti, dashboard performance consultabile dal cliente, raccomandazioni strategiche per le attività social successive.
- Tempistiche: date di avvio e fine nel progetto [[analisi-dati-q1-bloome]].
- Pagamento: 100% alla consegna; 30 giorni data fattura.
- Stato: inviata il 2025-12-20; accettata il 2025-12-28 dalla CEO ("partiamo a gennaio").

## Collegamenti
- Cliente: [[cliente-bloome-cosmetics]] · Contratto: [[contratto-bloome-cosmetics]] · Progetto: [[analisi-dati-q1-bloome]]
- Preparata da: [[giulio-marino]] · Referente cliente: [[alessia-neri]]
- Fatture: [[fattura-n-2025-3a]]
