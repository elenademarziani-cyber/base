---
tipo: offerta
numero: 2026-1
cliente: "[[cliente-helios-energia]]"
data: 2026-01-10
importo: 12500
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[marco-rossi]]"
progetto: "[[rebranding-digitale-helios]]"
fatture: ["[[fattura-n-2026-1a]]", "[[fattura-n-2026-1b]]", "[[fattura-n-2026-1c]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Helios Energia/Offerte/Offerta 2026-1 - Rebranding Digitale.md"
  - raw/connettori/email/2026-01-10_1130_offerta-2026-1-rebranding-digitale.md
  - raw/connettori/email/2026-01-25_1940_re-offerta-2026-1-rebranding-digitale.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-1 - Rebranding Digitale

## Sintesi
- Importo: 12.500 euro IVA esclusa.
- Contenuto: nuova content strategy, tone of voice guide, 3 mesi di contenuti pilota (tre rilasci mensili), dashboard KPI; ogni blocco con review degli stakeholder Helios prima della consegna definitiva.
- Tempistiche: date di avvio e fine nel progetto [[rebranding-digitale-helios]]; kickoff con tutti gli stakeholder nella prima settimana di febbraio.
- Pagamento: condizioni enterprise a SAL in tre tranche (acconto all'avvio, SAL 2, SAL 3), 60 giorni data fattura; gli importi delle tranche sono nelle note fattura.
- Stato: inviata il 2026-01-10; accettata il 2026-01-25 da M. Colombo, attivata con SOW nell'ambito del contratto quadro (SOW non nel Drive: `non documentato`).

## Collegamenti
- Cliente: [[cliente-helios-energia]] · Contratto: [[contratto-helios-energia]] · Progetto: [[rebranding-digitale-helios]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[marta-colombo]]
- Fatture: [[fattura-n-2026-1a]], [[fattura-n-2026-1b]], [[fattura-n-2026-1c]]
