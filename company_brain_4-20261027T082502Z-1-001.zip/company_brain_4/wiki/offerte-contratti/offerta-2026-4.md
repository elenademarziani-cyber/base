---
tipo: offerta
numero: 2026-4
cliente: "[[cliente-helios-energia]]"
data: 2026-04-12
importo: 1800
stato_documentato: in-sospeso
validita: 45 giorni dalla data di emissione (fino al 2026-05-27)
preparata_da: "[[marco-rossi]]"
progetto: "[[newsletter-trimestrale-helios]]"
fatture: []
fonti:
  - "raw/connettori/google-drive/Clienti/Helios Energia/Offerte/Offerta 2026-4 - Newsletter Trimestrale.md"
  - raw/connettori/email/2026-04-12_1715_offerta-2026-4-newsletter-trimestrale.md
  - raw/connettori/email/2026-06-27_1005_sollecito-conferma-budget-newsletter-trimestrale.md
  - raw/connettori/email/2026-06-29_0852_re-sollecito-conferma-budget-newsletter-trimestrale.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-4 - Newsletter Trimestrale

## Sintesi
- Importo: 1.800 euro IVA esclusa.
- Contenuto: newsletter istituzionale per stakeholder e investitori, 4 numeri l'anno; per ogni numero piano contenuti, redazione, impaginazione sul template (coerente col rebranding) e revisione con il team Helios.
- Tempistiche: avvio previsto a settembre 2026, primo numero nel trimestre autunnale.
- Pagamento: 50% all'avvio, 50% alla consegna; 30 giorni data fattura.
- Stato: inviata il 2026-04-12; nessuna accettazione. Il 2026-06-27 Musa AI ha sollecitato la conferma del budget; il 2026-06-29 M. Colombo risponde che attende l'ok del CFO. Nessuna data di accettazione o rifiuto documentata; la validità indicata nell'offerta risulta scaduta al 2026-05-27 (dedotto dalla data di emissione).

## Collegamenti
- Cliente: [[cliente-helios-energia]] · Contratto: [[contratto-helios-energia]] · Progetto: [[newsletter-trimestrale-helios]]
- Preparata da: [[marco-rossi]] · Referente cliente: [[marta-colombo]]
- Fatture: nessuna

## Incongruenze
- [[helios-newsletter-stato-offerta-vs-calendario]]
