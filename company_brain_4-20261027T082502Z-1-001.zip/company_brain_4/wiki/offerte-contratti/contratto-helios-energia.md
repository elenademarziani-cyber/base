---
tipo: contratto
cliente: "[[cliente-helios-energia]]"
formula: quadro
firma: 2023-06 (firmato dal cliente, email del 2023-06-01)
durata: 12 mesi dalla sottoscrizione
rinnovo: annuale; rinnovato a giugno 2026 (firmato dal cliente il 2026-06-03), prossimo rinnovo giugno 2027
preavviso_disdetta: almeno 90 giorni rispetto alla data di rinnovo
clausole_chiave:
  - esclusiva di settore (nessun altro cliente diretto concorrente nelle energie rinnovabili; violazione = grave inadempimento)
  - NDA rafforzato allegato (anche dopo la cessazione; niente referenze né pubblicazioni senza autorizzazione scritta)
  - progetti regolati da SOW dedicati
  - materiali al cliente dopo il saldo
  - foro di Torino
fonti:
  - "raw/connettori/google-drive/Clienti/Helios Energia/Contratti/Contratto quadro Helios Energia - Musa AI.md"
  - raw/connettori/email/2023-06-01_1620_contratto-quadro-helios-energia-musa-ai-firmato.md
  - raw/connettori/email/2026-06-01_1100_rinnovo-annuale-contratto-quadro-helios-musa-ai.md
  - raw/connettori/email/2026-06-03_1420_re-rinnovo-annuale-contratto-quadro-helios-musa-ai.md
ultimo_aggiornamento: 2026-10-20
---
# Contratto quadro Helios Energia

## Sintesi
- Contratto quadro per servizi di comunicazione e marketing digitale; ogni progetto è attivato con un SOW che richiama l'offerta accettata.
- Durata 12 mesi con rinnovo annuale; disdetta con almeno 90 giorni di preavviso rispetto alla data di rinnovo.
- Vincolo principale: esclusiva nelle energie rinnovabili, che limita l'acquisizione di clienti concorrenti. L'NDA rafforzato (allegato) copre informazioni commerciali, finanziarie, tecniche e di investitori e stakeholder.
- Rinnovo 2026: rinnovato a giugno 2026 per un'altra annualità, clausole invariate (annotazione del 2026-06-30); prossimo rinnovo giugno 2027, termine di disdetta da calcolare in timeline.
- SOW e testo dell'NDA allegati non sono nel Drive: `non documentato`.

## Collegamenti
- Cliente: [[cliente-helios-energia]] · Referente: [[marta-colombo]]
- Offerte sotto il quadro: [[offerta-2026-1]], [[offerta-2026-4]]
