---
tipo: offerta
numero: 2026-7
cliente: "[[cliente-verdalia]]"
data: 2026-05-10
importo: 3200
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[laura-conti]]"
progetto: "[[content-q3-social-verdalia]]"
fatture: ["[[fattura-n-2026-7a]]"]
fonti:
  - "raw/connettori/google-drive/Clienti/Verdalia/Offerte/Offerta 2026-7 - Content Q3 Social.md"
  - raw/connettori/email/2026-05-10_1820_offerta-2026-7-content-q3-social.md
  - raw/connettori/email/2026-05-25_0955_re-offerta-2026-7-content-q3-social.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-7 - Content Q3 Social

## Sintesi
- Importo: 3.200 euro IVA esclusa.
- Contenuto: content calendar trimestrale, 36 post Instagram/Facebook in batch mensili da 12, 4 reel dedicati alla collezione sostenibile autunno.
- Tempistiche: date di avvio e fine nel progetto [[content-q3-social-verdalia]].
- Pagamento: fatturazione anticipata trimestrale all'avvio; 30 giorni data fattura.
- Stato: inviata il 2026-05-10; accettata il 2026-05-25 da S. Bianchi ("partiamo da giugno").

## Collegamenti
- Cliente: [[cliente-verdalia]] · Contratto: [[contratto-verdalia]] · Progetto: [[content-q3-social-verdalia]]
- Preparata da: [[laura-conti]] · Referente cliente: [[sofia-bianchi]]
- Fatture: [[fattura-n-2026-7a]]
