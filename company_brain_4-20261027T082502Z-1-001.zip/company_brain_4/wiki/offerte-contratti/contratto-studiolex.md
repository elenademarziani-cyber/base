---
tipo: contratto
cliente: "[[cliente-studiolex]]"
formula: progetto
firma: 2024-02 (sottoscritto dallo Studio, email del 2024-02-19)
durata: non documentato (il contratto rimanda all'offerta accettata)
rinnovo: non documentato
preavviso_disdetta: non documentato
clausole_chiave:
  - validazione legale interna obbligatoria prima di ogni pubblicazione
  - penale per pubblicazione senza validazione (importo nell'Allegato economico, non documentato)
  - rispetto di tone of voice e deontologia forense
  - riservatezza su Studio e assistiti
  - foro di Roma
fonti:
  - "raw/connettori/google-drive/Clienti/StudioLex/Contratti/Contratto a progetto StudioLex - Febbraio 2024.md"
  - raw/connettori/email/2024-02-19_1200_contratto-studiolex-musa-ai-firmato.md
ultimo_aggiornamento: 2026-10-20
---
# Contratto a progetto StudioLex

## Sintesi
- Contratto a progetto per contenuti di comunicazione (blog, LinkedIn, materiali correlati); contenuti, tempi e corrispettivo sono nell'offerta accettata, che ne fa parte.
- Clausola centrale: ogni contenuto va in bozza al referente dello Studio e può essere pubblicato solo con approvazione scritta. La Managing Partner l'ha definita essenziale nell'email di firma.
- Penale per pubblicazione senza validazione: misura rimandata a un Allegato economico che non è presente nell'export: `non documentato`. Durata effettiva del contratto, rinnovo e recesso non sono indicati: `non documentato`.
- Nessun accordo quadro (contratto a progetto); le offerte successive richiamano il processo di validazione.

## Collegamenti
- Cliente: [[cliente-studiolex]] · Referente: [[chiara-messina]]
- Offerte: [[offerta-2026-2]], [[offerta-2026-9]]

## Incongruenze
- [[studiolex-penale-e-durata-non-documentate]]
