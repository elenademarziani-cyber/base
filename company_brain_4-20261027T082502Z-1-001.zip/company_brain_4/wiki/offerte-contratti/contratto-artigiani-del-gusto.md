---
tipo: contratto
cliente: "[[cliente-artigiani-del-gusto]]"
formula: retainer
firma: 2023-01 (firmato dal cliente il 2023-01-12)
durata: minima iniziale di 6 mesi dalla sottoscrizione
rinnovo: tacito di mese in mese dopo il periodo minimo
preavviso_disdetta: 30 giorni (recesso scritto, dopo il periodo minimo)
clausole_chiave:
  - retainer mensile fatturato il 1° del mese, pagamento a 15 giorni
  - recesso con 30 giorni di preavviso dopo i 6 mesi minimi
  - attività non comprese (es. shooting fotografici, campagne) solo con offerte separate
  - contenuti pubblicati di proprietà del cliente; riservatezza reciproca
  - foro di Como
fonti:
  - "raw/connettori/google-drive/Clienti/Artigiani del Gusto/Contratti/Contratto retainer social - Artigiani del Gusto.md"
  - raw/connettori/email/2023-01-12_1115_re-proposta-retainer-social-offerta-2022-1.md
ultimo_aggiornamento: 2026-10-20
---
# Contratto retainer social Artigiani del Gusto

## Sintesi
- Servizio Social Growth: gestione di Instagram e Facebook con 12 post al mese, come da [[offerta-2022-1]] che è parte integrante del contratto; il retainer e le sue revisioni sono nell'offerta (revisioni da concordare per iscritto).
- Durata minima 6 mesi, poi rinnovo tacito mensile: il rapporto non ha una scadenza fissa, quindi la fine del ciclo 2026 indicata nella nota di aggiornamento dell'offerta non è una scadenza contrattuale.
- Recesso con 30 giorni di preavviso solo dopo il periodo minimo.
- Art. 6: attività aggiuntive come shooting fotografici vanno in offerte separate, cosa rilevante per [[offerta-2026-6]].

## Collegamenti
- Cliente: [[cliente-artigiani-del-gusto]] · Referente: [[tommaso-ferraro]]
- Offerte: [[offerta-2022-1]], [[offerta-2026-6]]

## Incongruenze
- [[artigiani-offerta-2026-6-vs-retainer]]
- [[artigiani-budget-durata-e-numerazione-fatture]]
