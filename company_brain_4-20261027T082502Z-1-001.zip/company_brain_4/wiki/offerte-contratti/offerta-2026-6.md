---
tipo: offerta
numero: 2026-6
cliente: "[[cliente-artigiani-del-gusto]]"
data: 2026-05-08
importo: 600
stato_documentato: accettata
validita: 30 giorni dalla data di emissione
preparata_da: "[[laura-conti]]"
progetto: "[[fotografia-prodotto-artigiani]]"
fatture: []
fonti:
  - "raw/connettori/google-drive/Clienti/Artigiani del Gusto/Offerte/Offerta 2026-6 - Fotografia Prodotto.md"
  - raw/connettori/email/2026-05-08_1400_offerta-2026-6-fotografia-prodotto.md
  - raw/connettori/email/2026-05-15_1310_re-offerta-2026-6-fotografia-prodotto.md
  - raw/connettori/email/2026-05-18_0930_re-offerta-2026-6-fotografia-prodotto.md
ultimo_aggiornamento: 2026-10-20
---
# Offerta 2026-6 - Fotografia Prodotto

## Sintesi
- Importo: 600 euro IVA esclusa, una tantum.
- Tipo: upsell sul retainer social esistente, non un nuovo progetto autonomo.
- Contenuto: shooting prodotto in studio, 30 scatti post-prodotti in alta risoluzione per social ed ecommerce; prodotti campione ritirati presso il cliente.
- Tempistiche: shooting a luglio 2026 (data da concordare), consegna entro due settimane dallo shooting.
- Pagamento: 50% all'avvio, 50% alla consegna; 30 giorni data fattura.
- Stato: inviata il 2026-05-08; accettata il 2026-05-15 da T. Ferraro. Il 2026-05-18 L. Conti scrive che da giugno l'attività fotografica viene inclusa nel retainer mensile.
- Nessuna fattura con Rif. offerta 2026-6 nell'export.

## Collegamenti
- Cliente: [[cliente-artigiani-del-gusto]] · Contratto: [[contratto-artigiani-del-gusto]] · Progetto: [[fotografia-prodotto-artigiani]]
- Preparata da: [[laura-conti]] · Referente cliente: [[tommaso-ferraro]]
- Offerta madre: [[offerta-2022-1]]

## Incongruenze
- [[artigiani-offerta-2026-6-vs-retainer]]
