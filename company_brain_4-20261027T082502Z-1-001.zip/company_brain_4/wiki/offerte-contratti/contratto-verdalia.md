---
tipo: contratto
cliente: "[[cliente-verdalia]]"
formula: quadro
firma: 2022-03 (copia controfirmata inviata il 2022-03-10)
durata: annuale dalla sottoscrizione
rinnovo: automatico di anno in anno; rinnovato a marzo 2026, prossima scadenza marzo 2027
preavviso_disdetta: 60 giorni prima della scadenza annuale
clausole_chiave:
  - nessuna esclusiva di settore
  - riservatezza reciproca (NDA semplice)
  - progetti regolati da SOW dedicati (prevale il SOW)
  - materiali al cliente dopo il saldo; Musa AI può citare il cliente come referenza
  - foro di Milano
fonti:
  - "raw/connettori/google-drive/Clienti/Verdalia/Contratti/Contratto quadro Verdalia - Musa AI.md"
  - raw/connettori/email/2022-03-10_1500_contratto-quadro-musa-ai-verdalia-controfirmato.md
  - raw/connettori/email/2026-03-10_1030_rinnovo-contratto-quadro-verdalia-musa-ai.md
ultimo_aggiornamento: 2026-10-20
---
# Contratto quadro Verdalia

## Sintesi
- Contratto quadro per servizi di marketing digitale (content, automazione email, social strategy, analisi dati); ogni progetto è formalizzato con un SOW che richiama l'offerta accettata.
- Durata annuale con rinnovo automatico; la disdetta non pregiudica i SOW in corso, salvo accordo scritto diverso.
- Rinnovo 2026: avvenuto in automatico a marzo 2026 senza disdetta, condizioni invariate (annotazione del 2026-03-16 ed email del 2026-03-10); nessuna firma necessaria.
- Prossima scadenza marzo 2027; disdetta da comunicare almeno 60 giorni prima (data esatta del termine: vedi timeline).
- Nessuna esclusiva: Musa AI può servire concorrenti di Verdalia.
- I SOW dei singoli progetti non sono nel Drive: `non documentato`.

## Collegamenti
- Cliente: [[cliente-verdalia]] · Referente: [[sofia-bianchi]]
- Offerte sotto il quadro: [[offerta-2026-3]], [[offerta-2026-7]]
