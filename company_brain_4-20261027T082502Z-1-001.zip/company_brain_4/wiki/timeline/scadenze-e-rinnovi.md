---
tipo: timeline
argomento: scadenze, rinnovi e disdette calcolate rispetto al 2026-07-03
fonti:
  - raw/connettori/calendario/2027-01-08_termine-disdetta-contratto-verdalia.md
  - raw/connettori/calendario/2027-03-01_termine-disdetta-contratto-helios.md
  - raw/connettori/calendario/2026-07-10_scadenza-offerta-2026-9-studiolex.md
  - raw/connettori/calendario/2026-08-25_scadenza-offerta-2026-10-ferro-forma.md
ultimo_aggiornamento: 2026-10-27
---
# Scadenze e rinnovi

Vista derivata: le condizioni di rinnovo stanno nei contratti, le validità nelle offerte, le fine progetto nei progetti. Qui compaiono le date calcolate e quelle presenti a calendario. Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Prossime scadenze
| Data | Evento | Giorni da oggi | Note |
|---|---|---|---|
| 2026-07-10 | Validità [[offerta-2026-9]] | 7 | Offerta in valutazione |
| 2026-07-15 | Fine prevista [[tiktok-launch-bloome]] | 12 | |
| 2026-07-30 | Fine prevista [[automazione-email-flow-verdalia]] | 27 | Saldo non ancora fatturato |
| 2026-08-15 | Fine prevista [[linkedin-lead-gen-nordvik]] | 43 | Saldo non ancora fatturato |
| 2026-08-25 | Validità [[offerta-2026-10]] | 53 | Accettazione del 2026-10-20 documentata da una fonte successiva alla data di riferimento |
| 2026-08-31 | Fine prevista [[content-compliance-studiolex]] | 59 | |
| 2026-09-07 | Avvio provvisorio [[newsletter-trimestrale-helios]] | 66 | Da confermare: offerta non accettata |
| 2026-09-30 | Fine prevista [[content-q3-social-verdalia]] | 89 | |
| 2026-11-30 | Fine prevista [[rebranding-digitale-helios]] | 150 | Progetto in corso nell'export |
| 2026-12-20 | Fine prevista ciclo [[social-growth-artigiani]] | 170 | Retainer, ciclo 2026 |
| 2027-01-08 | Termine disdetta [[contratto-verdalia]] | 189 | Rinnovo automatico a marzo 2027, preavviso di 60 giorni |
| 2027-03-01 | Termine disdetta [[contratto-helios-energia]] | 241 | Rinnovo annuale a giugno 2027, preavviso di 90 giorni |

Le fatture scadute sono nell'indice [[fatture/_indice]]. Al 2026-07-03 nessuna data in elenco è ancora passata.

## Da fare, senza data
- [[cliente-ferro-forma]]: inviare il contratto e fissare il kickoff, richiesti dal cliente il 2026-10-20 con l'accettazione di [[offerta-2026-10]] (fonte successiva alla data di riferimento del 2026-07-03).
