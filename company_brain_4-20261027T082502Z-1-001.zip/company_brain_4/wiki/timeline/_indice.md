---
tipo: indice
argomento: timeline (vista derivata)
ultimo_aggiornamento: 2026-10-27
---
# Indice timeline

| Nota | Contenuto |
|---|---|
| [[scadenze-e-rinnovi]] | Fine progetto, disdette e validità delle offerte, calcolate rispetto al 2026-07-03 |

Le scadenze delle fatture sono in [[fatture/_indice]].
