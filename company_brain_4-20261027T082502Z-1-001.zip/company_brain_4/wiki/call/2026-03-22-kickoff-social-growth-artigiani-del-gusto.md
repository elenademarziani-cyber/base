---
tipo: call
data: 2026-03-22
durata_min: 12
natura: cliente
cliente: "[[cliente-artigiani-del-gusto]]"
progetto: "[[social-growth-artigiani]]"
partecipanti: ["[[elena-giorgi]]", "[[laura-conti]]", "[[tommaso-ferraro]]"]
fonti:
  - raw/connettori/granola/2026-03-22_kickoff-social-growth-artigiani-del-gusto.md
ultimo_aggiornamento: 2026-10-20
---
# Kickoff Social Growth - Artigiani del Gusto

## Sintesi
Kickoff del nuovo ciclo Social Growth (secondo le note partito il 2026-03-20, fino al 2026-12-20) nell'ambito del retainer mensile attivo dal gennaio 2023; il prezzo non cambia (importi nelle note offerta/fattura). Titolare: Tommaso Ferraro, che decide in prima persona.
- Piano editoriale confermato: 12 post al mese su Instagram e Facebook, in batch mensile da approvare; report di engagement a inizio mese.
- Laura Conti è il riferimento quotidiano, Elena Giorgi segue la parte creativa; idea di rubrica sui fornitori locali e storytelling di laboratorio.
- Azione: Laura imposta una cartella condivisa per le foto del cliente.
- Idea (senza impegno, da riprendere più avanti): shooting fotografico dei prodotti; il cliente rimanda la discussione.
- Azione: Elena invia mail di recap in giornata.

## Collegamenti
- Progetto: [[social-growth-artigiani]] - Cliente: [[cliente-artigiani-del-gusto]]
- Deliverable: [[dlv-013]], [[dlv-014]], [[dlv-015]]

## Incongruenze
- [[artigiani-budget-durata-e-numerazione-fatture]]
