---
tipo: call
data: 2026-04-25
durata_min: 12
natura: cliente
cliente: "[[cliente-nordvik-italia]]"
progetto: "[[linkedin-lead-gen-nordvik]]"
partecipanti: ["[[laura-conti]]", "[[giulio-marino]]", "[[luca-amendola]]"]
fonti:
  - raw/connettori/granola/2026-04-25_allineamento-target-mql-nordvik.md
ultimo_aggiornamento: 2026-10-20
---
# Allineamento target MQL - Nordvik

## Sintesi
Call prima dell'avvio del progetto: la proposta era stata inviata a metà aprile e Luca Amendola la stava facendo approvare internamente (ok formale atteso a giorni).
- Decisione: KPI principale = MQL generati da LinkedIn; target concordato 15 MQL al mese (il direttore commerciale del cliente ne voleva di più, giudicato non realistico).
- Definizione MQL condivisa: contatto in target (azienda, ruolo decisionale o influencer) con almeno un'azione di interesse (download, demo, form); esclusi concorrenti e studenti.
- I case study di febbraio saranno riusati come lead magnet.
- Perimetro ricordato: strategia contenuti LinkedIn (Elena, consegna entro 2026-05-25), 24 post, report lead mensile, dashboard analytics. Avvio previsto 2026-05-10, chiusura 2026-08-15.
- Azioni: Giulio Marino traccia gli MQL nel report e nella dashboard (walkthrough dedicato a dashboard pronta); Luca chiede al suo IT l'accesso in lettura al CRM; Laura Conti invia la conferma scritta del target subito dopo la call.

## Collegamenti
- Progetto: [[linkedin-lead-gen-nordvik]] - Cliente: [[cliente-nordvik-italia]]
- Deliverable: [[dlv-008]], [[dlv-009]], [[dlv-010]]; case study riusati: [[dlv-011]]

## Incongruenze
- [[nordvik-post-linkedin-senza-dlv]] (in call sono previsti 24 post)
