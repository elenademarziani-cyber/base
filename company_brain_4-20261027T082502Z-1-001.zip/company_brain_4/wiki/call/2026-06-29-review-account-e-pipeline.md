---
tipo: call
data: 2026-06-29
durata_min: 25
natura: interna
cliente: null
progetto: null
partecipanti: ["[[marco-rossi]]", "[[laura-conti]]", "[[davide-ferretti]]"]
fonti:
  - raw/connettori/granola/2026-06-29_review-account-e-pipeline.md
ultimo_aggiornamento: 2026-10-20
---
# Review account e pipeline (interna)

## Sintesi
Giro degli account a fine semestre (6 clienti attivi più 1 lead) sul lato relazione; i margini erano stati visti nella call precedente.
- Verdalia: relazione ottima, Sofia Bianchi ha aperto un upsell sulla collezione autunno; l'automazione email può essere il prossimo upsell.
- Nordvik: MQL in linea col target; nessuna risposta al report lead di maggio, da verificare con leggerezza al walkthrough.
- Artigiani: silenzio del cliente dal 2026-05-20 (campioni per lo shooting) e fattura di giugno scaduta senza risposta al sollecito; si recupera il contatto prima di affrontare il listino (a settembre); shooting provvisorio a luglio.
- Helios: progetto faticoso (quattro stakeholder, dashboard alla quarta iterazione); newsletter ferma in attesa dell'ok del CFO, offerta [[offerta-2026-4]] scaduta e mai rifirmata (il testo dà scadenza 2026-05-27).
- StudioLex: articolo 13 in validazione; offerta video [[offerta-2026-9]] in attesa del legale della cliente, scade il 2026-07-10.
- Bloome: vuole accelerare; YouTube Shorts rifiutato il 2026-06-17; serve una proposta di continuità sul TikTok prima della chiusura di metà luglio.
- Ferro & Forma: lead da referral; [[offerta-2026-10]] inviata il 2026-06-26, secondo meeting a fine luglio a Brescia, nessun contratto.
- Azioni: Laura Conti telefona a Tommaso Ferraro oggi, prepara la proposta upsell Verdalia (da rivedere con Marco) e fa follow-up StudioLex prima del 2026-07-10 (se nulla entro il 6-7 luglio); Davide Ferretti avvisa Giulio per il report Nordvik e segue la fattura Artigiani; Marco Rossi attende il CFO Helios, prepara la continuità Bloome e il secondo meeting Ferro & Forma (con Laura).

## Collegamenti
- Clienti: [[cliente-verdalia]], [[cliente-nordvik-italia]], [[cliente-artigiani-del-gusto]], [[cliente-helios-energia]], [[cliente-studiolex]], [[cliente-bloome-cosmetics]], [[cliente-ferro-forma]]
- Progetti: [[newsletter-trimestrale-helios]], [[content-linkedin-newsletter-ferro-forma]], [[tiktok-launch-bloome]]
- Call collegata: [[2026-06-26-review-marginalita-progetti]]

## Incongruenze
- [[helios-newsletter-stato-offerta-vs-calendario]] (scadenza offerta newsletter: 27 maggio qui, "fine maggio" nella review margini)
