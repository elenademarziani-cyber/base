---
tipo: call
data: 2026-06-15
durata_min: 11
natura: cliente
cliente: "[[cliente-ferro-forma]]"
progetto: "[[content-linkedin-newsletter-ferro-forma]]"
partecipanti: ["[[marco-rossi]]", "[[giorgio-testa]]"]
fonti:
  - raw/connettori/granola/2026-06-15_primo-contatto-ferro-e-forma.md
ultimo_aggiornamento: 2026-10-20
---
# Primo contatto - Ferro & Forma

## Sintesi
Primo contatto commerciale con Giorgio Testa (Direttore Commerciale), arrivato tramite referral di Sofia Bianchi (Verdalia). Anagrafica dell'azienda nella nota cliente.
- Esigenze: visibilità verso architetti e studi di progettazione; oggi nessuna strategia di contenuti (LinkedIn usato in modo sporadico) e database di contatti mai attivato.
- Interesse per contenuti LinkedIn e per una newsletter B2B. Nessun budget di riferimento: il cliente chiede una proposta sensata.
- Azione: Marco Rossi prepara e invia a breve una proposta con perimetro, tempi e costi, più un recap scritto.
- Prossimo passo: secondo confronto dopo la proposta, possibilmente di persona a Brescia.

## Collegamenti
- Cliente: [[cliente-ferro-forma]] - Progetto: [[content-linkedin-newsletter-ferro-forma]] - Offerta: [[offerta-2026-10]]
