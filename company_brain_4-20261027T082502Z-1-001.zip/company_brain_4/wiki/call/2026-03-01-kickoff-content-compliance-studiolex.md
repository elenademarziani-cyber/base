---
tipo: call
data: 2026-03-01
durata_min: 12
natura: cliente
cliente: "[[cliente-studiolex]]"
progetto: "[[content-compliance-studiolex]]"
partecipanti: ["[[elena-giorgi]]", "[[laura-conti]]", "[[chiara-messina]]"]
fonti:
  - raw/connettori/granola/2026-03-01_kickoff-content-compliance-studiolex.md
ultimo_aggiornamento: 2026-10-20
---
# Kickoff Content Compliance - StudioLex

## Sintesi
Kickoff con l'Avv. Chiara Messina (Managing Partner). Periodo 2026-03-01 / 2026-08-31. Perimetro ricordato in call: content calendar legale-compliant, 16 articoli blog, 20 post LinkedIn. Tono autorevole e divulgativo, mai promozionale, niente promesse di risultato.
- Regola concordata: ogni contenuto passa dalla revisione legale interna dello studio e si pubblica solo dopo l'ok scritto (vincolo anche contrattuale, con penale secondo la cliente); tempi di approvazione lunghi da mettere in conto.
- Le bozze vanno sempre alla Messina, via mail, con oggetto e numero articolo.
- Aree di pratica richieste: diritto societario e contrattualistica, privacy/GDPR, diritto del lavoro.
- Uso dell'AI ammesso in ricerca e prima stesura con revisione umana; nessun dato riservato dei clienti dello studio in strumenti esterni.
- Azione: Elena consegna il content calendar entro 2026-03-20 e invia conferma scritta in giornata; Laura segue gli articoli.

## Collegamenti
- Progetto: [[content-compliance-studiolex]] - Cliente: [[cliente-studiolex]]
- Deliverable: [[dlv-021]] (calendar), [[dlv-022]] (articoli 1-9), [[dlv-025]] (post LinkedIn)

## Incongruenze
- [[studiolex-articoli-previsti-vs-dlv]] (in call si parla di 16 articoli previsti)
