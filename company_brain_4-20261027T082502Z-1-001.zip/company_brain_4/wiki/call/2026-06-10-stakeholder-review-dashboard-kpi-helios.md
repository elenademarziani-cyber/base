---
tipo: call
data: 2026-06-10
durata_min: 13
natura: cliente
cliente: "[[cliente-helios-energia]]"
progetto: "[[rebranding-digitale-helios]]"
partecipanti: ["[[giulio-marino]]", "[[marco-rossi]]", "[[marta-colombo]]", "[[roberto-fabbri]]", "[[silvia-moretti]]", "[[andrea-lombardi]]"]
fonti:
  - raw/connettori/granola/2026-06-10_stakeholder-review-dashboard-kpi-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Stakeholder review dashboard KPI (3a review) - Helios

## Sintesi
Terza review della bozza di dashboard KPI, con tutti e quattro gli stakeholder. Accolte le modifiche della review precedente (vista d'insieme, sezione lead dal sito).
- Nuove revisioni richieste: sentiment segmentato per pubblico con focus investitori e stampa finanziaria (Moretti); confronto con lo stesso periodo dell'anno precedente (Fabbri); dettaglio per canale con filtro data (Lombardi); prima pagina ridotta a 5-6 KPI (Colombo).
- Decisione: quarta iterazione presentata dopo circa due settimane; Davide Ferretti invia l'invito ai quattro.
- Regola chiesta da Marco Rossi: i feedback vanno consolidati in un unico documento prima della review (lo coordina Marta Colombo).
- Azioni: Andrea Lombardi invia a Giulio l'export storico di Analytics; Giulio Marino invia il recap in giornata.

## Collegamenti
- Progetto: [[rebranding-digitale-helios]] - Cliente: [[cliente-helios-energia]]
- Deliverable: [[dlv-019]] (dashboard KPI)
