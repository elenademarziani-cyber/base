---
tipo: call
data: 2026-04-10
durata_min: 10
natura: cliente
cliente: "[[cliente-verdalia]]"
progetto: "[[automazione-email-flow-verdalia]]"
partecipanti: ["[[davide-ferretti]]", "[[elena-giorgi]]", "[[sofia-bianchi]]"]
fonti:
  - raw/connettori/granola/2026-04-10_kickoff-automazione-email-flow-verdalia.md
ultimo_aggiornamento: 2026-10-20
---
# Kickoff Automazione Email Flow - Verdalia

## Sintesi
Kickoff con Sofia Bianchi (Marketing Manager). Brief acquisito completo; piattaforma email invariata; sconto di benvenuto mantenuto ma comunicato con tono non "da saldi". Avvio lavori 2026-04-15, fine prevista 2026-07-30.
- Flow confermati: welcome, abandoned cart, post-purchase, più un batch finale di 8 template email personalizzati.
- Scadenze: welcome 2026-04-30, abandoned cart 2026-05-20, post-purchase 2026-06-15 (Davide Ferretti, anche setup tecnico); template definitivi 2026-07-10 (Elena Giorgi), dopo un test A/B sulle subject line a flow attivi.
- Il cliente fornisce linee guida grafiche, foto collezione e un utente admin sulla piattaforma email.
- Recap scritto a cura di Davide.

## Collegamenti
- Progetto: [[automazione-email-flow-verdalia]] - Cliente: [[cliente-verdalia]]
- Deliverable: [[dlv-001]], [[dlv-002]], [[dlv-003]], [[dlv-004]]
