---
tipo: call
data: 2026-06-28
durata_min: 10
natura: cliente
cliente: "[[cliente-verdalia]]"
progetto: "[[content-q3-social-verdalia]]"
partecipanti: ["[[laura-conti]]", "[[sofia-bianchi]]"]
fonti:
  - raw/connettori/granola/2026-06-28_check-in-mensile-verdalia.md
ultimo_aggiornamento: 2026-10-20
---
# Check-in mensile - Verdalia

## Sintesi
Check-in mensile sul Content Q3 Social (partito il 2026-06-01, fine prevista 2026-09-30). Risultati di giugno buoni (caroselli sulla filiera dei tessuti sopra la media); Sofia Bianchi molto soddisfatta anche dell'automazione email. Trimestre costruito sulla collezione sostenibile autunno: luglio dietro le quinte, agosto teaser, settembre lancio.
- Azione: Laura Conti consegna il primo batch di 12 post di luglio entro 2026-07-05; i primi 2 reel (seguiti da Elena Giorgi) entro 2026-07-20, con approvazione preventiva della cliente.
- Azione: Laura prepara una proposta di upsell per la collezione autunno (campagna dedicata/contenuti extra); la cliente vuole decidere entro l'estate.
- Email: il test A/B sulle subject line è partito il 2026-06-19; Davide Ferretti aggiorna la cliente sui risultati, poi Elena chiude i template definitivi.
- Laura invia il recap scritto in giornata.

## Collegamenti
- Progetti: [[content-q3-social-verdalia]], [[automazione-email-flow-verdalia]] - Cliente: [[cliente-verdalia]]
- Deliverable: [[dlv-004]], [[dlv-006]], [[dlv-007]]
