---
tipo: call
data: 2026-07-02
durata_min: 32
natura: interna
cliente: null
progetto: null
partecipanti: ["[[marco-rossi]]", "[[elena-giorgi]]", "[[davide-ferretti]]", "[[laura-conti]]", "[[giulio-marino]]"]
fonti:
  - raw/connettori/granola/2026-07-02_weekly-status-deliverable.md
ultimo_aggiornamento: 2026-10-20
---
# Weekly status deliverable (interna)

## Sintesi
Weekly del team con giro del tracker DLV progetto per progetto. Quadro d'insieme: 19 deliverable su 32 consegnati al 2026-07-02; 13 aperti (in revisione, in lavorazione o da consegnare). Lo stato dei singoli DLV è nelle note deliverable.
- Prima scadenza: [[dlv-028]] (report Bloome di giugno) il 2026-07-03, con una slide sulla frequenza di pubblicazione richiesta da Marco.
- Punti critici: [[dlv-004]] (attende l'esito del test A/B), [[dlv-019]] (quarta iterazione dashboard Helios, da inviare entro l'8 luglio), [[dlv-024]] (rischio sforamento per i tempi di validazione legale; non si pubblica senza validazione), [[dlv-029]] (cade oltre la fine prevista del progetto Bloome: usarlo per agganciare la proposta di continuità).
- Carico di luglio concentrato su Elena Giorgi (6 deliverable aperti): Laura Conti la supporta su StudioLex e Artigiani, responsabilità invariate; Davide Ferretti verifica che le date reggano. Chi vede uno slittamento lo segnala subito.
- Decisioni: Artigiani, senza campioni dal cliente lo shooting resta provvisorio e Elena usa foto d'archivio per [[dlv-015]]; Laura riprova a contattare Tommaso Ferraro. StudioLex: Laura abbina il sollecito sull'offerta video alla telefonata sull'articolo 13.
- Prossima weekly: giovedì successivo, stessa ora. Ferro & Forma non ha deliverable (solo proposta; secondo meeting a fine luglio con Laura).

## Collegamenti
- Progetti: [[automazione-email-flow-verdalia]], [[content-q3-social-verdalia]], [[linkedin-lead-gen-nordvik]], [[social-growth-artigiani]], [[rebranding-digitale-helios]], [[content-compliance-studiolex]], [[tiktok-launch-bloome]]
- Deliverable critici: [[dlv-004]], [[dlv-015]], [[dlv-019]], [[dlv-024]], [[dlv-028]], [[dlv-029]]
