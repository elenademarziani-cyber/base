---
tipo: call
data: 2025-11-05
durata_min: 16
natura: cliente
cliente: "[[cliente-bloome-cosmetics]]"
progetto: "[[tiktok-launch-bloome]]"
partecipanti: ["[[elena-giorgi]]", "[[giulio-marino]]", "[[alessia-neri]]"]
fonti:
  - raw/connettori/granola/2025-11-05_kickoff-tiktok-launch-bloome.md
ultimo_aggiornamento: 2026-10-20
---
# Kickoff TikTok Launch - Bloome

## Sintesi
Kickoff del progetto con Alessia Neri (CEO, segue direttamente il lavoro). Date concordate: avvio il 2025-11-05, fine prevista 2026-07-15. Perimetro ricordato in call: strategia TikTok, 40 video short-form distribuiti nel periodo, report di performance mensile. Strategia su due binari: contenuti evergreen pianificati e slot liberi per i trend; video nativi TikTok riadattati per i Reels.
- Piano editoriale iniziale confermato dal cliente.
- Azione: Elena Giorgi consegna la strategia TikTok entro 2025-11-20.
- Azione: Giulio Marino imposta tracciamento e baseline (follower, view, engagement, traffico verso lo shop) per i report mensili; il cliente gli gira gli accessi in sola lettura.
- Azione: recap scritto firmato da Elena e Giulio, inviato il giorno stesso.
- Il cliente dovrà comparire in alcuni video (founder); script preparati da Elena.

## Collegamenti
- Progetto: [[tiktok-launch-bloome]] - Cliente: [[cliente-bloome-cosmetics]]
- Deliverable: [[dlv-026]] (strategia TikTok), [[dlv-027]] (video 1-20), [[dlv-029]] (video 21-30)

## Incongruenze
- [[bloome-video-previsti-vs-dlv]] (in call si parla di 40 video previsti)
