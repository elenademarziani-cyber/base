---
tipo: call
data: 2026-01-03
durata_min: 13
natura: cliente
cliente: "[[cliente-nordvik-italia]]"
progetto: "[[case-study-produzione-nordvik]]"
partecipanti: ["[[laura-conti]]", "[[elena-giorgi]]", "[[luca-amendola]]"]
fonti:
  - raw/connettori/granola/2026-01-03_kickoff-case-study-produzione-nordvik.md
ultimo_aggiornamento: 2026-10-20
---
# Kickoff Case Study Produzione - Nordvik

## Sintesi
Kickoff con Luca Amendola. Avvio operativo 2026-01-05, chiusura entro 2026-02-28. Deliverable: 3 case study clienti in PDF e una landing page con form di download, pensata anche come strumento di lead generation e come materiale per LinkedIn.
- Confermata la lista dei 3 clienti da intervistare (distributore di ricambi, cooperativa logistica, studio di ingegneria); ogni numero va approvato dal cliente intervistato.
- Luca invia la mail di presentazione ai tre clienti, il brand book e (con la loro autorizzazione) i loghi; fornirà gli accessi al CMS tramite il suo IT.
- Laura Conti contatta i referenti per fissare le interviste; Elena Giorgi invia la traccia di intervista da validare.
- Scadenze interne: PDF (Laura) entro 2026-02-20; landing page (Elena) entro 2026-02-27.
- Recap scritto inviato da Laura in giornata.

## Collegamenti
- Progetto: [[case-study-produzione-nordvik]] - Cliente: [[cliente-nordvik-italia]]
- Deliverable: [[dlv-011]] (case study PDF), [[dlv-012]] (landing page)
