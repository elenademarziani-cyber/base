---
tipo: call
data: 2026-06-20
durata_min: 11
natura: cliente
cliente: "[[cliente-bloome-cosmetics]]"
progetto: "[[tiktok-launch-bloome]]"
partecipanti: ["[[elena-giorgi]]", "[[giulio-marino]]", "[[alessia-neri]]"]
fonti:
  - raw/connettori/granola/2026-06-20_check-in-performance-bloome.md
ultimo_aggiornamento: 2026-10-20
---
# Check-in performance - Bloome

## Sintesi
Check-in mensile sul TikTok Launch. Follower +180% in 6 mesi (crescita in rallentamento percentuale, fisiologico); format migliori: educational e routine, con la founder in prima persona; buon riflesso sui Reels.
- Stato produzione riferito in call: video 1-20 consegnati, tranche 21-30 in lavorazione; script di luglio a fine mese per approvazione.
- Richiesta del cliente: aumentare la frequenza di pubblicazione e concentrare tutto su TikTok (estensione YouTube Shorts declinata).
- Azioni: Elena Giorgi ripensa il calendario di luglio (trend veloci, meno produzione) senza perdere qualità; Giulio Marino indica orari e giorni più redditizi e invia il report di giugno entro 2026-07-03; recap scritto di Elena in giornata.
- Chiusura progetto prevista a metà luglio: da discutere cosa fare dopo, con Marco Rossi.

## Collegamenti
- Progetto: [[tiktok-launch-bloome]] - Cliente: [[cliente-bloome-cosmetics]]
- Deliverable: [[dlv-027]], [[dlv-028]] (report giugno), [[dlv-029]]

## Incongruenze
- [[bloome-video-previsti-vs-dlv]]
