---
tipo: call
data: 2026-06-24
durata_min: 29
natura: interna
cliente: null
progetto: null
partecipanti: ["[[marco-rossi]]", "[[davide-ferretti]]"]
fonti:
  - raw/connettori/granola/2026-06-24_pianificazione-team-h2-competenze.md
ultimo_aggiornamento: 2026-10-20
---
# Pianificazione team H2 e competenze (interna)

## Sintesi
Riunione interna per preparare il secondo semestre (carico alto: Helios fino a novembre, Artigiani fino a dicembre, Verdalia, Nordvik, StudioLex, possibile Ferro & Forma) e aggiornare la matrice competenze del team (livelli Esperto/Avanzato/Intermedio persona per persona; il dettaglio è solo nella trascrizione raw e non è riportato qui).
- Gap individuati: nessuna competenza avanzata in paid advertising (Meta Ads, Google Ads); SEO coperta solo in parte da Giulio Marino; nessuna figura per video editing avanzato oltre lo short-form.
- Opzioni emerse (nessuna decisione presa): formazione per la SEO; collaboratori esterni a progetto per paid e video.
- Azione: Davide Ferretti prepara una bozza di piano con pro e contro, da discutere a settembre (dopo aver chiarito Ferro & Forma e la newsletter Helios).
- Urgente: il carico di Elena Giorgi, presente su quasi tutti i progetti; nel planning di luglio valutare cosa passare a Laura Conti sulla gestione contenuti (in agenda alla weekly di inizio luglio).
- Davide gira a ciascuno la propria scheda aggiornata individualmente.

## Collegamenti
- Persone: [[marco-rossi]], [[davide-ferretti]]; citati [[elena-giorgi]], [[laura-conti]], [[giulio-marino]]
- Clienti/progetti citati: [[cliente-helios-energia]], [[cliente-artigiani-del-gusto]], [[cliente-ferro-forma]], [[content-linkedin-newsletter-ferro-forma]], [[newsletter-trimestrale-helios]]
- Call collegate: [[2026-06-26-review-marginalita-progetti]], [[2026-07-02-weekly-status-deliverable]]
