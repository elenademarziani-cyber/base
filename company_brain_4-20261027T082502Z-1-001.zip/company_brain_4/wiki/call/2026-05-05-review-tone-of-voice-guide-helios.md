---
tipo: call
data: 2026-05-05
durata_min: 10
natura: cliente
cliente: "[[cliente-helios-energia]]"
progetto: "[[rebranding-digitale-helios]]"
partecipanti: ["[[elena-giorgi]]", "[[marta-colombo]]"]
fonti:
  - raw/connettori/granola/2026-05-05_review-tone-of-voice-guide-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Review Tone of voice guide - Helios

## Sintesi
Marta Colombo riporta la sintesi dei commenti dei quattro stakeholder Helios sulla tone of voice guide.
- Esito: guida approvata. Sezione investitori molto apprezzata; tono, struttura ed esempi senza modifiche.
- Modifiche richieste sulla terminologia: correggere i termini di settore (es. fotovoltaico, non "pannello solare"), aggiungere in appendice un glossario do and don't (PPA, comunità energetiche, accumulo), uniformare le unità di misura, ridurre gli anglicismi.
- Azione: Elena Giorgi integra le modifiche e consegna la versione finale entro 2026-05-10; poi si passa ai contenuti pilota (primo mese a metà giugno).
- Azione: Elena invia a Marta una conferma scritta, che lei inoltra agli altri tre stakeholder.

## Collegamenti
- Progetto: [[rebranding-digitale-helios]] - Cliente: [[cliente-helios-energia]]
- Deliverable: [[dlv-017]] (tone of voice guide), [[dlv-018]] (contenuti pilota mese 1)
