---
tipo: call
data: 2026-07-01
durata_min: 10
natura: cliente
cliente: "[[cliente-helios-energia]]"
progetto: "[[rebranding-digitale-helios]]"
partecipanti: ["[[davide-ferretti]]", "[[marta-colombo]]"]
fonti:
  - raw/connettori/granola/2026-07-01_check-in-sal-3-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Check-in SAL 3 - Helios

## Sintesi
Check-in amministrativo e operativo con Marta Colombo. Importi e scadenze delle fatture sono nelle note fattura.
- Fattura SAL 3 emessa il 2026-07-01, nessun problema segnalato dal cliente; confermato che il SAL 2 è stato saldato a giugno.
- Dashboard KPI: quarta iterazione in lavorazione con Giulio; Davide Ferretti aggiorna a breve sullo stato delle revisioni. Priorità del cliente: prima pagina snella.
- Contenuti pilota: mese 1 consegnato a metà giugno, mese 2 previsto a metà luglio; Andrea Lombardi chiede più LinkedIn e meno blog (Marta inoltra la richiesta a Davide, che la gira a Elena).
- Newsletter trimestrale: ancora nessuna conferma di budget, serve l'ok della direzione finanziaria del cliente (impegnata con la semestrale).
- Azione: Davide invia il recap scritto.

## Collegamenti
- Progetto: [[rebranding-digitale-helios]] - Cliente: [[cliente-helios-energia]] - Pipeline: [[newsletter-trimestrale-helios]]
- Deliverable: [[dlv-019]], [[dlv-020]]
