---
tipo: timeline
argomento: Indice delle call registrate con Granola (2025-11-05 / 2026-07-02)
fonti:
  - raw/connettori/granola/README.md
ultimo_aggiornamento: 2026-10-20
---
# Indice call

Vista derivata dalle note call (la nota proprietaria resta la singola call). Le trascrizioni Granola sono automatiche e non riviste.

| Data | Nota | Natura | Cliente / progetto | Durata (min) |
|---|---|---|---|---|
| 2025-11-05 | [[2025-11-05-kickoff-tiktok-launch-bloome]] | cliente | [[cliente-bloome-cosmetics]] / [[tiktok-launch-bloome]] | 16 |
| 2026-01-03 | [[2026-01-03-kickoff-case-study-produzione-nordvik]] | cliente | [[cliente-nordvik-italia]] / [[case-study-produzione-nordvik]] | 13 |
| 2026-02-05 | [[2026-02-05-kickoff-rebranding-digitale-helios]] | cliente | [[cliente-helios-energia]] / [[rebranding-digitale-helios]] | 16 |
| 2026-03-01 | [[2026-03-01-kickoff-content-compliance-studiolex]] | cliente | [[cliente-studiolex]] / [[content-compliance-studiolex]] | 12 |
| 2026-03-22 | [[2026-03-22-kickoff-social-growth-artigiani-del-gusto]] | cliente | [[cliente-artigiani-del-gusto]] / [[social-growth-artigiani]] | 12 |
| 2026-04-10 | [[2026-04-10-kickoff-automazione-email-flow-verdalia]] | cliente | [[cliente-verdalia]] / [[automazione-email-flow-verdalia]] | 10 |
| 2026-04-25 | [[2026-04-25-allineamento-target-mql-nordvik]] | cliente | [[cliente-nordvik-italia]] / [[linkedin-lead-gen-nordvik]] | 12 |
| 2026-05-05 | [[2026-05-05-review-tone-of-voice-guide-helios]] | cliente | [[cliente-helios-energia]] / [[rebranding-digitale-helios]] | 10 |
| 2026-05-28 | [[2026-05-28-modifiche-articoli-10-12-studiolex]] | cliente | [[cliente-studiolex]] / [[content-compliance-studiolex]] | 9 |
| 2026-06-10 | [[2026-06-10-stakeholder-review-dashboard-kpi-helios]] | cliente | [[cliente-helios-energia]] / [[rebranding-digitale-helios]] | 13 |
| 2026-06-15 | [[2026-06-15-primo-contatto-ferro-e-forma]] | cliente | [[cliente-ferro-forma]] / [[content-linkedin-newsletter-ferro-forma]] | 11 |
| 2026-06-20 | [[2026-06-20-check-in-performance-bloome]] | cliente | [[cliente-bloome-cosmetics]] / [[tiktok-launch-bloome]] | 11 |
| 2026-06-24 | [[2026-06-24-pianificazione-team-h2-competenze]] | interna | - | 29 |
| 2026-06-26 | [[2026-06-26-review-marginalita-progetti]] | interna | - | 27 |
| 2026-06-28 | [[2026-06-28-check-in-mensile-verdalia]] | cliente | [[cliente-verdalia]] / [[content-q3-social-verdalia]] | 10 |
| 2026-06-29 | [[2026-06-29-review-account-e-pipeline]] | interna | - | 25 |
| 2026-06-30 | [[2026-06-30-walkthrough-dashboard-analytics-nordvik]] | cliente | [[cliente-nordvik-italia]] / [[linkedin-lead-gen-nordvik]] | 9 |
| 2026-07-01 | [[2026-07-01-check-in-sal-3-helios]] | cliente | [[cliente-helios-energia]] / [[rebranding-digitale-helios]] | 10 |
| 2026-07-02 | [[2026-07-02-weekly-status-deliverable]] | interna | - | 32 |
