---
tipo: call
data: 2026-02-05
durata_min: 16
natura: cliente
cliente: "[[cliente-helios-energia]]"
progetto: "[[rebranding-digitale-helios]]"
partecipanti: ["[[marco-rossi]]", "[[elena-giorgi]]", "[[davide-ferretti]]", "[[giulio-marino]]", "[[marta-colombo]]", "[[roberto-fabbri]]", "[[silvia-moretti]]", "[[andrea-lombardi]]"]
fonti:
  - raw/connettori/granola/2026-02-05_kickoff-rebranding-digitale-helios.md
ultimo_aggiornamento: 2026-10-20
---
# Kickoff Rebranding Digitale - Helios

## Sintesi
Kickoff con i 4 stakeholder Helios. Progetto partito il 2026-02-01, fine prevista 2026-11-30. Perimetro: nuova content strategy, tone of voice guide (con sezione dedicata agli investitori), 3 mesi di contenuti pilota, dashboard KPI. Ruoli Musa AI: Marco relazione e strategia, Elena contenuti e ToV, Davide timeline e coordinamento, Giulio dashboard.
- Decisione: in ogni review sono presenti tutti e quattro gli stakeholder (Colombo, Fabbri, Moretti, Lombardi).
- Tappe: content strategy entro 2026-03-15 (Elena, parte da audit canali); tone of voice guide entro 2026-05-10; primo mese di contenuti pilota a metà giugno.
- Azione: Davide invia il calendario delle review ai quattro; Giulio raccoglie da ciascuno i 2-3 KPI di interesse e prepara la bozza di dashboard.
- Marco anticipa che sono attesi più giri di revisione su dashboard e ToV; Davide ha previsto margine.
- Recap scritto a cura di Marco ed Elena.

## Collegamenti
- Progetto: [[rebranding-digitale-helios]] - Cliente: [[cliente-helios-energia]]
- Deliverable: [[dlv-016]], [[dlv-017]], [[dlv-018]], [[dlv-019]], [[dlv-020]]
