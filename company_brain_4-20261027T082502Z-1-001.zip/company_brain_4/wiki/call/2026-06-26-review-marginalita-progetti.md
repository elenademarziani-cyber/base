---
tipo: call
data: 2026-06-26
durata_min: 27
natura: interna
cliente: null
progetto: null
partecipanti: ["[[marco-rossi]]", "[[davide-ferretti]]"]
fonti:
  - raw/connettori/granola/2026-06-26_review-marginalita-progetti.md
ultimo_aggiornamento: 2026-10-20
---
# Review marginalità progetti (interna)

## Sintesi
Review semestrale progetto per progetto di budget, costo stimato e margine. Margini e importi non sono riportati qui: stanno nelle note dei progetti e delle offerte.
- In corso: [[automazione-email-flow-verdalia]], [[content-q3-social-verdalia]], [[linkedin-lead-gen-nordvik]], [[social-growth-artigiani]], [[rebranding-digitale-helios]], [[content-compliance-studiolex]], [[tiktok-launch-bloome]]. Conclusi: [[case-study-produzione-nordvik]], [[analisi-dati-q1-bloome]]. In pipeline senza stima costi: [[newsletter-trimestrale-helios]], [[content-linkedin-newsletter-ferro-forma]].
- Decisione: monitorare le ore su Helios; Davide Ferretti le condivide con Marco ogni venerdì. I feedback sulla dashboard devono arrivare consolidati: una quinta iterazione metterebbe a rischio la redditività.
- Decisione: rivedere a settembre il listino di Artigiani (fermo dal 2023), dopo aver recuperato il contatto con il cliente.
- Azione (Davide): provare a vendere più progetti di analisi dati.
- Spunti: sul TikTok Launch serve una proposta di continuità prima della chiusura di luglio (Marco con Elena e Giulio); la mancanza di un video editor avanzato pesa sulle ore (dato per la discussione di settembre).
- Marco invia in giornata la proposta a Ferro & Forma e un sollecito a Marta Colombo per la newsletter Helios.

## Collegamenti
- Offerta: [[offerta-2026-10]] (proposta Ferro & Forma)
- Call collegate: [[2026-06-24-pianificazione-team-h2-competenze]], [[2026-06-29-review-account-e-pipeline]]
