---
tipo: call
data: 2026-06-30
durata_min: 9
natura: cliente
cliente: "[[cliente-nordvik-italia]]"
progetto: "[[linkedin-lead-gen-nordvik]]"
partecipanti: ["[[giulio-marino]]", "[[luca-amendola]]"]
fonti:
  - raw/connettori/granola/2026-06-30_walkthrough-dashboard-analytics-nordvik.md
ultimo_aggiornamento: 2026-10-20
---
# Walkthrough dashboard analytics - Nordvik

## Sintesi
Walkthrough della dashboard analytics; MQL in linea con il target concordato di 15 al mese. I case study di febbraio risultano i contenuti con la resa migliore.
- Decisione: aggiungere il CTR dei post/link; il tempo medio da primo contatto a MQL resta in coda; costo per MQL non applicabile (solo organico).
- Azione: Giulio Marino rilascia la dashboard v2 con CTR entro 2026-07-12 (richiesta del cliente: entro metà luglio, per una presentazione in direzione a fine mese).
- Azione: Giulio invia il report lead di giugno entro 2026-07-05 e il recap con la richiesta CTR.
- Luca Amendola spiega di non aver risposto al report di maggio perché l'aveva girato al commerciale; nessun problema.

## Collegamenti
- Progetto: [[linkedin-lead-gen-nordvik]] - Cliente: [[cliente-nordvik-italia]]
- Deliverable: [[dlv-009]] (report giugno), [[dlv-010]] (dashboard v2)
