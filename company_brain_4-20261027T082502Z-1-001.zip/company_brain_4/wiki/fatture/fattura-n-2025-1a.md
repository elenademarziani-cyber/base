---
tipo: fattura
numero: 2025-1A
cliente: "[[cliente-bloome-cosmetics]]"
contatto_sollecito: "[[alessia-neri]]"   # referente del cliente
offerta: "[[offerta-2025-1]]"
progetto: "[[tiktok-launch-bloome]]"
tipo_fattura: acconto
importo: 2600
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 572
importo_ivato: 3172
emissione: 2025-11-05
scadenza: 2025-12-05
stato_documentato: pagata
incasso: 2025-12-01
stato_calcolato_oggi: pagata
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2025-1A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2025-1A

## Sintesi
- Acconto del 50% per il progetto TikTok Launch.
- Tipo `acconto` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2025-11-05, scadenza 2025-12-05.
- Stato nell'export (2026-07-02): pagata il 2025-12-01.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-bloome-cosmetics]]
- Offerta: [[offerta-2025-1]]
- Progetto: [[tiktok-launch-bloome]]
