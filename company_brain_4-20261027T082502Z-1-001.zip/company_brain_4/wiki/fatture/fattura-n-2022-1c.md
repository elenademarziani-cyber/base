---
tipo: fattura
numero: 2022-1C
cliente: "[[cliente-artigiani-del-gusto]]"
contatto_sollecito: "[[tommaso-ferraro]]"   # referente del cliente
offerta: "[[offerta-2022-1]]"
progetto: "[[social-growth-artigiani]]"
tipo_fattura: retainer
importo: 200
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 44
importo_ivato: 244
emissione: 2026-06-01
scadenza: 2026-06-16
stato_documentato: scaduta
incasso: null
stato_calcolato_oggi: "scaduta da 17 giorni"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2022-1C.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2022-1C

## Sintesi
- Retainer mensile di giugno 2026 del servizio Social Growth.
- Tipo `retainer` (dedotto da descrizione, importo e offerta); termini di pagamento 15 giorni data fattura, emissione 2026-06-01, scadenza 2026-06-16.
- Stato nell'export (2026-07-02): scaduta (stato nell'export).
- Nella fonte e' annotato un sollecito di pagamento inviato il 2026-06-25, senza risposta del cliente. Nessun incasso documentato.
- Stato oggi: scaduta da 17 giorni (scadenza 2026-06-16); nessun incasso documentato nell'export.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-artigiani-del-gusto]]
- Offerta: [[offerta-2022-1]]
- Progetto: [[social-growth-artigiani]]

## Incongruenze
- [[artigiani-budget-durata-e-numerazione-fatture]]: numerazione fatture e budget/durata del retainer (la mail di sollecito del 2026-06-25 cita il numero FT-2026-028, diverso dalla numerazione Fatture in Cloud)
