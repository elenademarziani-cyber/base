---
tipo: fattura
numero: 2022-1D
cliente: "[[cliente-artigiani-del-gusto]]"
contatto_sollecito: "[[tommaso-ferraro]]"   # referente del cliente
offerta: "[[offerta-2022-1]]"
progetto: "[[social-growth-artigiani]]"
tipo_fattura: retainer
importo: 200
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 44
importo_ivato: 244
emissione: 2026-07-01
scadenza: 2026-07-16
stato_documentato: in-attesa
incasso: null
stato_calcolato_oggi: "in termini, scade tra 13 giorni"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2022-1D.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2022-1D

## Sintesi
- Retainer mensile di luglio 2026 del servizio Social Growth.
- Tipo `retainer` (dedotto da descrizione, importo e offerta); termini di pagamento 15 giorni data fattura, emissione 2026-07-01, scadenza 2026-07-16.
- Stato nell'export (2026-07-02): in attesa di pagamento.
- Alla data dell'export (2026-07-02) non ancora scaduta.
- Stato oggi: in termini, scade tra 13 giorni (scadenza 2026-07-16).

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-artigiani-del-gusto]]
- Offerta: [[offerta-2022-1]]
- Progetto: [[social-growth-artigiani]]
