---
tipo: fattura
numero: 2026-2B
cliente: "[[cliente-studiolex]]"
contatto_sollecito: "[[chiara-messina]]"   # referente del cliente
offerta: "[[offerta-2026-2]]"
progetto: "[[content-compliance-studiolex]]"
tipo_fattura: saldo
importo: 1800
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 396
importo_ivato: 2196
emissione: 2026-06-01
scadenza: 2026-07-16
stato_documentato: in-attesa
incasso: null
stato_calcolato_oggi: "in termini, scade tra 13 giorni"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-2B.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-2B

## Sintesi
- Saldo (50%) di Content Compliance.
- Tipo `saldo` (dedotto da descrizione, importo e offerta); termini di pagamento 45 giorni data fattura, emissione 2026-06-01, scadenza 2026-07-16.
- Stato nell'export (2026-07-02): in attesa di pagamento.
- Alla data dell'export non ancora scaduta.
- Stato oggi: in termini, scade tra 13 giorni (scadenza 2026-07-16).

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-studiolex]]
- Offerta: [[offerta-2026-2]]
- Progetto: [[content-compliance-studiolex]]
