---
tipo: fattura
numero: 2026-2A
cliente: "[[cliente-studiolex]]"
contatto_sollecito: "[[chiara-messina]]"   # referente del cliente
offerta: "[[offerta-2026-2]]"
progetto: "[[content-compliance-studiolex]]"
tipo_fattura: acconto
importo: 1800
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 396
importo_ivato: 2196
emissione: 2026-03-01
scadenza: 2026-04-15
stato_documentato: pagata
incasso: 2026-04-10
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-2A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-2A

## Sintesi
- Acconto del 50% per Content Compliance.
- Tipo `acconto` (dedotto da descrizione, importo e offerta); termini di pagamento 45 giorni data fattura, emissione 2026-03-01, scadenza 2026-04-15.
- Stato nell'export (2026-07-02): pagata il 2026-04-10.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-studiolex]]
- Offerta: [[offerta-2026-2]]
- Progetto: [[content-compliance-studiolex]]
