---
tipo: indice
argomento: fatture
fonti:
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Indice fatture

Vista derivata dalle note fattura (importi in euro, IVA esclusa). Stato documentato = export 2026-07-02.
Per il riepilogo per stato, cliente e totale apri [[riepilogo-fatture]] (query Dataview). Per una tabella dinamica e ordinabile apri `fatture.base` (Obsidian Bases): legge le proprietà delle note e non contiene dati propri.

| Nota | Cliente | Offerta | Tipo | Importo | Emissione | Scadenza | Stato documentato | Stato calcolato oggi |
|---|---|---|---|---|---|---|---|---|
| [[fattura-n-2022-1a]] | [[cliente-artigiani-del-gusto]] | [[offerta-2022-1]] | retainer | 200 | 2026-04-01 | 2026-04-16 | pagata | pagata |
| [[fattura-n-2022-1b]] | [[cliente-artigiani-del-gusto]] | [[offerta-2022-1]] | retainer | 200 | 2026-05-01 | 2026-05-16 | pagata | pagata |
| [[fattura-n-2022-1c]] | [[cliente-artigiani-del-gusto]] | [[offerta-2022-1]] | retainer | 200 | 2026-06-01 | 2026-06-16 | scaduta | scaduta da 17 giorni |
| [[fattura-n-2022-1d]] | [[cliente-artigiani-del-gusto]] | [[offerta-2022-1]] | retainer | 200 | 2026-07-01 | 2026-07-16 | in-attesa | in termini, scade tra 13 giorni |
| [[fattura-n-2025-1a]] | [[cliente-bloome-cosmetics]] | [[offerta-2025-1]] | acconto | 2.600 | 2025-11-05 | 2025-12-05 | pagata | pagata |
| [[fattura-n-2025-1b]] | [[cliente-bloome-cosmetics]] | [[offerta-2025-1]] | saldo | 2.600 | 2026-05-10 | 2026-06-09 | pagata | pagata |
| [[fattura-n-2025-2a]] | [[cliente-nordvik-italia]] | [[offerta-2025-2]] | unica | 2.100 | 2026-02-28 | 2026-03-30 | pagata | pagata |
| [[fattura-n-2025-3a]] | [[cliente-bloome-cosmetics]] | [[offerta-2025-3]] | unica | 1.200 | 2026-02-15 | 2026-03-17 | pagata | pagata |
| [[fattura-n-2026-1a]] | [[cliente-helios-energia]] | [[offerta-2026-1]] | acconto | 5.000 | 2026-02-01 | 2026-04-02 | pagata | pagata |
| [[fattura-n-2026-1b]] | [[cliente-helios-energia]] | [[offerta-2026-1]] | sal | 4.500 | 2026-05-01 | 2026-06-30 | pagata | pagata |
| [[fattura-n-2026-1c]] | [[cliente-helios-energia]] | [[offerta-2026-1]] | sal | 3.000 | 2026-07-01 | 2026-08-30 | in-attesa | in termini, scade tra 58 giorni |
| [[fattura-n-2026-2a]] | [[cliente-studiolex]] | [[offerta-2026-2]] | acconto | 1.800 | 2026-03-01 | 2026-04-15 | pagata | pagata |
| [[fattura-n-2026-2b]] | [[cliente-studiolex]] | [[offerta-2026-2]] | saldo | 1.800 | 2026-06-01 | 2026-07-16 | in-attesa | in termini, scade tra 13 giorni |
| [[fattura-n-2026-3a]] | [[cliente-verdalia]] | [[offerta-2026-3]] | acconto | 2.250 | 2026-04-15 | 2026-05-15 | pagata | pagata |
| [[fattura-n-2026-5a]] | [[cliente-nordvik-italia]] | [[offerta-2026-5]] | acconto | 3.400 | 2026-05-10 | 2026-06-09 | pagata | pagata |
| [[fattura-n-2026-5b]] | [[cliente-nordvik-italia]] | [[offerta-2026-5]] | sal | 1.700 | 2026-06-15 | 2026-07-15 | in-attesa | in termini, scade tra 12 giorni |
| [[fattura-n-2026-7a]] | [[cliente-verdalia]] | [[offerta-2026-7]] | unica | 3.200 | 2026-06-01 | 2026-07-01 | pagata | pagata |

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Riconciliazione (al 2026-07-02)
- Fatturato totale: 35.950 (17 fatture)
- Incassato: 29.050 (12 fatture pagate)
- Aperto: 6.900 (5 fatture: 1 scaduta nell'export, 4 in attesa)

## Fatturato vs importo offerta
| Offerta | Importo offerta | Fatturato | Incassato | Residuo da fatturare |
|---|---|---|---|---|
| [[offerta-2022-1]] | 200/mese (budget 2026 di 2.400) | 800 | 400 | non applicabile (retainer mensile) |
| [[offerta-2025-1]] | 5.200 | 5.200 | 5.200 | 0 |
| [[offerta-2025-2]] | 2.100 | 2.100 | 2.100 | 0 |
| [[offerta-2025-3]] | 1.200 | 1.200 | 1.200 | 0 |
| [[offerta-2026-1]] | 12.500 | 12.500 | 9.500 | 0 |
| [[offerta-2026-2]] | 3.600 | 3.600 | 1.800 | 0 |
| [[offerta-2026-3]] | 4.500 | 2.250 | 2.250 | 2.250 |
| [[offerta-2026-5]] | 6.800 | 5.100 | 3.400 | 1.700 |
| [[offerta-2026-7]] | 3.200 | 3.200 | 3.200 | 0 |

Offerte del vault senza fatture nell'export: 2026-4, 2026-6, 2026-8, 2026-9, 2026-10 (fatturato 0).

Importi offerta da `raw/connettori/google-drive/Clienti/*/Offerte`; la proprieta' del dato resta nelle note offerta.
