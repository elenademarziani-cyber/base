---
tipo: fattura
numero: 2026-1A
cliente: "[[cliente-helios-energia]]"
contatto_sollecito: "[[marta-colombo]]"   # referente del cliente
offerta: "[[offerta-2026-1]]"
progetto: "[[rebranding-digitale-helios]]"
tipo_fattura: acconto
importo: 5000
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 1100
importo_ivato: 6100
emissione: 2026-02-01
scadenza: 2026-04-02
stato_documentato: pagata
incasso: 2026-03-28
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-1A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-1A

## Sintesi
- Acconto all'avvio del Rebranding Digitale.
- Tipo `acconto` (dedotto da descrizione, importo e offerta); termini di pagamento 60 giorni data fattura, emissione 2026-02-01, scadenza 2026-04-02.
- Stato nell'export (2026-07-02): pagata il 2026-03-28.
- Termini a 60 giorni, condizioni cliente enterprise.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-helios-energia]]
- Offerta: [[offerta-2026-1]]
- Progetto: [[rebranding-digitale-helios]]
