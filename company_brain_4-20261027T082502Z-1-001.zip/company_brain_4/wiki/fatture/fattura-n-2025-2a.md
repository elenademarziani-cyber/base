---
tipo: fattura
numero: 2025-2A
cliente: "[[cliente-nordvik-italia]]"
contatto_sollecito: "[[luca-amendola]]"   # referente del cliente
offerta: "[[offerta-2025-2]]"
progetto: "[[case-study-produzione-nordvik]]"
tipo_fattura: unica
importo: 2100
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 462
importo_ivato: 2562
emissione: 2026-02-28
scadenza: 2026-03-30
stato_documentato: pagata
incasso: 2026-03-15
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2025-2A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2025-2A

## Sintesi
- Fattura descritta come "Saldo" del Case Study Produzione.
- Tipo `unica` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2026-02-28, scadenza 2026-03-30.
- Stato nell'export (2026-07-02): pagata il 2026-03-15.
- Non risultano altre fatture sull'offerta e l'importo e' l'intero valore dell'offerta: classificata come unica (dedotto) nonostante la dicitura "saldo".
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-nordvik-italia]]
- Offerta: [[offerta-2025-2]]
- Progetto: [[case-study-produzione-nordvik]]
