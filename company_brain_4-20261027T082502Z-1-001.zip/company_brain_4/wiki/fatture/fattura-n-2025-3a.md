---
tipo: fattura
numero: 2025-3A
cliente: "[[cliente-bloome-cosmetics]]"
contatto_sollecito: "[[alessia-neri]]"   # referente del cliente
offerta: "[[offerta-2025-3]]"
progetto: "[[analisi-dati-q1-bloome]]"
tipo_fattura: unica
importo: 1200
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 264
importo_ivato: 1464
emissione: 2026-02-15
scadenza: 2026-03-17
stato_documentato: pagata
incasso: 2026-03-10
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2025-3A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2025-3A

## Sintesi
- Fattura unica per l'Analisi Dati Q1.
- Tipo `unica` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2026-02-15, scadenza 2026-03-17.
- Stato nell'export (2026-07-02): pagata il 2026-03-10.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-bloome-cosmetics]]
- Offerta: [[offerta-2025-3]]
- Progetto: [[analisi-dati-q1-bloome]]
