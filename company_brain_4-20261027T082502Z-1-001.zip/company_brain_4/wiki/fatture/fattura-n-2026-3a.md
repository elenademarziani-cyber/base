---
tipo: fattura
numero: 2026-3A
cliente: "[[cliente-verdalia]]"
contatto_sollecito: "[[sofia-bianchi]]"   # referente del cliente
offerta: "[[offerta-2026-3]]"
progetto: "[[automazione-email-flow-verdalia]]"
tipo_fattura: acconto
importo: 2250
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 495
importo_ivato: 2745
emissione: 2026-04-15
scadenza: 2026-05-15
stato_documentato: pagata
incasso: 2026-05-12
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-3A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-3A

## Sintesi
- Acconto del 50% per Automazione Email Flow.
- Tipo `acconto` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2026-04-15, scadenza 2026-05-15.
- Stato nell'export (2026-07-02): pagata il 2026-05-12.
- Nell'export non compare una fattura di saldo sull'offerta.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-verdalia]]
- Offerta: [[offerta-2026-3]]
- Progetto: [[automazione-email-flow-verdalia]]

## Incongruenze
- [[saldo-2026-3-verdalia-non-fatturato]]: saldo dell'offerta non fatturato
