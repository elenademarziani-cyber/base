---
tipo: fattura
numero: 2026-5A
cliente: "[[cliente-nordvik-italia]]"
contatto_sollecito: "[[luca-amendola]]"   # referente del cliente
offerta: "[[offerta-2026-5]]"
progetto: "[[linkedin-lead-gen-nordvik]]"
tipo_fattura: acconto
importo: 3400
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 748
importo_ivato: 4148
emissione: 2026-05-10
scadenza: 2026-06-09
stato_documentato: pagata
incasso: 2026-06-02
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-5A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-5A

## Sintesi
- Acconto del 50% per LinkedIn Lead Gen.
- Tipo `acconto` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2026-05-10, scadenza 2026-06-09.
- Stato nell'export (2026-07-02): pagata il 2026-06-02.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-nordvik-italia]]
- Offerta: [[offerta-2026-5]]
- Progetto: [[linkedin-lead-gen-nordvik]]

## Incongruenze
- [[saldo-2026-5-nordvik-non-fatturato]]: saldo dell'offerta non fatturato
