---
tipo: fattura
numero: 2026-1B
cliente: "[[cliente-helios-energia]]"
contatto_sollecito: "[[marta-colombo]]"   # referente del cliente
offerta: "[[offerta-2026-1]]"
progetto: "[[rebranding-digitale-helios]]"
tipo_fattura: sal
importo: 4500
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 990
importo_ivato: 5490
emissione: 2026-05-01
scadenza: 2026-06-30
stato_documentato: pagata
incasso: 2026-06-20
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-1B.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-1B

## Sintesi
- SAL 2 del Rebranding Digitale.
- Tipo `sal` (dedotto da descrizione, importo e offerta); termini di pagamento 60 giorni data fattura, emissione 2026-05-01, scadenza 2026-06-30.
- Stato nell'export (2026-07-02): pagata il 2026-06-20.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-helios-energia]]
- Offerta: [[offerta-2026-1]]
- Progetto: [[rebranding-digitale-helios]]
