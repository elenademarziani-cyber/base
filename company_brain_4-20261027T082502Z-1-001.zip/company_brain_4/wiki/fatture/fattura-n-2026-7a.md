---
tipo: fattura
numero: 2026-7A
cliente: "[[cliente-verdalia]]"
contatto_sollecito: "[[sofia-bianchi]]"   # referente del cliente
offerta: "[[offerta-2026-7]]"
progetto: "[[content-q3-social-verdalia]]"
tipo_fattura: unica
importo: 3200
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 704
importo_ivato: 3904
emissione: 2026-06-01
scadenza: 2026-07-01
stato_documentato: pagata
incasso: 2026-06-25
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-7A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-7A

## Sintesi
- Fatturazione anticipata trimestrale di Content Q3 Social.
- Tipo `unica` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2026-06-01, scadenza 2026-07-01.
- Stato nell'export (2026-07-02): pagata il 2026-06-25.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-verdalia]]
- Offerta: [[offerta-2026-7]]
- Progetto: [[content-q3-social-verdalia]]
