---
tipo: indice
argomento: riepilogo fatture per stato, cliente e totale (query Dataview)
ultimo_aggiornamento: 2026-10-27
---
# Riepilogo fatture

Tabelle calcolate da **Dataview** sulle proprietà delle note fattura (nessun dato è copiato qui). Importi in euro. Lo stato è **calcolato rispetto al 2026-07-03**, non confermato dalle fonti: «Scaduta» = non pagata nell'export del 2026-07-02 e con scadenza già passata; «Pagata» = incassata nell'export. IVA al 22%, dedotta.

Per vedere le tabelle: Impostazioni, Plugin della community, disattiva la modalità limitata, cerca «Dataview», installa e abilita. Poi apri questa nota in modalità lettura.

## 1. Per stato
```dataview
TABLE WITHOUT ID
  Stato AS "Stato",
  length(rows) AS "N. fatture",
  sum(rows.importo) AS "Senza IVA",
  sum(rows.iva) AS "IVA",
  sum(rows.importo_ivato) AS "IVATO"
FROM "wiki/fatture"
WHERE tipo = "fattura"
FLATTEN choice(contains(stato_calcolato_oggi, "scaduta"), "Scaduta", "Pagata") AS Stato
GROUP BY Stato
SORT Stato DESC
```

## 2. Per cliente
```dataview
TABLE WITHOUT ID
  cliente AS "Cliente",
  length(rows) AS "N. fatture",
  sum(rows.importo) AS "Senza IVA",
  sum(rows.iva) AS "IVA",
  sum(rows.importo_ivato) AS "IVATO"
FROM "wiki/fatture"
WHERE tipo = "fattura"
GROUP BY cliente
SORT cliente ASC
```

## 3. Per cliente e stato
Una riga per cliente, con le colonne divise tra fatture scadute e pagate.
```dataview
TABLE WITHOUT ID
  cliente AS "Cliente",
  length(filter(rows, (r) => contains(r.stato_calcolato_oggi, "scaduta"))) AS "N. scadute",
  sum(map(filter(rows, (r) => contains(r.stato_calcolato_oggi, "scaduta")), (r) => r.importo)) AS "Scadute senza IVA",
  sum(map(filter(rows, (r) => contains(r.stato_calcolato_oggi, "scaduta")), (r) => r.importo_ivato)) AS "Scadute IVATO",
  length(filter(rows, (r) => !contains(r.stato_calcolato_oggi, "scaduta"))) AS "N. pagate",
  sum(map(filter(rows, (r) => !contains(r.stato_calcolato_oggi, "scaduta")), (r) => r.importo)) AS "Pagate senza IVA",
  sum(map(filter(rows, (r) => !contains(r.stato_calcolato_oggi, "scaduta")), (r) => r.importo_ivato)) AS "Pagate IVATO",
  sum(rows.importo_ivato) AS "Totale IVATO"
FROM "wiki/fatture"
WHERE tipo = "fattura"
GROUP BY cliente
SORT cliente ASC
```

## 4. Totale azienda
```dataview
TABLE WITHOUT ID
  length(rows) AS "N. fatture",
  sum(rows.importo) AS "Senza IVA",
  sum(rows.iva) AS "IVA",
  sum(rows.importo_ivato) AS "IVATO"
FROM "wiki/fatture"
WHERE tipo = "fattura"
GROUP BY true
```

## Valori attesi per il controllo
Totale azienda: 17 fatture, 35.950 senza IVA, 7.909 IVA, 43.859 IVATO. Scadute: 5 fatture, 6.900 senza IVA, 8.418 IVATO. Pagate: 12 fatture, 29.050 senza IVA, 35.441 IVATO. Se le tabelle mostrano numeri diversi, la query ha un problema.

Non comprende i saldi non ancora fatturati di [[automazione-email-flow-verdalia]] e [[linkedin-lead-gen-nordvik]]. Elenco completo delle fatture: [[fatture/_indice]].
