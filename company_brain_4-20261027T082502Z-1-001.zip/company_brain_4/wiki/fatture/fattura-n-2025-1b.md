---
tipo: fattura
numero: 2025-1B
cliente: "[[cliente-bloome-cosmetics]]"
contatto_sollecito: "[[alessia-neri]]"   # referente del cliente
offerta: "[[offerta-2025-1]]"
progetto: "[[tiktok-launch-bloome]]"
tipo_fattura: saldo
importo: 2600
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 572
importo_ivato: 3172
emissione: 2026-05-10
scadenza: 2026-06-09
stato_documentato: pagata
incasso: 2026-05-30
stato_calcolato_oggi: "pagata"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2025-1B.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2025-1B

## Sintesi
- Descritta come "saldo parziale" alla milestone dei 6 mesi.
- Tipo `saldo` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2026-05-10, scadenza 2026-06-09.
- Stato nell'export (2026-07-02): pagata il 2026-05-30.
- Insieme a [[fattura-n-2025-1a]] la somma coincide con l'importo dell'offerta, quindi di fatto chiude il fatturato (dedotto).
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-bloome-cosmetics]]
- Offerta: [[offerta-2025-1]]
- Progetto: [[tiktok-launch-bloome]]
