---
tipo: fattura
numero: 2022-1A
cliente: "[[cliente-artigiani-del-gusto]]"
contatto_sollecito: "[[tommaso-ferraro]]"   # referente del cliente
offerta: "[[offerta-2022-1]]"
progetto: "[[social-growth-artigiani]]"
tipo_fattura: retainer
importo: 200
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 44
importo_ivato: 244
emissione: 2026-04-01
scadenza: 2026-04-16
stato_documentato: pagata
incasso: 2026-04-20
stato_calcolato_oggi: pagata
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2022-1A.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2022-1A

## Sintesi
- Retainer mensile di aprile 2026 del servizio Social Growth.
- Tipo `retainer` (dedotto da descrizione, importo e offerta); termini di pagamento 15 giorni data fattura, emissione 2026-04-01, scadenza 2026-04-16.
- Stato nell'export (2026-07-02): pagata il 2026-04-20.
- Stato oggi: pagata.

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-artigiani-del-gusto]]
- Offerta: [[offerta-2022-1]]
- Progetto: [[social-growth-artigiani]]
