---
tipo: fattura
numero: 2026-1C
cliente: "[[cliente-helios-energia]]"
contatto_sollecito: "[[marta-colombo]]"   # referente del cliente
offerta: "[[offerta-2026-1]]"
progetto: "[[rebranding-digitale-helios]]"
tipo_fattura: sal
importo: 3000
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 660
importo_ivato: 3660
emissione: 2026-07-01
scadenza: 2026-08-30
stato_documentato: in-attesa
incasso: null
stato_calcolato_oggi: "in termini, scade tra 58 giorni"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-1C.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-1C

## Sintesi
- SAL 3 del Rebranding Digitale.
- Tipo `sal` (dedotto da descrizione, importo e offerta); termini di pagamento 60 giorni data fattura, emissione 2026-07-01, scadenza 2026-08-30.
- Stato nell'export (2026-07-02): in attesa di pagamento.
- Alla data dell'export non ancora scaduta. Un'email del 2026-07-01 (`2026-07-01_1250_recap-call-fattura-sal-3-e-stato-revisioni-dashboard.md`) conferma l'emissione senza problemi segnalati dal cliente.
- Stato oggi: in termini, scade tra 58 giorni (scadenza 2026-08-30).

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-helios-energia]]
- Offerta: [[offerta-2026-1]]
- Progetto: [[rebranding-digitale-helios]]
