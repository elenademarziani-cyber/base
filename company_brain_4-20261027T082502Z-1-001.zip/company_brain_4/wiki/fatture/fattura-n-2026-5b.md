---
tipo: fattura
numero: 2026-5B
cliente: "[[cliente-nordvik-italia]]"
contatto_sollecito: "[[luca-amendola]]"   # referente del cliente
offerta: "[[offerta-2026-5]]"
progetto: "[[linkedin-lead-gen-nordvik]]"
tipo_fattura: sal
importo: 1700
aliquota_iva: 22   # dedotto: importo considerato IVA esclusa, aliquota ordinaria
iva: 374
importo_ivato: 2074
emissione: 2026-06-15
scadenza: 2026-07-15
stato_documentato: in-attesa
incasso: null
stato_calcolato_oggi: "in termini, scade tra 12 giorni"
fonti:
  - raw/connettori/fatture-in-cloud/fatture/fattura-2026-5B.md
  - raw/connettori/fatture-in-cloud/README.md
ultimo_aggiornamento: 2026-10-27
---
# Fattura 2026-5B

## Sintesi
- SAL intermedio (25%) di LinkedIn Lead Gen.
- Tipo `sal` (dedotto da descrizione, importo e offerta); termini di pagamento 30 giorni data fattura, emissione 2026-06-15, scadenza 2026-07-15.
- Stato nell'export (2026-07-02): in attesa di pagamento.
- Alla data dell'export non ancora scaduta. Nell'export non compare una fattura di saldo sull'offerta.
- Stato oggi: in termini, scade tra 12 giorni (scadenza 2026-07-15).

Calcolato rispetto al 2026-07-03, non confermato dalle fonti.

## Collegamenti
- Cliente: [[cliente-nordvik-italia]]
- Offerta: [[offerta-2026-5]]
- Progetto: [[linkedin-lead-gen-nordvik]]

## Incongruenze
- [[saldo-2026-5-nordvik-non-fatturato]]: saldo dell'offerta non fatturato
