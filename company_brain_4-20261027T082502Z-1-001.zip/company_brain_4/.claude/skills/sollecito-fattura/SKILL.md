---
name: sollecito-fattura
description: Scrive una mail educata di sollecito di pagamento per una fattura scaduta di Musa AI, usando i dati del wiki (fattura, cliente, contatto, solleciti precedenti). Usare quando l'utente chiede di sollecitare un cliente, di scrivere un promemoria di pagamento o di sapere quali fatture scadute vanno sollecitate. Non invia nulla.
---

# Sollecito di una fattura scaduta

Prepara il **testo** di una mail di sollecito, educata e precisa. Non la invia mai.

## Regole inviolabili
- Questa è un'esercitazione: **non usare connettori reali** (Gmail, Slack, ecc.), nemmeno per creare una bozza. Il risultato è solo testo mostrato all'utente.
- Non scrivere in `raw/`. Non inventare dati: se manca un indirizzo email, un importo o una data, dillo e lascia il campo da completare.
- Nella mail al cliente non finiscono mai informazioni interne: margini, incongruenze del wiki, note personali dell'utente, giudizi sul cliente.

## Procedimento
1. **Individua la fattura.**
   - Se l'utente indica un numero (es. `2026-5B`), leggi `wiki/fatture/fattura-n-<numero minuscolo>.md`.
   - Altrimenti elenca le fatture il cui `stato_calcolato_oggi` inizia con «scaduta» (cerca nel frontmatter di `wiki/fatture/`, oppure leggi `wiki/fatture/_indice.md`) e chiedi all'utente quale sollecitare, o se vuole una mail per ciascuna.
   - Più fatture scadute dello stesso cliente: una sola mail con l'elenco.
2. **Raccogli i dati dalla nota fattura:** `numero`, `cliente`, `contatto_sollecito`, `progetto`, `tipo_fattura`, `importo`, `iva`, `importo_ivato`, `emissione`, `scadenza`, `stato_documentato`, `stato_calcolato_oggi`, `incasso`.
   - Giorni di ritardo = oggi − `scadenza` (la data odierna è quella della sessione).
   - Nella mail indica l'**importo IVATO** (è quello che il cliente paga). L'aliquota del 22% è dedotta dal wiki: se l'utente non l'ha confermata, segnalalo fuori dalla mail.
3. **Trova il contatto:** apri la nota `persona` indicata in `contatto_sollecito` (nome, ruolo, email). Se l'email è `non documentato`, lascia «A:» da completare.
4. **Cerca solleciti precedenti** per quella fattura o quel cliente:
   - leggi il corpo della nota fattura e le sue `fonti`;
   - cerca in `raw/connettori/email/` le email con «sollecito» e il nome del cliente o il numero fattura (solo lettura).
   - Se esiste un sollecito precedente, la mail è un **secondo promemoria** e lo cita con la data.
5. **Verifica lo stato.** Gli stati «scaduta» sono calcolati rispetto a oggi e non confermati: il pagamento può essere arrivato dopo l'export del 2026-07-02. Avvisa l'utente di controllare l'incasso prima di inviare.
6. **Scrivi la mail** (vedi sotto) e mostrala all'utente. Se è disponibile la skill `componi-mail-widget`, usala per mostrarla in un widget modificabile con A, Cc, Oggetto e corpo; altrimenti scrivila in chiaro con quegli stessi campi.
7. **Chiudi con una nota breve** per l'utente (fuori dalla mail): dati da verificare (incasso, email del destinatario, aliquota IVA), eventuali solleciti precedenti trovati, chi firma.

## Come scrivere la mail
- Lingua: italiano. Tono cordiale e professionale, mai accusatorio: parti dal presupposto che sia una svista o che il pagamento sia in corso.
- Stile Musa AI: saluto «Ciao Nome,» (come nelle mail già inviate ai referenti), frasi brevi, firma `Nome Cognome | Ruolo | Musa AI`.
- **Oggetto**: `Promemoria pagamento fattura <numero> – <progetto>`.
- **Corpo**, in questo ordine:
  1. saluto e riferimento alla fattura: numero, data di emissione, descrizione breve (tipo e progetto), importo IVATO, scadenza;
  2. richiesta gentile di verificare lo stato del pagamento, con la formula «se nel frattempo avete già provveduto, vi chiediamo di ignorare questo messaggio»;
  3. disponibilità a rimandare la copia della fattura o a chiarire dubbi;
  4. richiesta di una data prevista di pagamento (solo se il ritardo supera i 15 giorni o se è un secondo promemoria);
  5. ringraziamento e firma.
- **Gradazione**: primo promemoria = molto leggero; secondo = cita il sollecito del giorno X e chiede conferma della data di pagamento. Niente minacce, penali, interessi di mora o sospensione dei servizi, salvo che l'utente li chieda e il contratto li preveda (controlla la nota `contratto-<cliente>`).
- Non scrivere IBAN o coordinate bancarie: non sono nelle fonti. Usa «le coordinate sono riportate in fattura».
- **Mittente**: se l'utente non lo indica, proponi Laura Conti (Account Manager, relazioni con i clienti) e dillo; le mail di sollecito già presenti nelle fonti sono firmate da Davide Ferretti e da Marco Rossi.

## Traccia di partenza
```
A: <email del contatto>
Oggetto: Promemoria pagamento fattura <numero> – <progetto>

Ciao <Nome>,

ti scrivo a proposito della fattura <numero> del <data emissione> (<tipo> – <progetto>), di <importo IVATO> € IVA inclusa, con scadenza il <data scadenza>, che dai nostri registri risulta ancora da saldare.

Se nel frattempo hai già provveduto, ignora pure questo messaggio e grazie. In caso contrario, potresti verificare lo stato del pagamento? Se ti serve una copia della fattura o hai qualche dubbio, ti rispondo volentieri.

<Se secondo promemoria: Ti avevamo già scritto il <data> a questo proposito.> Se puoi, fammi sapere la data prevista di pagamento.

Grazie e a presto,
<Nome Cognome> | <Ruolo> | Musa AI
```

## Dopo l'invio
Se l'utente conferma di aver inviato la mail, aggiorna la nota fattura (una riga in «Sintesi»: sollecito inviato il `<data>` a `<contatto>`) e aggiungi una riga a `wiki/log.md`, come previsto da `CLAUDE.md`. Non modificare altro.
